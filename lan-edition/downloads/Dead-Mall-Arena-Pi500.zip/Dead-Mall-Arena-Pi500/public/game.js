(function(){
  "use strict";

  /* ============================================================
     SOUND — synthesized with Web Audio, no external files needed
  ============================================================ */
  let audioCtx = null;
  function ensureAudio(){
    if(!audioCtx){
      try{ audioCtx = new (window.AudioContext || window.webkitAudioContext)(); }catch(e){}
    }
    if(audioCtx && audioCtx.state === 'suspended') audioCtx.resume();
  }
  function playNoiseBurst(duration, filterFreq, gainPeak){
    if(!audioCtx) return;
    const bufferSize = Math.max(1, Math.floor(audioCtx.sampleRate * duration));
    const buffer = audioCtx.createBuffer(1, bufferSize, audioCtx.sampleRate);
    const data = buffer.getChannelData(0);
    for(let i=0;i<bufferSize;i++) data[i] = (Math.random()*2-1) * (1 - i/bufferSize);
    const src = audioCtx.createBufferSource();
    src.buffer = buffer;
    const filter = audioCtx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.value = filterFreq;
    const gain = audioCtx.createGain();
    gain.gain.setValueAtTime(gainPeak, audioCtx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime+duration);
    src.connect(filter); filter.connect(gain); gain.connect(audioCtx.destination);
    src.start();
  }
  function playTone(freq, duration, type, gainPeak, freqEnd){
    if(!audioCtx) return;
    const osc = audioCtx.createOscillator();
    osc.type = type || 'sine';
    osc.frequency.setValueAtTime(freq, audioCtx.currentTime);
    if(freqEnd) osc.frequency.exponentialRampToValueAtTime(freqEnd, audioCtx.currentTime+duration);
    const gain = audioCtx.createGain();
    gain.gain.setValueAtTime(gainPeak, audioCtx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime+duration);
    osc.connect(gain); gain.connect(audioCtx.destination);
    osc.start(); osc.stop(audioCtx.currentTime+duration);
  }
  const GUNSHOT_SPECS = {
    shotgun:{dur:0.22, filt:1800, gain:0.5, thump:110},
    pistol: {dur:0.10, filt:3000, gain:0.35, thump:180},
    smg:    {dur:0.07, filt:2600, gain:0.28, thump:160},
    rifle:  {dur:0.14, filt:2200, gain:0.40, thump:140},
    sniper: {dur:0.30, filt:1200, gain:0.55, thump:80}
  };
  function playGunshotSound(weaponId){
    ensureAudio(); if(!audioCtx) return;
    const s = GUNSHOT_SPECS[weaponId] || GUNSHOT_SPECS.pistol;
    playNoiseBurst(s.dur, s.filt, s.gain);
    playTone(s.thump, s.dur*0.6, 'triangle', s.gain*0.6, s.thump*0.5);
  }
  function playHitmarkerSound(){ ensureAudio(); playTone(1400,0.06,'square',0.15); }
  function playPoolCrackSound(){
    ensureAudio(); if(!audioCtx) return;
    playNoiseBurst(0.08, 3200, 0.35);
    playTone(1800, 0.05, 'square', 0.2);
    setTimeout(() => playNoiseBurst(0.12, 1400, 0.12), 60);
  }
  function playCreepyBreath(){
    ensureAudio(); if(!audioCtx) return;
    // low, rasping inhale/exhale — filtered noise with a slow rise and fall
    playNoiseBurst(0.55, 380, 0.13);
    setTimeout(() => playNoiseBurst(0.5, 280, 0.1), 500);
  }
  function playPickupSound(){ ensureAudio(); playTone(700,0.08,'sine',0.2,1100); }
  function playDamageSound(){ ensureAudio(); playNoiseBurst(0.15,400,0.3); }
  function playReloadSound(){ ensureAudio(); playTone(300,0.04,'square',0.1); setTimeout(()=>playTone(500,0.04,'square',0.1), 120); }
  function playKillSound(){ ensureAudio(); playTone(500,0.12,'sawtooth',0.2,900); }
  function playExplosionSound(){ ensureAudio(); playNoiseBurst(0.6,600,0.6); playTone(60,0.5,'sine',0.5,30); }
  function playTradeSound(){ ensureAudio(); playTone(600,0.1,'sine',0.2,900); }
  function playThrowSound(){ ensureAudio(); playTone(220,0.15,'sine',0.15,340); }
  function playScreamOrLaugh(){
    ensureAudio(); if(!audioCtx) return;
    if(Math.random() < 0.5){
      // distant scream: descending pitch with a noisy edge
      playTone(900, 0.9, 'sawtooth', 0.22, 180);
      playNoiseBurst(0.7, 1600, 0.14);
    } else {
      // hysterical laughing: rapid, uneven pitch blips
      const count = 5 + Math.floor(Math.random()*4);
      for(let i=0;i<count;i++){
        setTimeout(() => playTone(260+Math.random()*380, 0.11, 'square', 0.17), i*(90+Math.random()*60));
      }
    }
  }
  function flickerScreenOnce(){
    const el = document.getElementById('flickerOverlay');
    el.style.transition = 'none';
    el.style.opacity = String(0.5+Math.random()*0.4);
    setTimeout(() => { el.style.transition = 'opacity .25s'; el.style.opacity = '0'; }, 60+Math.random()*60);
  }
  let storyShakeAmt = 0;

  /* ============================================================
     SETUP
  ============================================================ */
  // LAN multiplayer runs through net.js (a WebSocket to the bundled server); see NETWORKING below
  const net = window.DMANet;
  const mpStatusEl = document.getElementById('mpStatus');

  const myId = 'p_' + Math.random().toString(36).slice(2,10) + Date.now().toString(36);
  let myName = 'Operator';

  const scene = new THREE.Scene();
  scene.background = new THREE.Color(0x121208);
  scene.fog = new THREE.Fog(0x3a3626, 10, 60);

  const camera = new THREE.PerspectiveCamera(75, window.innerWidth/window.innerHeight, 0.1, 400);
  camera.rotation.order = 'YXZ';

  // graphics preset (Ultra for the AMD 395, Pi for the Raspberry Pi 500, etc.) is chosen in boot.js
  const lowPowerMode = DMA.Q.lambert;
  const pipeline = DMA.createPipeline(scene, camera);
  const renderer = pipeline.renderer;

  // every player must build the exact same mall (store names, lease signs, decor) — seed the
  // random generator for the world build, then hand back the real one before gameplay starts
  DMA.seedRandom(19870915);

  scene.add(new THREE.AmbientLight(0x8a8a6a, 0.42));
  const sun = new THREE.DirectionalLight(0xcfc9a0, 0.4);
  sun.position.set(20, 30, 10);
  scene.add(sun);
  const rim = new THREE.DirectionalLight(0x2a3a4a, 0.15);
  rim.position.set(-20,10,-20);
  scene.add(rim);

  /* ============================================================
     WEAPONS
  ============================================================ */
  const WEAPONS = {
    shotgun:{name:'Sawed-Off',   kind:'shotgun', pellets:9, spread:0.055, damage:7,  cooldown:550,  range:40,  recoil:0.06, tracerColor:0xfff2c0},
    pistol: {name:'Sidearm',     kind:'hitscan', pellets:1, spread:0.010, damage:24, cooldown:260,  range:60,  recoil:0.02, tracerColor:0xffe9a8},
    smg:    {name:'SMG',         kind:'hitscan', pellets:1, spread:0.035, damage:9,  cooldown:90,   range:50,  recoil:0.012,tracerColor:0xaee8ff},
    rifle:  {name:'Rifle',       kind:'hitscan', pellets:1, spread:0.006, damage:34, cooldown:480,  range:90,  recoil:0.035,tracerColor:0xffcf8a},
    sniper: {name:'Sniper',      kind:'hitscan', pellets:1, spread:0.0015,damage:85, cooldown:1300, range:160, recoil:0.09, tracerColor:0xff5c5c},
    rpg:    {name:'RPG',         kind:'rocket',  pellets:1, spread:0.008, damage:100,cooldown:1700, range:70,  recoil:0.12, tracerColor:0xff8a3d}
  };
  const WEAPON_KEYS = Object.keys(WEAPONS).filter(k => k !== 'rpg'); // RPG is fortune-exclusive, never drops normally
  function randomWeaponId(){ return WEAPON_KEYS[Math.floor(Math.random()*WEAPON_KEYS.length)]; }

  const GUN_MESH_SPECS = {
    shotgun:{w:0.17,h:0.17,l:0.7, color:0x3a2a1a},
    pistol: {w:0.08,h:0.14,l:0.28,color:0x777777},
    smg:    {w:0.09,h:0.16,l:0.45,color:0x2f4a6a},
    rifle:  {w:0.09,h:0.14,l:0.75,color:0x3a4a2a},
    sniper: {w:0.07,h:0.12,l:0.95,color:0x232323},
    rpg:    {w:0.17,h:0.17,l:0.95,color:0x2a3a1a}
  };
  function gunMeshFor(weaponId, armInfo){
    const s = GUN_MESH_SPECS[weaponId] || GUN_MESH_SPECS.pistol;
    const mesh = new THREE.Mesh(new THREE.BoxGeometry(s.w,s.h,s.l), new THREE.MeshStandardMaterial({color:s.color, roughness:0.5, metalness:0.3}));
    const ai = armInfo || {armY:1.1, armOffset:0.5};
    mesh.position.set(ai.armOffset+0.1, ai.armY-0.05, 0.32);
    return mesh;
  }

  const BOT_FIRE_INTERVAL = {shotgun:1300, pistol:950, smg:420, rifle:1350, sniper:2300};
  const BOT_DAMAGE = {shotgun:16, pistol:12, smg:6, rifle:18, sniper:32};

  /* ============================================================
     ARENA — abandoned mall, ~110x110
  ============================================================ */
  const ARENA_HALF = 55;
  const ATRIUM_R = 13;
  const CORR_HALF_W = 6;
  const CORR_END = ARENA_HALF - 6;
  const FLOOR2_Y = 5.5;
  const ESC_X = 13, ESC_Z0 = 5, ESC_Z1 = 12.2, ESC_HALF_W = 1.6, ESC_STEP_COUNT = 14;
  const escalatorTextures = [];
  const escalatorSteps = [];
  function positionEscalatorStep(s, t){
    const y = 0.1 + t*FLOOR2_Y;
    const z = ESC_Z0 + t*(ESC_Z1-ESC_Z0);
    s.tread.position.set(ESC_X, y, z);
    s.riser.position.set(ESC_X, y-0.11, z - s.stepDepth/2 + 0.03);
    s.edge.position.set(ESC_X, y+0.035, z + s.stepDepth/2 - 0.03);
  }
  const pizzaRobots = [];
  const animatronics = [];
  const creepyFigures = [];
  const billboardPlaques = [];
  const speechFollowers = [];
  function makeSpeechTexture(text){
    const c = document.createElement('canvas'); c.width = 512; c.height = 160;
    const ctx = c.getContext('2d');
    ctx.fillStyle = 'rgba(10,8,14,0.88)';
    ctx.fillRect(4,4,504,152);
    ctx.strokeStyle = 'rgba(255,255,255,0.35)'; ctx.lineWidth = 3;
    ctx.strokeRect(4,4,504,152);
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 26px sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    const words = text.split(' ');
    const lines = []; let line = '';
    words.forEach(w => {
      const test = line + w + ' ';
      if(ctx.measureText(test).width > 460){ lines.push(line.trim()); line = w + ' '; }
      else line = test;
    });
    lines.push(line.trim());
    const lineH = 32;
    const startY = 80 - (lines.length-1)*lineH/2;
    lines.forEach((l,i) => ctx.fillText(l, 256, startY+i*lineH));
    return new THREE.CanvasTexture(c);
  }
  function buildSpeechBubble(yOffset, followFn){
    const mat = new THREE.MeshBasicMaterial({transparent:true, opacity:0, side:THREE.DoubleSide});
    const mesh = new THREE.Mesh(new THREE.PlaneGeometry(2.0,0.63), mat);
    mesh.visible = false;
    scene.add(mesh);
    billboardPlaques.push(mesh);
    const bubble = {
      mesh, yOffset,
      say(text, duration){
        mesh.material.map = makeSpeechTexture(text);
        mesh.material.opacity = 1;
        mesh.material.needsUpdate = true;
        mesh.visible = true;
        clearTimeout(mesh.userData.hideTimer);
        mesh.userData.hideTimer = setTimeout(() => { mesh.visible = false; }, duration||3500);
      }
    };
    speechFollowers.push({bubble, followFn});
    return bubble;
  }
  let movieScreen = null;
  const shootables = [];
  const bots = [];
  let sodaCanMesh = null, pizzaSliceMesh = null;
  let storyTriggerPos = null, storyPlaying = false, storyPlayedAt = 0;
  let sitOffset = 0, sitTargetOffset = 0;
  const storyLines = [
    "The bear leans forward. \"Sit. Get comfortable. It's story time.\"",
    "\"I've stood on this stage since 1987. I've seen a lot of things.\"",
    "\"I watched this arcade get its first fighting cabinet. Grown men wept.\"",
    "\"Three different owners tried to modernize this place. None of them lasted.\"",
    "\"The rabbit hasn't blinked since the incident in '94. Don't ask about the incident.\"",
    "\"Some nights, after close, the lights flicker on their own. We don't turn them on.\"",
    "\"Kids used to line up around the block for our shows. Now it's just... you.\"",
    "\"We used to do four shows a day. Confetti cannons, a laser light show, the whole production.\"",
    "\"I remember when the go-kart museum was just an empty storage room. The engines showed up one at a time. No delivery truck. No explanation.\"",
    "\"The vending machines still restock themselves, every night. We don't know who does it anymore. We stopped asking.\"",
    "\"There was a fire in '96. Everything survived except the popcorn machine at the theater. We don't talk about why it was the only thing that burned.\"",
    "\"The mall used to close at 9 PM sharp, every night, like clockwork. Now... does it even close?\"",
    "\"Here's some advice, since you're new: keep moving, never stand still in a doorway.\"",
    "\"And whatever you do — please keep an eye out for the tall lurkers. Never trust them.\""
  ];
  function showStoryLine(text, duration){
    const el = document.getElementById('storyText');
    el.textContent = text;
    el.classList.add('show');
    setTimeout(() => { el.classList.remove('show'); }, duration || 4700);
  }
  function playStorySequence(){
    storyLines.forEach((line, i) => setTimeout(() => showStoryLine(line), i*4800));
  }
  let grenadeCount = 0;
  let grenadeStandPos = null;
  const grenades = [];
  const GRENADE_COST_HP = 15;
  const GRENADE_MAX = 4;
  function updateGrenadeUI(){
    const el = document.getElementById('grenadeCountEl');
    if(el) el.textContent = grenadeCount;
  }
  function tryTradeAtStand(){
    if(!grenadeStandPos || !localAlive || currentFloor !== 1) return;
    const dx = camera.position.x-grenadeStandPos.x, dz = camera.position.z-grenadeStandPos.z;
    if(dx*dx+dz*dz > 2.5*2.5) return;
    if(grenadeCount >= GRENADE_MAX){ addFeed(myName + " — the vendor shrugs. \"You're carrying enough.\"", false); return; }
    if(localHealth <= GRENADE_COST_HP){ addFeed(myName + " — the vendor eyes your health. \"Not like that, kid.\"", false); return; }
    localHealth -= GRENADE_COST_HP;
    grenadeCount++;
    updateHealthUI();
    updateGrenadeUI();
    playTradeSound();
    addFeed(myName + ' traded a piece of their integrity for a hand grenade', false);
  }

  const crystalBalls = [];
  let fortuneTellerPos = null;
  let fortuneTellerFigure = null;
  let lastFortuneAt = 0;
  const HELL_Y = -60;
  let inHell = false, preHellPos = null, preHellFloor = 0, originalFogColor = null;
  const hellFires = [];
  let hellFireLight = null;
  let drunkLockedUntil = 0;
  let shieldRegenUntil = 0;

  function makeBloodTextTexture(text){
    const c = document.createElement('canvas'); c.width = 512; c.height = 256;
    const ctx = c.getContext('2d');
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    let fontSize = 52;
    ctx.font = '900 '+fontSize+'px Georgia, serif';
    const maxWidth = 470;
    while(ctx.measureText(text).width > maxWidth && fontSize > 20){
      fontSize -= 2;
      ctx.font = '900 '+fontSize+'px Georgia, serif';
    }
    ctx.fillStyle = '#5a0000';
    ctx.fillText(text, 258, 116);
    ctx.fillStyle = '#9a0808';
    ctx.fillText(text, 256, 112);
    const textWidth = Math.min(460, ctx.measureText(text).width);
    const left = 256 - textWidth/2;
    ctx.fillStyle = 'rgba(130,10,10,0.9)';
    for(let i=0;i<24;i++){
      const dx = left + Math.random()*textWidth;
      const dy = 112 + 22 + Math.random()*8;
      const len = 16+Math.random()*90;
      const w = 3+Math.random()*6;
      ctx.beginPath();
      ctx.moveTo(dx-w/2, dy);
      ctx.quadraticCurveTo(dx+(Math.random()-0.5)*6, dy+len*0.6, dx, dy+len);
      ctx.quadraticCurveTo(dx+(Math.random()-0.5)*6, dy+len*0.6, dx+w/2, dy);
      ctx.closePath();
      ctx.fill();
      ctx.beginPath();
      ctx.arc(dx, dy+len, w*0.55, 0, Math.PI*2);
      ctx.fill();
    }
    ctx.fillStyle = 'rgba(100,5,5,0.4)';
    for(let i=0;i<40;i++){
      const x = Math.random()*512, y = Math.random()*256, r = 1+Math.random()*3;
      ctx.beginPath(); ctx.arc(x,y,r,0,Math.PI*2); ctx.fill();
    }
    return new THREE.CanvasTexture(c);
  }
  function buildHellRoom(){
    const group = new THREE.Group();
    group.position.set(0, HELL_Y, 0);
    scene.add(group);
    const floorMat = new THREE.MeshStandardMaterial({color:0x2a0805, emissive:0xaa2200, emissiveIntensity:0.5, roughness:0.85});
    const floor = new THREE.Mesh(new THREE.PlaneGeometry(16,16), floorMat);
    floor.rotation.x = -Math.PI/2;
    group.add(floor);
    const wallMat = new THREE.MeshStandardMaterial({color:0x140303, roughness:0.95, side:THREE.DoubleSide});
    [[0,-8,0],[0,8,0],[-8,0,Math.PI/2],[8,0,Math.PI/2]].forEach(([x,z,ry]) => {
      const wall = new THREE.Mesh(new THREE.PlaneGeometry(16,7), wallMat);
      wall.position.set(x,3.5,z);
      wall.rotation.y = ry;
      group.add(wall);
    });
    // "WELCOME TO HELL" scrawled in dripping blood on every wall, facing the room interior
    const bloodTex = makeBloodTextTexture('WELCOME TO HELL');
    const bloodMat = new THREE.MeshBasicMaterial({map:bloodTex, transparent:true, side:THREE.DoubleSide});
    [[0,3.5,-7.9,0],[0,3.5,7.9,Math.PI],[-7.9,3.5,0,Math.PI/2],[7.9,3.5,0,-Math.PI/2]].forEach(([x,y,z,ry]) => {
      const bloodText = new THREE.Mesh(new THREE.PlaneGeometry(7.5,3.75), bloodMat);
      bloodText.position.set(x,y,z);
      bloodText.rotation.y = ry;
      group.add(bloodText);
    });
    for(let i=0;i<14;i++){
      const fire = new THREE.Mesh(new THREE.ConeGeometry(0.18+Math.random()*0.22,0.6+Math.random()*0.6,6), new THREE.MeshBasicMaterial({color:0xff5522, transparent:true, opacity:0.85}));
      fire.position.set((Math.random()-0.5)*13, 0.3, (Math.random()-0.5)*13);
      group.add(fire);
      hellFires.push(fire);
    }
    hellFireLight = new THREE.PointLight(0xff3300, 2.2, 24);
    hellFireLight.position.set(0,4,0);
    group.add(hellFireLight);
    const hellFireLight2 = new THREE.PointLight(0xff4400, 1.4, 18);
    hellFireLight2.position.set(5,2,-5);
    group.add(hellFireLight2);
  }
  buildHellRoom();

  function sendToHell(){
    if(inHell || !localAlive) return;
    inHell = true;
    preHellPos = camera.position.clone();
    preHellFloor = currentFloor;
    camera.position.set(0, HELL_Y+1.7, 0);
    if(!originalFogColor) originalFogColor = scene.fog.color.clone();
    scene.fog.color.setHex(0x260404);
    playExplosionSound();
    showStoryLine('"You shouldn\'t have asked." The floor gives way beneath you.', 4000);
    addFeed(myName + ' vanishes into the crystal, screaming', true);
    setTimeout(() => {
      camera.position.copy(preHellPos);
      currentFloor = preHellFloor;
      inHell = false;
      if(originalFogColor) scene.fog.color.copy(originalFogColor);
      localHealth = 1;
      updateHealthUI();
      showStoryLine('You claw your way back. Something followed you partway.', 4500);
      addFeed(myName + ' returns from somewhere that shouldn\'t exist, barely alive', true);
    }, 15000);
  }

  function buildGangsterMeshes(){
    const meshes = [];
    const suitMat = new THREE.MeshStandardMaterial({color:0x1a1a2a, roughness:0.6});
    const shirtMat = new THREE.MeshStandardMaterial({color:0xe8e0d0, roughness:0.6});
    const skinMat = new THREE.MeshStandardMaterial({color:0xc89068, roughness:0.7});
    const torso = new THREE.Mesh(new THREE.CylinderGeometry(0.32,0.38,0.9,8), suitMat);
    torso.position.y = 1.05; meshes.push(torso);
    const shirt = new THREE.Mesh(new THREE.BoxGeometry(0.25,0.35,0.05), shirtMat);
    shirt.position.set(0,1.25,0.3); meshes.push(shirt);
    const head = new THREE.Mesh(new THREE.SphereGeometry(0.24,10,10), skinMat);
    head.position.y = 1.65; meshes.push(head);
    const hatMat = new THREE.MeshStandardMaterial({color:0x1a1410, roughness:0.5});
    const hatBrim = new THREE.Mesh(new THREE.CylinderGeometry(0.3,0.3,0.04,12), hatMat);
    hatBrim.position.y = 1.78; meshes.push(hatBrim);
    const hatTop = new THREE.Mesh(new THREE.CylinderGeometry(0.2,0.22,0.18,12), hatMat);
    hatTop.position.y = 1.9; meshes.push(hatTop);
    const legL = new THREE.Mesh(new THREE.CylinderGeometry(0.12,0.12,0.9,8), suitMat);
    legL.position.set(0.14,0.45,0); meshes.push(legL);
    const legR = new THREE.Mesh(new THREE.CylinderGeometry(0.12,0.12,0.9,8), suitMat);
    legR.position.set(-0.14,0.45,0); meshes.push(legR);
    const armL = new THREE.Mesh(new THREE.CylinderGeometry(0.09,0.09,0.7,8), suitMat);
    armL.position.set(0.42,1.05,0); armL.rotation.z = 0.15; meshes.push(armL);
    const armR = new THREE.Mesh(new THREE.CylinderGeometry(0.09,0.09,0.7,8), suitMat);
    armR.position.set(-0.42,1.05,0); armR.rotation.z = -0.15; meshes.push(armR);
    meshes.armInfo = {armY:1.05, armOffset:0.5};
    return meshes;
  }
  const GANGSTER_SPAWN = {x:0, z:20};
  function playGangsterYell(){
    ensureAudio(); if(!audioCtx) return;
    playTone(170, 0.45, 'sawtooth', 0.32, 85);
    playNoiseBurst(0.35, 900, 0.22);
    setTimeout(() => playTone(140, 0.3, 'square', 0.22, 70), 150);
  }
  function spawnGangster(){
    const spawnPos = GANGSTER_SPAWN;
    const meshes = buildGangsterMeshes();
    const group = new THREE.Group();
    meshes.forEach(m => group.add(m));
    const species = {name:'Big Vinny', blood:0x8a1a1a};
    const nameTag = makeNameSprite('BIG VINNY // IRATE', '#ff2020');
    nameTag.position.y = 2.7; group.add(nameTag);
    const hpBar = new THREE.Mesh(new THREE.PlaneGeometry(1,0.12), new THREE.MeshBasicMaterial({color:0x37d67a}));
    hpBar.position.y = 2.45; group.add(hpBar);
    const gunGroup = new THREE.Group();
    const gunBody = new THREE.Mesh(new THREE.CylinderGeometry(0.1,0.1,0.5,8), new THREE.MeshStandardMaterial({color:0x2a2a2a, metalness:0.6}));
    gunBody.rotation.z = Math.PI/2; gunGroup.add(gunBody);
    for(let i=0;i<6;i++){
      const ang = (i/6)*Math.PI*2;
      const barrel = new THREE.Mesh(new THREE.CylinderGeometry(0.02,0.02,0.6,6), new THREE.MeshStandardMaterial({color:0x1a1a1a, metalness:0.7}));
      barrel.rotation.z = Math.PI/2;
      barrel.position.set(0.3, Math.cos(ang)*0.06, Math.sin(ang)*0.06);
      gunGroup.add(barrel);
    }
    gunGroup.position.set(0.45,1.05,0.3);
    group.add(gunGroup);
    group.position.set(spawnPos.x, currentFloor*FLOOR2_Y, spawnPos.z);
    scene.add(group);
    const patrol = [new THREE.Vector3(spawnPos.x,0,spawnPos.z)];
    playGangsterYell();
    addFeed('BIG VINNY: "I\'M GONNA FIND YOU!"', true);
    const gangster = {
      id:'gangster_'+Date.now(), name:'Big Vinny', group, hpBar, species, gunMesh:gunGroup, weaponId:'smg', armInfo:{armY:1.05,armOffset:0.5},
      health:140, maxHealth:140, alive:true, floor: currentFloor,
      patrol, patrolIdx:0, state:'attack',
      lastShot:0, fireInterval:55,
      speed:3.4,
      respawnAt:0, noRespawn:true,
      approach:true, burstFire:true, burstState:'windup', burstStateUntil:performance.now()+2200, lastYellAt:performance.now()
    };
    meshes.forEach(m => shootables.push({mesh:m, kind:'bot', ref:gangster}));
    bots.push(gangster);
  }

  const fortunes = [
    {text:'"Something walks beside you, unseen. For now, it means you well."', weight:14, apply:() => { localHealth = Math.min(100, localHealth+20); updateHealthUI(); }},
    {text:'"Run. It has already found the shape of you."', weight:11, apply:() => { speedBoostUntil = performance.now()+8000; }},
    {text:'"A skin of ash and old blood wraps around you. It will hold... once."', weight:11, apply:() => { shieldAmount = Math.min(100, shieldAmount+30); }},
    {text:'"The dead leave gifts for the desperate. Take it before they change their mind."', weight:9, apply:() => { equipWeapon(randomWeaponId()); }},
    {text:'"I see rot behind your eyes. It spreads a little more with every word I speak."', weight:9, apply:() => { damageLocalPlayer(15, 'a cursed fortune'); }},
    {text:'"Something in the dark just noticed you. Don\'t look back. Don\'t run either."', weight:7, apply:() => {}},
    {text:'"The crystal cracks. Even it doesn\'t want to know what happens to you."', weight:7, apply:() => {}},
    {text:'"You were cursed long before you walked in here. I only said it out loud."', weight:8, apply:() => { damageLocalPlayer(25, 'a shattered fortune'); }},
    {text:'"An old ward wakes and wraps itself around you. It will not let go easily."', weight:4, apply:() => { shieldAmount = 100; shieldRegenUntil = performance.now()+180000; }},
    {text:'"You will run for a long time yet. Longer than you\'d like."', weight:4, apply:() => { speedBoostUntil = performance.now()+180000; }},
    {text:'"Drink from the well I keep beneath this table. You won\'t remember agreeing to it."', weight:3, apply:() => { drunkLevel = 5; drunkLockedUntil = performance.now()+180000; }},
    {text:'"The dead had need of these once. They no longer do."', weight:5, apply:() => { grenadeCount = GRENADE_MAX; updateGrenadeUI(); }},
    {text:'"A weapon built for chaos. It suits you."', weight:5, apply:() => { equipWeapon('smg'); }},
    {text:'"Something too big for this world claws its way into your hands."', weight:10, apply:() => { equipWeapon('rpg'); }},
    {text:'"You have made an enemy tonight. He is already very, very angry."', weight:10, apply:() => { spawnGangster(); }},
    {text:'"You shouldn\'t have asked me that question." The crystal turns black as pitch.', weight:7, apply:() => { sendToHell(); }}
  ];
  function pickWeightedFortune(){
    const total = fortunes.reduce((s,f) => s+f.weight, 0);
    let r = Math.random()*total;
    for(const f of fortunes){
      if(r < f.weight) return f;
      r -= f.weight;
    }
    return fortunes[fortunes.length-1];
  }
  function tryGetFortune(){
    if(!fortuneTellerPos || !localAlive || currentFloor !== 1) return;
    const dx = camera.position.x-fortuneTellerPos.x, dz = camera.position.z-fortuneTellerPos.z;
    if(dx*dx+dz*dz > 2.8*2.8) return;
    const now = performance.now();
    if(now - lastFortuneAt < 2000) return;
    lastFortuneAt = now;
    if(localHealth <= 5){ addFeed(myName + ' — the crystal ball dims. "Come back when you have more to offer."', false); return; }
    localHealth -= 5;
    updateHealthUI();
    playTradeSound();
    const pick = pickWeightedFortune();
    pick.apply();
    updateStatusUI();
    showStoryLine(pick.text, 10400);
    if(fortuneTellerFigure && fortuneTellerFigure.speechBubble) fortuneTellerFigure.speechBubble.say(pick.text, 6500);
    addFeed(myName + ' pays the fortune teller for a reading', false);
    if(fortuneTellerFigure){
      fortuneTellerFigure.mouth.material.map = fortuneTellerFigure.mouthSmileTex;
      fortuneTellerFigure.mouth.material.needsUpdate = true;
      setTimeout(() => {
        fortuneTellerFigure.mouth.material.map = fortuneTellerFigure.mouthNeutralTex;
        fortuneTellerFigure.mouth.material.needsUpdate = true;
      }, 2600);
    }
  }

  let barPos = null;
  let drunkLevel = 0;
  let lastDrinkAt = 0;
  let appliedBlurLevel = -1;
  let drunkSwayYaw = 0, drunkSwayPitch = 0, drunkSwayRoll = 0;
  let jukeboxPos = null, jukeboxLight = null, jukeboxGlow = null, lastJukeboxAt = 0;
  const poolBalls = [];
  let poolCue = null, poolCueOrigX = 0;
  let dartboardPos = null, diveBarRoomGroup = null, lastDartAt = 0, dartScore = 0;
  const dartMeshes = [];
  function tryThrowDart(){
    if(!dartboardPos || currentFloor !== 1) return;
    const dx = camera.position.x-dartboardPos.x, dz = camera.position.z-dartboardPos.z;
    if(dx*dx+dz*dz > 3.6*3.6) return;
    const now = performance.now();
    if(now - lastDartAt < 900) return;
    lastDartAt = now;
    const r = Math.pow(Math.random(), 1.6) * 0.42;
    const ang = Math.random()*Math.PI*2;
    const score = r < 0.05 ? 50 : r < 0.14 ? 25 : r < 0.24 ? 15 : r < 0.34 ? 10 : 5;
    dartScore += score;
    playHitmarkerSound();
    const label = score === 50 ? 'BULLSEYE! ' : (score === 25 ? 'Inner ring! ' : '');
    addFeed(myName + ' throws a dart — ' + label + score + ' pts (total: ' + dartScore + ')', false);
    if(diveBarRoomGroup){
      const dart = new THREE.Mesh(new THREE.ConeGeometry(0.018,0.1,6), new THREE.MeshStandardMaterial({color:0x0a0a0a}));
      dart.position.set(dartboardPos.x+0.04, dartboardPos.y + Math.sin(ang)*r, dartboardPos.z + Math.cos(ang)*r);
      dart.rotation.z = Math.PI/2;
      diveBarRoomGroup.add(dart);
      dartMeshes.push(dart);
      if(dartMeshes.length > 6){ const old = dartMeshes.shift(); diveBarRoomGroup.remove(old); }
    }
  }
  let poolTablePos = null, poolAnimating = false, lastPoolAt = 0;
  function tryPlayPool(){
    if(!poolTablePos || currentFloor !== 1) return;
    const dx = camera.position.x-poolTablePos.x, dz = camera.position.z-poolTablePos.z;
    if(dx*dx+dz*dz > 3.6*3.6) return;
    const now = performance.now();
    if(poolAnimating || now - lastPoolAt < 3500) return;
    lastPoolAt = now;
    poolAnimating = true;
    // cue stick strikes forward, then springs back
    if(poolCue){
      poolCue.userData.strikeStart = now;
    }
    setTimeout(() => { playPoolCrackSound(); }, 220);
    poolBalls.forEach(b => {
      const ang = Math.random()*Math.PI*2;
      const dist = 0.25+Math.random()*0.55;
      let tx = b.origX + Math.cos(ang)*dist;
      let tz = b.origZ + Math.sin(ang)*dist;
      // clamp to stay on the felt, inside the rail
      const localX = Math.max(-1.05, Math.min(1.05, tx-poolTablePos.x));
      const localZ = Math.max(-0.5, Math.min(0.5, tz-poolTablePos.z));
      b.targetX = poolTablePos.x + localX;
      b.targetZ = poolTablePos.z + localZ;
      b.phase = 'scatter';
      b.phaseStart = now+220;
    });
    setTimeout(() => {
      poolBalls.forEach(b => { b.phase = 'return'; b.phaseStart = performance.now(); });
      setTimeout(() => { poolAnimating = false; poolBalls.forEach(b => { b.phase = 'idle'; }); }, 1600);
    }, 2000);
    addFeed(myName + ' breaks hard on the pool table', false);
  }
  let jukeboxPlaying = false, jukeboxStopAt = 0, jukeboxIntervalId = null, jukeboxBeat = 0;
  function playRockNote(freq, dur, gain){
    ensureAudio(); if(!audioCtx) return;
    playTone(freq, dur, 'sawtooth', gain, undefined);
    playTone(freq*1.006, dur, 'square', gain*0.55, undefined); // slight detune for a grittier power-chord edge
    playTone(freq*0.5, dur*0.9, 'triangle', gain*0.5, undefined); // sub octave for a bass punch
  }

  // original driving synth-brass "action march" soundtrack, in the vein of early-90s FPS games — not a reproduction of any specific track
  let gameMusicOn = false;
  let gameMusicIntervalId = null;
  let gameMusicBeat = 0;
  let gameMusicThemeSwitchAt = 0;
  const gameMusicThemes = [
    [110.0,110.0,164.8,110.0, 130.8,130.8,196.0,130.8, 110.0,110.0,164.8,110.0, 98.0,98.0,146.8,98.0],
    [146.8,146.8,220.0,146.8, 164.8,164.8,246.9,164.8, 130.8,130.8,196.0,130.8, 110.0,110.0,164.8,110.0],
    [123.5,123.5,185.0,123.5, 110.0,110.0,164.8,110.0, 138.6,138.6,207.7,138.6, 123.5,98.0,123.5,146.8],
    [98.0,98.0,146.8,196.0, 98.0,98.0,146.8,174.6, 110.0,110.0,164.8,220.0, 98.0,87.3,98.0,110.0]
  ];
  function playMarchNote(freq, dur, gain){
    ensureAudio(); if(!audioCtx) return;
    playTone(freq, dur, 'square', gain, undefined);
    playTone(freq*2, dur*0.35, 'square', gain*0.28, undefined);
    playTone(freq*0.5, dur*0.8, 'sawtooth', gain*0.4, undefined);
  }
  function startGameMusic(){
    ensureAudio();
    if(gameMusicIntervalId) return;
    gameMusicBeat = 0;
    let theme = gameMusicThemes[Math.floor(Math.random()*gameMusicThemes.length)];
    gameMusicThemeSwitchAt = performance.now() + 45000 + Math.random()*20000;
    gameMusicIntervalId = setInterval(() => {
      if(!gameMusicOn) return;
      if(performance.now() > gameMusicThemeSwitchAt){
        theme = gameMusicThemes[Math.floor(Math.random()*gameMusicThemes.length)];
        gameMusicThemeSwitchAt = performance.now() + 45000 + Math.random()*20000;
      }
      const freq = theme[gameMusicBeat % theme.length];
      playMarchNote(freq, 0.14, 0.075);
      if(gameMusicBeat % 4 === 0) playNoiseBurst(0.045, 3200, 0.045);
      if(gameMusicBeat % 8 === 4) playNoiseBurst(0.09, 450, 0.07);
      gameMusicBeat++;
    }, 150);
  }
  function stopGameMusic(){
    if(gameMusicIntervalId){ clearInterval(gameMusicIntervalId); gameMusicIntervalId = null; }
  }
  function toggleGameMusic(){
    if(gameMusicIntervalId){
      stopGameMusic();
      gameMusicOn = false;
      addFeed('Music: OFF (M to re-enable)', false);
    } else {
      gameMusicOn = true;
      startGameMusic();
      addFeed('Music: ON', false);
    }
  }

  function stopJukebox(){
    jukeboxPlaying = false;
    if(jukeboxIntervalId){ clearInterval(jukeboxIntervalId); jukeboxIntervalId = null; }
  }
  function playFunkNote(freq, dur, gain){
    ensureAudio(); if(!audioCtx) return;
    playTone(freq, dur, 'triangle', gain, freq*0.97);
    playTone(freq*2.01, dur*0.4, 'sine', gain*0.35);
  }
  function playJukeboxTune(){
    ensureAudio();
    if(jukeboxPlaying) return;
    jukeboxPlaying = true;
    jukeboxBeat = 0;
    jukeboxStopAt = performance.now() + 120000; // about two minutes
    // a handful of songs — driving rock riffs plus one slow funky groove — picked at random so it's a new song each time
    const songs = [
      {style:'rock', tempo:200, riff:[164.8,164.8,196.0,164.8,220.0,196.0,164.8,146.8, 164.8,164.8,196.0,220.0,246.9,220.0,196.0,164.8]},
      {style:'rock', tempo:200, riff:[146.8,146.8,174.6,146.8,196.0,174.6,146.8,130.8, 146.8,196.0,220.0,196.0,174.6,146.8,130.8,146.8]},
      {style:'rock', tempo:200, riff:[220.0,220.0,246.9,220.0,196.0,220.0,246.9,261.6, 220.0,196.0,174.6,196.0,220.0,246.9,220.0,196.0]},
      {style:'rock', tempo:200, riff:[110.0,110.0,130.8,110.0,146.8,130.8,110.0,98.0,  110.0,146.8,164.8,146.8,130.8,110.0,98.0,110.0]},
      {style:'funk', tempo:340, riff:[110.0,0,130.8,110.0, 0,146.8,110.0,0, 98.0,0,110.0,130.8, 0,110.0,98.0,0]},
      {style:'funk', tempo:300, riff:[87.3,0,87.3,0, 110.0,0,98.0,87.3, 0,73.4,0,87.3, 98.0,0,0,87.3]},
      {style:'funk', tempo:380, riff:[130.8,0,0,130.8, 155.6,0,146.8,0, 0,130.8,0,0, 116.5,0,130.8,0]}
    ];
    const song = songs[Math.floor(Math.random()*songs.length)];
    jukeboxIntervalId = setInterval(() => {
      if(!jukeboxPlaying || performance.now() > jukeboxStopAt){ stopJukebox(); return; }
      const freq = song.riff[jukeboxBeat % song.riff.length];
      if(freq > 0){
        if(song.style === 'funk') playFunkNote(freq, 0.18, 0.16);
        else playRockNote(freq, 0.2, 0.14);
      }
      if(song.style === 'rock'){
        if(jukeboxBeat % 2 === 0) playNoiseBurst(0.05, 2600, 0.07); // hi-hat-ish tick
        if(jukeboxBeat % 8 === 0) playNoiseBurst(0.12, 500, 0.16); // kick-ish thump on the downbeat
      } else {
        if(jukeboxBeat % 4 === 2) playNoiseBurst(0.04, 3200, 0.05); // sparse, swung hi-hat
        if(jukeboxBeat % 8 === 0) playNoiseBurst(0.1, 380, 0.14); // laid-back kick
      }
      jukeboxBeat++;
    }, song.tempo);
  }
  function tryPlayJukebox(){
    if(!jukeboxPos || currentFloor !== 1) return;
    const dx = camera.position.x-jukeboxPos.x, dz = camera.position.z-jukeboxPos.z;
    if(dx*dx+dz*dz > 2.2*2.2) return;
    const now = performance.now();
    if(now - lastJukeboxAt < 800) return;
    lastJukeboxAt = now;
    if(jukeboxPlaying){
      stopJukebox();
      addFeed(myName + ' cuts the jukebox off', false);
    } else {
      playJukeboxTune();
      addFeed(myName + ' cranks up the jukebox — rock n roll for the next couple minutes', false);
    }
  }
  function tryDrinkAtBar(){
    if(!barPos || !localAlive || currentFloor !== 1) return;
    const dx = camera.position.x-barPos.x, dz = camera.position.z-barPos.z;
    if(dx*dx+dz*dz > 2.8*2.8) return;
    const now = performance.now();
    if(now - lastDrinkAt < 1500) return;
    lastDrinkAt = now;
    playPickupSound();
    if(drunkLevel >= 5){
      if(Math.random() < 0.4){
        damageLocalPlayer(25, 'one too many');
        drunkLevel = 3;
        addFeed(myName + ' — the room spins hard. That last one wasn\'t a good idea.', true);
      } else {
        addFeed(myName + ' — the bartender cuts them off. "You\'ve had enough."', false);
      }
      return;
    }
    drunkLevel = Math.min(5, drunkLevel+1);
    addFeed(myName + ' has one too many at the bar', false);
  }

  function throwGrenade(){
    if(grenadeCount <= 0 || !localAlive) return;
    grenadeCount--;
    updateGrenadeUI();
    playThrowSound();
    const origin = camera.position.clone();
    const dir = camera.getWorldDirection(new THREE.Vector3());
    const mesh = new THREE.Mesh(new THREE.SphereGeometry(0.12,8,8), new THREE.MeshStandardMaterial({color:0x2a3a1a, roughness:0.6}));
    mesh.position.copy(origin);
    scene.add(mesh);
    const vel = dir.clone().multiplyScalar(13);
    vel.y += 5;
    grenades.push({mesh, vel, floor: currentFloor, exploded:false});
  }
  function explodeGrenade(pos, floor, remote){
    if(remote){ if(pos.distanceTo(camera.position) < 60) playExplosionSound(); }
    else { playExplosionSound(); net.send('boom', {x:pos.x, y:pos.y, z:pos.z, f:floor}); }
    DMAGfx.flash(pos, 0xffaa33, 6, 26, 380);

    // core fireball
    const burst = new THREE.Mesh(new THREE.SphereGeometry(0.5,14,14), new THREE.MeshBasicMaterial({color:0xffb84a, transparent:true, opacity:0.95}));
    burst.position.copy(pos);
    scene.add(burst);
    let s = 0.5;
    const grow = setInterval(() => {
      s += 1.3; burst.scale.set(s,s,s); burst.material.opacity -= 0.06;
      if(burst.material.opacity <= 0){ clearInterval(grow); scene.remove(burst); }
    }, 20);

    // expanding shockwave ring along the ground
    const ring = new THREE.Mesh(new THREE.RingGeometry(0.4,0.7,32), new THREE.MeshBasicMaterial({color:0xffdd88, transparent:true, opacity:0.85, side:THREE.DoubleSide}));
    ring.rotation.x = -Math.PI/2;
    ring.position.set(pos.x, pos.y-0.3, pos.z);
    scene.add(ring);
    let rs = 1;
    const ringGrow = setInterval(() => {
      rs += 1.6; ring.scale.set(rs,rs,rs); ring.material.opacity -= 0.045;
      if(ring.material.opacity <= 0){ clearInterval(ringGrow); scene.remove(ring); }
    }, 20);

    // billowing smoke plumes
    for(let i=0;i<7;i++){
      const smoke = new THREE.Mesh(new THREE.SphereGeometry(0.35+Math.random()*0.3,8,8), new THREE.MeshBasicMaterial({color:0x3a3a3a, transparent:true, opacity:0.55}));
      smoke.position.set(pos.x+(Math.random()-0.5)*1.2, pos.y+Math.random()*0.5, pos.z+(Math.random()-0.5)*1.2);
      scene.add(smoke);
      const vel = new THREE.Vector3((Math.random()-0.5)*1.2, 1.2+Math.random()*1.2, (Math.random()-0.5)*1.2);
      const born = performance.now();
      const iv = setInterval(() => {
        const age = performance.now()-born;
        if(age > 1400){ clearInterval(iv); scene.remove(smoke); return; }
        smoke.position.addScaledVector(vel, 0.016);
        smoke.scale.multiplyScalar(1.012);
        smoke.material.opacity = 0.55*(1-age/1400);
      }, 16);
    }

    if(remote) return; // visuals only — the thrower deals the damage
    const radius = 11, dmg = 95;
    function distXZ(x,z){ const dx=x-pos.x, dz=z-pos.z; return Math.sqrt(dx*dx+dz*dz); }
    if(floor === 0){
      bots.forEach(bot => {
        if(!bot.alive) return;
        const d = distXZ(bot.group.position.x, bot.group.position.z);
        if(d < radius) damageBot(bot, dmg*(1-d/radius), pos);
      });
    } else {
      creepyFigures.forEach(f => {
        if(!f.alive) return;
        const d = distXZ(f.group.position.x, f.group.position.z);
        if(d < radius) damageCreepyFigure(f, dmg*(1-d/radius), pos);
      });
    }
    if(floor === currentFloor && localAlive){
      const distToMe = distXZ(camera.position.x, camera.position.z);
      if(distToMe < radius) damageLocalPlayer(dmg*(1-distToMe/radius), 'their own grenade');
    }
    for(const id in remotePlayers){
      const e = remotePlayers[id];
      if(!e.group.visible || (e.floor||0) !== floor) continue;
      const d = distXZ(e.group.position.x, e.group.position.z);
      if(d < radius) sendDamage(id, dmg*(1-d/radius));
    }
  }
  const conveyorPizzas = [];
  let pizzaPlaceRoomGroup = null;
  let conveyorPathSegs = null;
  let ovenWorldPos = null;
  let nextConveyorSpawnAt = 0;
  function buildOvalConveyorPath(laneA, laneB, zNear, zFar){
    const radius = Math.abs(laneB-laneA)/2;
    const cx = (laneA+laneB)/2;
    const straightLen = Math.abs(zFar-zNear);
    const arcLen = Math.PI*radius;
    return [
      {len:straightLen, point:(f) => ({x:laneA, z:zNear+(zFar-zNear)*f})},
      {len:arcLen, point:(f) => { const ang = Math.PI - f*Math.PI; return {x:cx+radius*Math.cos(ang), z:zFar+radius*Math.sin(ang)}; }},
      {len:straightLen, point:(f) => ({x:laneB, z:zFar+(zNear-zFar)*f})},
      {len:arcLen, point:(f) => { const ang = 0 - f*Math.PI; return {x:cx+radius*Math.cos(ang), z:zNear+radius*Math.sin(ang)}; }}
    ];
  }
  function getConveyorPoint(t){
    if(!conveyorPathSegs) return {x:0,z:0};
    const segs = conveyorPathSegs;
    const total = segs.reduce((s,seg) => s+seg.len, 0);
    let dist = ((t%1)+1)%1 * total;
    for(let i=0;i<segs.length;i++){
      const seg = segs[i];
      if(dist <= seg.len || i === segs.length-1){
        const f = seg.len > 0 ? Math.max(0,Math.min(1,dist/seg.len)) : 0;
        return seg.point(f);
      }
      dist -= seg.len;
    }
    return segs[0].point(0);
  }
  const PIZZA_HEAL_X = 32, PIZZA_HEAL_Z = -41.3;
  const POP_SPEED_X = 38, POP_SPEED_Z = -44.45;

  function makeFloorTexture(){
    const c = document.createElement('canvas'); c.width=c.height=256;
    const ctx = c.getContext('2d');
    ctx.fillStyle = '#7d7360'; ctx.fillRect(0,0,256,256);
    const tile = 32;
    for(let y=0;y<256;y+=tile){
      for(let x=0;x<256;x+=tile){
        if(((x/tile)+(y/tile))%2===0){ ctx.fillStyle='rgba(0,0,0,0.08)'; ctx.fillRect(x,y,tile,tile); }
      }
    }
    ctx.fillStyle='rgba(0,0,0,0.18)';
    for(let i=0;i<160;i++){ ctx.fillRect(Math.random()*256, Math.random()*256, 2, 2); }
    const tex = new THREE.CanvasTexture(c);
    tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
    tex.repeat.set(ARENA_HALF*2/6, ARENA_HALF*2/6);
    return tex;
  }
  const groundMat = new THREE.MeshStandardMaterial({map:makeFloorTexture(), roughness:0.95});
  const ground = new THREE.Mesh(new THREE.PlaneGeometry(ARENA_HALF*2, ARENA_HALF*2), groundMat);
  ground.rotation.x = -Math.PI/2;
  scene.add(ground);

  const ceilingMat = new THREE.MeshStandardMaterial({color:0x33322c, roughness:0.9, side:THREE.DoubleSide});
  const ceiling = new THREE.Mesh(new THREE.PlaneGeometry(ARENA_HALF*2, ARENA_HALF*2), ceilingMat);
  ceiling.rotation.x = Math.PI/2;
  ceiling.position.y = FLOOR2_Y;
  scene.add(ceiling);

  // tall vaulted skylight roof over the upstairs mezzanine — old-mall metal-and-glass atrium ceiling
  (function buildSkylightRoof(){
    const SKYLIGHT_Y = FLOOR2_Y + 9;
    function makeSkylightGridTexture(){
      const c = document.createElement('canvas'); c.width = 512; c.height = 512;
      const ctx = c.getContext('2d');
      ctx.fillStyle = 'rgba(180,205,215,0.22)'; ctx.fillRect(0,0,512,512);
      ctx.strokeStyle = 'rgba(35,38,42,0.95)'; ctx.lineWidth = 7;
      const cell = 64;
      for(let i=0;i<=512;i+=cell){
        ctx.beginPath(); ctx.moveTo(i,0); ctx.lineTo(i,512); ctx.stroke();
        ctx.beginPath(); ctx.moveTo(0,i); ctx.lineTo(512,i); ctx.stroke();
      }
      ctx.strokeStyle = 'rgba(60,64,68,0.5)'; ctx.lineWidth = 2;
      for(let i=32;i<=512;i+=cell){
        ctx.beginPath(); ctx.moveTo(i,0); ctx.lineTo(i,512); ctx.stroke();
        ctx.beginPath(); ctx.moveTo(0,i); ctx.lineTo(512,i); ctx.stroke();
      }
      return new THREE.CanvasTexture(c);
    }
    const skyTex = makeSkylightGridTexture();
    skyTex.wrapS = skyTex.wrapT = THREE.RepeatWrapping;
    skyTex.repeat.set(8,8);
    const skyMat = new THREE.MeshStandardMaterial({map:skyTex, transparent:true, opacity:0.95, side:THREE.DoubleSide, roughness:0.35, metalness:0.4, emissive:0x8fa8b0, emissiveIntensity:0.35});
    const skylight = new THREE.Mesh(new THREE.PlaneGeometry(ARENA_HALF*2, ARENA_HALF*2), skyMat);
    skylight.rotation.x = Math.PI/2;
    skylight.position.y = SKYLIGHT_Y;
    scene.add(skylight);

    // soft daylight glow washing down from the skylight
    const skyLight = new THREE.HemisphereLight(0xcfe4ee, 0x1a1a1a, 0.6);
    scene.add(skyLight);
    const skyFill = new THREE.PointLight(0xd8ecf5, 0.8, 45);
    skyFill.position.set(0, SKYLIGHT_Y-2, 0);
    scene.add(skyFill);

    // a handful of big structural trusses for visible architecture, running both directions
    const trussMat = new THREE.MeshStandardMaterial({color:0x2a2e32, metalness:0.6, roughness:0.4});
    const trussSpan = ARENA_HALF*2-4;
    [-40,-20,0,20,40].forEach(pos => {
      const beamX = new THREE.Mesh(new THREE.BoxGeometry(trussSpan,0.5,0.5), trussMat);
      beamX.position.set(0, SKYLIGHT_Y-0.4, pos);
      scene.add(beamX);
      const beamZ = new THREE.Mesh(new THREE.BoxGeometry(0.5,0.5,trussSpan), trussMat);
      beamZ.position.set(pos, SKYLIGHT_Y-0.4, 0);
      scene.add(beamZ);
    });
    // corner support columns rising to meet the roof
    [[-48,-48],[48,-48],[-48,48],[48,48],[-48,0],[48,0],[0,-48],[0,48]].forEach(([cx,cz]) => {
      const col = new THREE.Mesh(new THREE.CylinderGeometry(0.35,0.4,SKYLIGHT_Y-FLOOR2_Y-3.4,10), trussMat);
      col.position.set(cx, FLOOR2_Y+3.4+(SKYLIGHT_Y-FLOOR2_Y-3.4)/2, cz);
      scene.add(col);
    });
  })();

  const obstacles = []; // {mesh, x,z,hw,hd}
  const wallMat = new THREE.MeshStandardMaterial({color:0x4a5862, roughness:0.85});
  const coverMat = new THREE.MeshStandardMaterial({color:0x5a4c3a, roughness:0.75});

  function addBox(x,z,w,h,d,mat,tag,floorY){
    floorY = floorY || 0;
    const mesh = new THREE.Mesh(new THREE.BoxGeometry(w,h,d), mat);
    mesh.position.set(x, floorY+h/2, z);
    mesh.userData.type = tag || 'obstacle';
    scene.add(mesh);
    obstacles.push({mesh, x, z, hw:w/2, hd:d/2, floor: floorY>0 ? 1 : 0});
    return mesh;
  }

  function makeSignTexture(text){
    const canvas = document.createElement('canvas');
    canvas.width = 512; canvas.height = 128;
    const ctx = canvas.getContext('2d');
    ctx.fillStyle = 'rgba(24,23,17,0.92)';
    ctx.fillRect(0,0,512,128);
    ctx.strokeStyle = 'rgba(90,85,60,0.6)'; ctx.lineWidth = 4; ctx.strokeRect(4,4,504,120);
    let display = text;
    if(Math.random() < 0.5){
      const chars = display.split('');
      const idxs = [];
      for(let i=0;i<chars.length;i++){ if(/[A-Z]/.test(chars[i])) idxs.push(i); }
      if(idxs.length){ chars[idxs[Math.floor(Math.random()*idxs.length)]] = '_'; display = chars.join(''); }
    }
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    let fontSize = 40;
    ctx.font = '700 '+fontSize+'px Orbitron, sans-serif';
    const maxWidth = 480;
    while(ctx.measureText(display).width > maxWidth && fontSize > 14){
      fontSize -= 2;
      ctx.font = '700 '+fontSize+'px Orbitron, sans-serif';
    }
    ctx.fillStyle = 'rgba(200,190,150,0.85)';
    ctx.fillText(display, 256, 64);
    return new THREE.CanvasTexture(canvas);
  }

  function makeLeaseTexture(){
    const canvas = document.createElement('canvas');
    canvas.width = 300; canvas.height = 220;
    const ctx = canvas.getContext('2d');
    ctx.fillStyle = 'rgba(120,105,75,0.9)';
    ctx.fillRect(0,0,300,220);
    ctx.strokeStyle = 'rgba(60,50,35,0.8)'; ctx.lineWidth = 6; ctx.strokeRect(3,3,294,214);
    ctx.fillStyle = 'rgba(30,28,20,0.85)';
    ctx.font = '700 34px Arial, sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('FOR', 150, 90);
    ctx.fillText('LEASE', 150, 135);
    ctx.font = '400 16px Arial, sans-serif';
    ctx.fillStyle = 'rgba(30,28,20,0.5)';
    ctx.fillText('inquire at management office', 150, 175);
    return new THREE.CanvasTexture(canvas);
  }

  function makeNeonTexture(text, colorCss){
    const canvas = document.createElement('canvas');
    canvas.width = 512; canvas.height = 150;
    const ctx = canvas.getContext('2d');
    ctx.fillStyle = 'rgba(4,4,8,0.96)';
    ctx.fillRect(0,0,512,150);
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    let fontSize = 46;
    ctx.font = '900 '+fontSize+'px Orbitron, sans-serif';
    const maxWidth = 480;
    while(ctx.measureText(text).width > maxWidth && fontSize > 16){
      fontSize -= 2;
      ctx.font = '900 '+fontSize+'px Orbitron, sans-serif';
    }
    ctx.shadowColor = colorCss; ctx.shadowBlur = 28;
    ctx.fillStyle = colorCss;
    ctx.fillText(text, 256, 75);
    ctx.shadowBlur = 8;
    ctx.fillText(text, 256, 75);
    { const __t = new THREE.CanvasTexture(canvas); __t.userData.glow = 2.4; return __t; }
  }

  function makeArcadeScreenTexture(style){
    const c = document.createElement('canvas'); c.width = 128; c.height = 100;
    const ctx = c.getContext('2d');
    ctx.fillStyle = '#000'; ctx.fillRect(0,0,128,100);
    if(style === 0){
      // paddle-and-ball
      ctx.strokeStyle = 'rgba(255,255,255,0.5)'; ctx.setLineDash([4,4]);
      ctx.beginPath(); ctx.moveTo(64,4); ctx.lineTo(64,96); ctx.stroke(); ctx.setLineDash([]);
      ctx.fillStyle = '#fff';
      ctx.fillRect(8,35,4,20); ctx.fillRect(116,45,4,20); ctx.fillRect(60,48,6,6);
      ctx.font = '10px monospace'; ctx.fillText('3', 40, 16); ctx.fillText('2', 82, 16);
    } else if(style === 1){
      // vector shooter
      ctx.strokeStyle = '#5ff'; ctx.lineWidth = 1.5;
      ctx.beginPath(); ctx.moveTo(64,20); ctx.lineTo(74,50); ctx.lineTo(64,80); ctx.lineTo(54,50); ctx.closePath(); ctx.stroke();
      for(let i=0;i<5;i++){
        const cx2 = 14+i*22, cy2 = 20+((i*37)%60);
        ctx.beginPath();
        ctx.moveTo(cx2,cy2); ctx.lineTo(cx2+8,cy2+4); ctx.lineTo(cx2+4,cy2+10); ctx.lineTo(cx2-4,cy2+6); ctx.closePath(); ctx.stroke();
      }
    } else if(style === 2){
      // maze / dot muncher
      ctx.strokeStyle = '#33f'; ctx.lineWidth = 2;
      for(let x=8;x<120;x+=20) ctx.strokeRect(x,8,14,84);
      ctx.fillStyle = '#ff0';
      for(let i=0;i<10;i++) ctx.fillRect(14+(i%5)*20, 20+Math.floor(i/5)*50, 3,3);
    } else if(style === 3){
      // invader rows
      ctx.fillStyle = '#5f5';
      for(let row=0; row<3; row++){
        for(let col=0; col<6; col++){
          ctx.fillRect(10+col*18, 20+row*22, 10,8);
        }
      }
    } else {
      // grid horizon racer
      ctx.strokeStyle = '#f5f'; ctx.lineWidth = 1;
      for(let i=0;i<6;i++){ ctx.beginPath(); ctx.moveTo(64,40); ctx.lineTo(10+i*22,95); ctx.stroke(); }
      ctx.beginPath(); ctx.moveTo(10,95); ctx.lineTo(118,95); ctx.stroke();
    }
    { const __t = new THREE.CanvasTexture(c); __t.userData.glow = 1.7; return __t; }
  }
  function makeWoodTexture(baseColor){
    const c = document.createElement('canvas'); c.width = 64; c.height = 128;
    const ctx = c.getContext('2d');
    ctx.fillStyle = baseColor; ctx.fillRect(0,0,64,128);
    ctx.strokeStyle = 'rgba(0,0,0,0.15)';
    for(let i=0;i<10;i++){
      ctx.beginPath();
      const y = i*13 + Math.random()*4;
      ctx.moveTo(0,y); ctx.bezierCurveTo(20,y+4,44,y-4,64,y);
      ctx.stroke();
    }
    return new THREE.CanvasTexture(c);
  }
  function makeRugTexture(){
    const c = document.createElement('canvas'); c.width = 128; c.height = 170;
    const ctx = c.getContext('2d');
    ctx.fillStyle = '#5a1f2a'; ctx.fillRect(0,0,128,170);
    ctx.strokeStyle = '#d8b060'; ctx.lineWidth = 6;
    ctx.strokeRect(10,10,108,150);
    ctx.strokeStyle = 'rgba(216,176,96,0.4)'; ctx.lineWidth = 2;
    ctx.strokeRect(20,20,88,130);
    ctx.fillStyle = 'rgba(216,176,96,0.3)';
    for(let y=32;y<150;y+=26){
      for(let x=26;x<104;x+=26){
        ctx.beginPath();
        ctx.moveTo(x,y-8); ctx.lineTo(x+8,y); ctx.lineTo(x,y+8); ctx.lineTo(x-8,y);
        ctx.closePath(); ctx.fill();
      }
    }
    return new THREE.CanvasTexture(c);
  }

  function makeCabinetSideArt(colorCssA, colorCssB){
    const c = document.createElement('canvas'); c.width = 64; c.height = 160;
    const ctx = c.getContext('2d');
    const grad = ctx.createLinearGradient(0,0,0,160);
    grad.addColorStop(0, colorCssA); grad.addColorStop(1, colorCssB);
    ctx.fillStyle = grad; ctx.fillRect(0,0,64,160);
    ctx.strokeStyle = 'rgba(255,255,255,0.55)'; ctx.lineWidth = 3;
    for(let i=0;i<6;i++){
      ctx.beginPath();
      ctx.moveTo(0, 15+i*26); ctx.lineTo(64, i*26);
      ctx.stroke();
    }
    ctx.strokeStyle = 'rgba(0,0,0,0.35)'; ctx.lineWidth = 1.5;
    for(let i=0;i<6;i++){
      ctx.beginPath();
      ctx.moveTo(0, 22+i*26); ctx.lineTo(64, 7+i*26);
      ctx.stroke();
    }
    return new THREE.CanvasTexture(c);
  }

  // a genuine 80s upright arcade cabinet: side art, joystick+buttons, recessed screen, arched marquee
  function buildArcadeCabinet(x, z, rotY, accentColor, gameName, screenStyle){
    const group = new THREE.Group();
    const accentCss = '#'+accentColor.toString(16).padStart(6,'0');
    const sideArtTex = makeCabinetSideArt(accentCss, '#0a0a12');
    const bodyMatSide = new THREE.MeshStandardMaterial({map:sideArtTex, roughness:0.5});
    const bodyMatDark = new THREE.MeshStandardMaterial({color:0x141414, roughness:0.6});
    // BoxGeometry material order: [+x,-x,+y,-y,+z,-z]
    const cabinet = new THREE.Mesh(new THREE.BoxGeometry(0.7,1.5,0.6),
      [bodyMatSide, bodyMatSide, bodyMatDark, bodyMatDark, bodyMatDark, bodyMatDark]);
    cabinet.position.y = 0.75; group.add(cabinet);

    const panel = new THREE.Mesh(new THREE.BoxGeometry(0.68,0.12,0.34), new THREE.MeshStandardMaterial({color:0x1c1c1c}));
    panel.position.set(0,0.95,0.42); panel.rotation.x = -0.35; group.add(panel);
    const joystick = new THREE.Mesh(new THREE.CylinderGeometry(0.02,0.02,0.12,6), new THREE.MeshStandardMaterial({color:0x222222}));
    joystick.position.set(-0.15,1.06,0.47); group.add(joystick);
    const joyBall = new THREE.Mesh(new THREE.SphereGeometry(0.035,8,8), new THREE.MeshStandardMaterial({color:accentColor}));
    joyBall.position.set(-0.15,1.12,0.47); group.add(joyBall);
    [0xff4040,0xffe040,0x40a0ff].forEach((bc,i) => {
      const btn = new THREE.Mesh(new THREE.CylinderGeometry(0.025,0.025,0.02,8), new THREE.MeshStandardMaterial({color:bc, emissive:bc, emissiveIntensity:0.35}));
      btn.position.set(0.05+i*0.09,1.0,0.49); btn.rotation.x = -0.35; group.add(btn);
    });

    const bezel = new THREE.Mesh(new THREE.BoxGeometry(0.58,0.5,0.05), new THREE.MeshStandardMaterial({color:0x0c0c0c}));
    bezel.position.set(0,1.3,0.31); group.add(bezel);
    const screen = new THREE.Mesh(new THREE.PlaneGeometry(0.48,0.38), new THREE.MeshBasicMaterial({map: makeArcadeScreenTexture(screenStyle)}));
    screen.position.set(0,1.3,0.335); group.add(screen);

    const marqueeBase = new THREE.Mesh(new THREE.BoxGeometry(0.74,0.28,0.42), new THREE.MeshStandardMaterial({color:0x141414}));
    marqueeBase.position.set(0,1.64,0.05); group.add(marqueeBase);
    const marqueeGlass = new THREE.Mesh(new THREE.PlaneGeometry(0.62,0.22), new THREE.MeshBasicMaterial({map: makeNeonTexture(gameName, accentCss)}));
    marqueeGlass.position.set(0,1.64,0.27); group.add(marqueeGlass);

    group.position.set(x,0,z);
    group.rotation.y = rotY;
    return group;
  }

  function buildAnimatronic(x, z, color, kind){
    const group = new THREE.Group();
    const mat = new THREE.MeshStandardMaterial({color, roughness:0.75});
    const torso = new THREE.Mesh(new THREE.CylinderGeometry(0.32,0.4,0.85,8), mat);
    torso.position.y = 0.75; group.add(torso);
    const headPivot = new THREE.Group();
    headPivot.position.set(0, 1.35, 0);
    group.add(headPivot);
    const head = new THREE.Mesh(new THREE.SphereGeometry(0.32,10,10), mat);
    headPivot.add(head);
    if(kind === 'rabbit'){
      const earGeo = new THREE.CylinderGeometry(0.06,0.09,0.5,6);
      const earL = new THREE.Mesh(earGeo, mat); earL.position.set(0.12,0.4,0); earL.rotation.z=-0.15; headPivot.add(earL);
      const earR = new THREE.Mesh(earGeo, mat); earR.position.set(-0.12,0.4,0); earR.rotation.z=0.15; headPivot.add(earR);
    } else {
      const earL = new THREE.Mesh(new THREE.SphereGeometry(0.11,6,6), mat); earL.position.set(0.26,0.27,0); headPivot.add(earL);
      const earR = new THREE.Mesh(new THREE.SphereGeometry(0.11,6,6), mat); earR.position.set(-0.26,0.27,0); headPivot.add(earR);
    }
    const eyeMat = new THREE.MeshStandardMaterial({color:0xffffff, emissive:0xff3030, emissiveIntensity:0.9});
    const eyeL = new THREE.Mesh(new THREE.SphereGeometry(0.055,6,6), eyeMat); eyeL.position.set(0.12,0.03,0.27); headPivot.add(eyeL);
    const eyeR = new THREE.Mesh(new THREE.SphereGeometry(0.055,6,6), eyeMat); eyeR.position.set(-0.12,0.03,0.27); headPivot.add(eyeR);
    const armPivotL = new THREE.Group(); armPivotL.position.set(0.42,1.15,0); group.add(armPivotL);
    const armL = new THREE.Mesh(new THREE.CylinderGeometry(0.08,0.09,0.7,6), mat);
    armL.position.set(0,-0.35,0); armL.rotation.z = -1.1; armPivotL.add(armL);
    const armPivotR = new THREE.Group(); armPivotR.position.set(-0.42,1.0,0); group.add(armPivotR);
    const armR = new THREE.Mesh(new THREE.CylinderGeometry(0.08,0.09,0.7,6), mat);
    armR.position.set(0,-0.35,0); armR.rotation.z = 0.15; armPivotR.add(armR);
    const legL = new THREE.Mesh(new THREE.CylinderGeometry(0.11,0.13,0.7,6), mat); legL.position.set(0.14,0.35,0); group.add(legL);
    const legR = new THREE.Mesh(new THREE.CylinderGeometry(0.11,0.13,0.7,6), mat); legR.position.set(-0.14,0.35,0); group.add(legR);
    group.position.set(x, 0.3, z);
    return {group, headPivot, armPivotL, armPivotR, baseArmRotL:-1.1, baseArmRotR:0.15, phase: Math.random()*10};
  }

  function makeBackglassTexture(colorCss, name){
    const c = document.createElement('canvas'); c.width = 200; c.height = 240;
    const ctx = c.getContext('2d');
    ctx.fillStyle = '#0a0a12'; ctx.fillRect(0,0,200,240);
    ctx.strokeStyle = colorCss; ctx.lineWidth = 3;
    for(let i=0;i<6;i++){
      ctx.beginPath();
      ctx.moveTo(100,120);
      const ang = (i/6)*Math.PI*2;
      ctx.lineTo(100+Math.cos(ang)*90, 120+Math.sin(ang)*110);
      ctx.stroke();
    }
    ctx.fillStyle = colorCss;
    ctx.font = '900 22px Orbitron, sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText(name, 100, 40);
    ctx.font = '13px monospace';
    ctx.fillStyle = '#ffffff';
    ctx.fillText('HIGH SCORE', 100, 210);
    ctx.fillText('000000', 100, 226);
    { const __t = new THREE.CanvasTexture(c); __t.userData.glow = 1.5; return __t; }
  }
  function makeTeethTexture(){
    const c = document.createElement('canvas'); c.width = 128; c.height = 64;
    const ctx = c.getContext('2d');
    ctx.clearRect(0,0,128,64);
    ctx.fillStyle = '#e8e4d8';
    ctx.beginPath();
    ctx.moveTo(6,20);
    for(let i=0;i<10;i++){ ctx.lineTo(6+i*11.6, i%2===0?12:34); }
    ctx.lineTo(122,20); ctx.lineTo(122,44);
    for(let i=9;i>=0;i--){ ctx.lineTo(6+i*11.6, i%2===0?40:20); }
    ctx.closePath();
    ctx.fill();
    return new THREE.CanvasTexture(c);
  }

  function buildCreepyFigure(x, z, rotY){
    const group = new THREE.Group();
    const suitMat = new THREE.MeshStandardMaterial({color:0x0d0d10, roughness:0.7});
    const skinMat = new THREE.MeshStandardMaterial({color:0x3a3a3a, roughness:0.8});
    const legL = new THREE.Mesh(new THREE.CylinderGeometry(0.13,0.15,1.7,8), suitMat); legL.position.set(0.16,0.85,0); group.add(legL);
    const legR = new THREE.Mesh(new THREE.CylinderGeometry(0.13,0.15,1.7,8), suitMat); legR.position.set(-0.16,0.85,0); group.add(legR);
    const torso = new THREE.Mesh(new THREE.BoxGeometry(0.72,1.3,0.32), suitMat); torso.position.y = 2.35; group.add(torso);
    const armL = new THREE.Mesh(new THREE.CylinderGeometry(0.09,0.11,1.7,8), suitMat); armL.position.set(0.5,1.85,0); armL.rotation.z = 0.06; group.add(armL);
    const armR = new THREE.Mesh(new THREE.CylinderGeometry(0.09,0.11,1.7,8), suitMat); armR.position.set(-0.5,1.85,0); armR.rotation.z = -0.06; group.add(armR);
    const handL = new THREE.Mesh(new THREE.SphereGeometry(0.1,6,6), skinMat); handL.position.set(0.54,1.0,0); group.add(handL);
    const handR = new THREE.Mesh(new THREE.SphereGeometry(0.1,6,6), skinMat); handR.position.set(-0.54,1.0,0); group.add(handR);
    const head = new THREE.Mesh(new THREE.SphereGeometry(0.26,10,10), skinMat); head.scale.set(0.85,1.25,0.9); head.position.y = 3.15; group.add(head);
    const eyeMatL = new THREE.MeshStandardMaterial({color:0x1a0505, emissive:0xff0000, emissiveIntensity:0.05});
    const eyeMatR = new THREE.MeshStandardMaterial({color:0x1a0505, emissive:0xff0000, emissiveIntensity:0.05});
    const eyeL = new THREE.Mesh(new THREE.SphereGeometry(0.045,6,6), eyeMatL); eyeL.position.set(0.09,3.18,0.22); group.add(eyeL);
    const eyeR = new THREE.Mesh(new THREE.SphereGeometry(0.045,6,6), eyeMatR); eyeR.position.set(-0.09,3.18,0.22); group.add(eyeR);
    const teethMat = new THREE.MeshBasicMaterial({map: makeTeethTexture(), transparent:true, opacity:0});
    const teeth = new THREE.Mesh(new THREE.PlaneGeometry(0.32,0.16), teethMat);
    teeth.position.set(0,3.0,0.24);
    group.add(teeth);
    group.position.set(x,0,z);
    group.rotation.y = rotY;
    const bodyMeshes = [legL, legR, torso, armL, armR, handL, handR, head];
    return {group, eyeL, eyeR, teeth, bodyMeshes, health:100, maxHealth:100, alive:true, originalX:x, originalZ:z, respawnAt:0};
  }
  function registerCreepyFigure(f){
    creepyFigures.push(f);
    f.bodyMeshes.forEach(m => shootables.push({mesh:m, kind:'creepy', ref:f}));
  }
  function damageCreepyFigure(f, amount, hitPoint){
    if(!f.alive) return;
    f.health -= amount;
    if(hitPoint) spawnBlood(hitPoint, 0x4a0a0a);
    if(f.health <= 0){
      f.alive = false;
      f.group.visible = false;
      f.respawnAt = performance.now() + 14000;
      addFeed(myName + ' put down something that shouldn\'t exist', false);
      playKillSound();
    }
  }

  function buildPinball(x, z, rotY, color){
    const colorCss = '#'+color.toString(16).padStart(6,'0');
    const group = new THREE.Group();
    const woodTex = makeWoodTexture('#4a2c1a');
    const cab = new THREE.Mesh(new THREE.BoxGeometry(0.65,1.0,0.8), new THREE.MeshStandardMaterial({map:woodTex, roughness:0.7}));
    cab.position.y = 0.65; group.add(cab);
    const playfield = new THREE.Mesh(new THREE.BoxGeometry(0.6,0.05,0.75), new THREE.MeshStandardMaterial({color:0x101010, roughness:0.3}));
    playfield.position.set(0,1.05,0.05); playfield.rotation.x = -0.25; group.add(playfield);
    const bumperColors = [0xff4040, 0xffe040, 0x40ff80];
    for(let i=0;i<3;i++){
      const bumper = new THREE.Mesh(new THREE.CylinderGeometry(0.05,0.05,0.04,10), new THREE.MeshStandardMaterial({color:bumperColors[i], emissive:bumperColors[i], emissiveIntensity:0.5}));
      bumper.position.set((i-1)*0.16, 1.09-((i-1)*0.16*0.25), 0.02+i*0.12);
      group.add(bumper);
    }
    const back = new THREE.Mesh(new THREE.BoxGeometry(0.62,0.75,0.06), new THREE.MeshBasicMaterial({map: makeBackglassTexture(colorCss, 'GALAXY QUEST')}));
    back.position.set(0,1.55,-0.35); back.rotation.x = -0.15; group.add(back);
    const legGeo = new THREE.CylinderGeometry(0.04,0.05,0.65,6);
    [[0.25,0.3],[-0.25,0.3],[0.25,-0.3],[-0.25,-0.3]].forEach(([lx,lz]) => {
      const leg = new THREE.Mesh(legGeo, new THREE.MeshStandardMaterial({color:0x111111}));
      leg.position.set(lx,0.32,lz); group.add(leg);
    });
    group.position.set(x,0,z);
    group.rotation.y = rotY;
    return group;
  }

  function buildPizzaRobot(x, z){
    const base = new THREE.Group();
    const table = new THREE.Mesh(new THREE.BoxGeometry(1.0,0.85,0.8), new THREE.MeshStandardMaterial({color:0xd8d8dc, roughness:0.4, metalness:0.3}));
    table.position.y = 0.425; base.add(table);
    const dough = new THREE.Mesh(new THREE.CylinderGeometry(0.28,0.28,0.06,20), new THREE.MeshStandardMaterial({color:0xe8c473, roughness:0.7}));
    dough.position.y = 0.88; base.add(dough);
    for(let i=0;i<6;i++){
      const ang = (i/6)*Math.PI*2;
      const pep = new THREE.Mesh(new THREE.CylinderGeometry(0.05,0.05,0.02,8), new THREE.MeshStandardMaterial({color:0xa33020}));
      pep.position.set(Math.cos(ang)*0.17, 0.91, Math.sin(ang)*0.17);
      base.add(pep);
    }
    const mountPost = new THREE.Mesh(new THREE.CylinderGeometry(0.06,0.08,0.9,8), new THREE.MeshStandardMaterial({color:0x555555, metalness:0.6}));
    mountPost.position.set(0,1.3,-0.35); base.add(mountPost);

    const shoulderPivot = new THREE.Group();
    shoulderPivot.position.set(0,1.75,-0.35);
    base.add(shoulderPivot);
    const shoulderJoint = new THREE.Mesh(new THREE.SphereGeometry(0.09,8,8), new THREE.MeshStandardMaterial({color:0x888888, metalness:0.7}));
    shoulderPivot.add(shoulderJoint);
    const upperArm = new THREE.Mesh(new THREE.BoxGeometry(0.12,0.5,0.12), new THREE.MeshStandardMaterial({color:0xcc3333, metalness:0.4, roughness:0.4}));
    upperArm.position.set(0,-0.25,0);
    shoulderPivot.add(upperArm);

    const elbowPivot = new THREE.Group();
    elbowPivot.position.set(0,-0.5,0);
    shoulderPivot.add(elbowPivot);
    const elbowJoint = new THREE.Mesh(new THREE.SphereGeometry(0.07,8,8), new THREE.MeshStandardMaterial({color:0x888888, metalness:0.7}));
    elbowPivot.add(elbowJoint);
    const forearm = new THREE.Mesh(new THREE.BoxGeometry(0.1,0.45,0.1), new THREE.MeshStandardMaterial({color:0xaaaaaa, metalness:0.6, roughness:0.3}));
    forearm.position.set(0,-0.225,0);
    elbowPivot.add(forearm);
    const gripper = new THREE.Mesh(new THREE.BoxGeometry(0.24,0.05,0.16), new THREE.MeshStandardMaterial({color:0x333333}));
    gripper.position.set(0,-0.47,0);
    elbowPivot.add(gripper);
    const heldPizza = new THREE.Mesh(new THREE.CylinderGeometry(0.2,0.2,0.045,14), new THREE.MeshStandardMaterial({color:0xe8c473, roughness:0.6, emissive:0xffae3d, emissiveIntensity:0.15}));
    heldPizza.position.set(0,-0.52,0);
    elbowPivot.add(heldPizza);

    base.position.set(x,0,z);
    return {group:base, shoulderPivot, elbowPivot, heldPizza};
  }

  function buildPizzaPlace(yOffset){
    yOffset = yOffset || 0;
    const cx = 35, cz = -35, w = 18, d = 20, h = 3.4;
    const roomGroup = new THREE.Group();
    roomGroup.position.set(0, yOffset, 0);
    scene.add(roomGroup);
    const pizzaWallMat = new THREE.MeshStandardMaterial({color:0x2a1c18, roughness:0.85});
    addBox(cx, cz-d/2, w, h, 0.4, pizzaWallMat, 'wall', yOffset);
    addBox(cx-w/2, cz, 0.4, h, d, pizzaWallMat, 'wall', yOffset);
    addBox(cx+w/2, cz, 0.4, h, d, pizzaWallMat, 'wall', yOffset);

    const neonTex = makeNeonTexture('STARLITE PIZZA CAFE', '#ffcf2f');
    const neonMat = new THREE.MeshBasicMaterial({map:neonTex, transparent:true, side:THREE.DoubleSide});
    const neonSign = new THREE.Mesh(new THREE.PlaneGeometry(w*0.65, 1.0), neonMat);
    neonSign.position.set(cx, h+0.1, cz+d/2);
    roomGroup.add(neonSign);
    const neonLight = new THREE.PointLight(0xffcf2f, 1.5, 13);
    neonLight.position.set(cx, h, cz+d/2-0.3);
    roomGroup.add(neonLight);
    (function scheduleNeonFlicker(){
      const delay = 400 + Math.random()*3500;
      setTimeout(() => {
        const dim = Math.random() < 0.3;
        neonLight.intensity = dim ? 0.2 : 1.5;
        neonMat.opacity = dim ? 0.4 : 1;
        scheduleNeonFlicker();
      }, delay);
    })();

    const popTex = makeNeonTexture('ICE COLD POP', '#ff5c3d');
    const popMat = new THREE.MeshBasicMaterial({map:popTex, transparent:true, side:THREE.DoubleSide});
    const popSign = new THREE.Mesh(new THREE.PlaneGeometry(2.6, 0.5), popMat);
    popSign.position.set(cx-w/2+0.3, 2.3, cz-d/2+3); popSign.rotation.y = Math.PI/2;
    roomGroup.add(popSign);

    // pizza counter + display (also the health recharge station)
    const counterX = cx-3, counterZ = cz-d/2+2.6;
    const counter = new THREE.Mesh(new THREE.BoxGeometry(3.2,0.9,0.8), new THREE.MeshStandardMaterial({color:0x3a2a20, roughness:0.6}));
    counter.position.set(counterX, 0.45, counterZ);
    roomGroup.add(counter);
    const pizza = new THREE.Mesh(new THREE.CylinderGeometry(0.48,0.48,0.08,20), new THREE.MeshStandardMaterial({color:0xe8c473, roughness:0.6}));
    pizza.position.set(counterX, 0.94, counterZ);
    roomGroup.add(pizza);
    for(let i=0;i<7;i++){
      const ang = (i/7)*Math.PI*2;
      const pep = new THREE.Mesh(new THREE.CylinderGeometry(0.07,0.07,0.03,8), new THREE.MeshStandardMaterial({color:0xa33020}));
      pep.position.set(counterX+Math.cos(ang)*0.27, 0.99, counterZ+Math.sin(ang)*0.27);
      roomGroup.add(pep);
    }
    const lampCone = new THREE.Mesh(new THREE.ConeGeometry(0.16,0.2,8), new THREE.MeshStandardMaterial({color:0x552222, emissive:0xff6622, emissiveIntensity:0.6}));
    lampCone.position.set(counterX, 1.5, counterZ); lampCone.rotation.x = Math.PI;
    roomGroup.add(lampCone);
    // kitchen light — the back of this room is otherwise unlit, which was hiding the bar and robot in the dark
    const kitchenLight = new THREE.PointLight(0xffb060, 1.1, 9);
    kitchenLight.position.set(counterX, 2.0, cz-d/2+1.3);
    roomGroup.add(kitchenLight);
    const healBeacon = new THREE.Mesh(new THREE.RingGeometry(1.6,1.85,24), new THREE.MeshBasicMaterial({color:0x37d67a, transparent:true, opacity:0.5, side:THREE.DoubleSide}));
    healBeacon.rotation.x = -Math.PI/2; healBeacon.position.set(counterX, 0.02, counterZ+1.1);
    roomGroup.add(healBeacon);
    pizzaSliceMesh = new THREE.Mesh(new THREE.ConeGeometry(0.26,0.07,3), new THREE.MeshStandardMaterial({color:0xe8c473, emissive:0xffae3d, emissiveIntensity:0.4, roughness:0.6}));
    pizzaSliceMesh.rotation.x = Math.PI/2;
    pizzaSliceMesh.position.set(counterX, 1.0, counterZ+1.1);
    roomGroup.add(pizzaSliceMesh);

    // "FRESH PIZZA — MADE BY ROBOT" sign over the kitchen
    const kitchenSignTex = makeNeonTexture('MADE BY ROBOT', '#ffcf2f');
    const kitchenSign = new THREE.Mesh(new THREE.PlaneGeometry(2.2, 0.45), new THREE.MeshBasicMaterial({map:kitchenSignTex, transparent:true, side:THREE.DoubleSide}));
    kitchenSign.position.set(counterX, 2.35, cz-d/2+0.45);
    roomGroup.add(kitchenSign);

    // pizza bar: a serving counter lined with finished pizzas, right in front of the kitchen
    const barZ = cz-d/2+1.6;
    const bar = new THREE.Mesh(new THREE.BoxGeometry(3.6,0.85,0.6), new THREE.MeshStandardMaterial({color:0x2a2018, roughness:0.6}));
    bar.position.set(counterX, 0.425, barZ);
    roomGroup.add(bar);
    const toppingColors = [0xa33020, 0x6a8a3a, 0xd8d040, 0xa33020];
    for(let p=0;p<4;p++){
      const px = counterX + (p-1.5)*0.85;
      const barPizza = new THREE.Mesh(new THREE.CylinderGeometry(0.32,0.32,0.06,18), new THREE.MeshStandardMaterial({color:0xe8c473, roughness:0.6}));
      barPizza.position.set(px, 0.885, barZ);
      roomGroup.add(barPizza);
      for(let i=0;i<5;i++){
        const ang = (i/5)*Math.PI*2 + p;
        const topping = new THREE.Mesh(new THREE.CylinderGeometry(0.045,0.045,0.025,6), new THREE.MeshStandardMaterial({color:toppingColors[p]}));
        topping.position.set(px+Math.cos(ang)*0.17, 0.92, barZ+Math.sin(ang)*0.17);
        roomGroup.add(topping);
      }
    }

    // robot pizza-maker, working the kitchen right behind the bar
    const robot = buildPizzaRobot(counterX, cz-d/2+0.9);
    roomGroup.add(robot.group);
    pizzaRobots.push(robot);

    // oven — the robot's pizzas come out of here before hitting the belt
    const ovenX = counterX-1.5, ovenZ = cz-d/2+0.9;
    const ovenGroup = new THREE.Group();
    const ovenBody = new THREE.Mesh(new THREE.BoxGeometry(1.0,1.1,0.9), new THREE.MeshStandardMaterial({color:0x2a2a2a, roughness:0.5, metalness:0.4}));
    ovenBody.position.y = 0.55; ovenGroup.add(ovenBody);
    const ovenDoorFrame = new THREE.Mesh(new THREE.BoxGeometry(0.7,0.6,0.05), new THREE.MeshStandardMaterial({color:0x111111}));
    ovenDoorFrame.position.set(0,0.55,0.46); ovenGroup.add(ovenDoorFrame);
    const ovenGlow = new THREE.Mesh(new THREE.PlaneGeometry(0.58,0.48), new THREE.MeshBasicMaterial({color:0xff6622}));
    ovenGlow.position.set(0,0.55,0.485); ovenGroup.add(ovenGlow);
    const ovenLight = new THREE.PointLight(0xff6622, 0.5, 3);
    ovenLight.position.set(0,0.55,0.6); ovenGroup.add(ovenLight);
    ovenGroup.position.set(ovenX, 0, ovenZ);
    roomGroup.add(ovenGroup);

    // conveyor belt loop, from the kitchen all the way out to the front of the store — rounded corners so it reads as a real belt, not sharp right angles
    const laneA = cx-w/2+3, laneB = cx+w/2-4;
    const kitchenZ = cz-d/2+1, frontZ = cz+d/2-1;
    function buildRoundedRectPath(x0,x1,z0,z1,r){
      const straightX = x1-x0-2*r, straightZ = z1-z0-2*r;
      const arcLen = (Math.PI/2)*r;
      function arcSeg(acx,acz,a0,a1){ return {len:arcLen, point:(f) => { const a=a0+(a1-a0)*f; return {x:acx+r*Math.cos(a), z:acz+r*Math.sin(a)}; }}; }
      return [
        {len:straightZ, point:(f) => ({x:x0, z:z0+r+straightZ*f})},
        arcSeg(x0+r, z1-r, Math.PI, Math.PI/2),
        {len:straightX, point:(f) => ({x:x0+r+straightX*f, z:z1})},
        arcSeg(x1-r, z1-r, Math.PI/2, 0),
        {len:straightZ, point:(f) => ({x:x1, z:z1-r-straightZ*f})},
        arcSeg(x1-r, z0+r, 0, -Math.PI/2),
        {len:straightX, point:(f) => ({x:x1-r-straightX*f, z:z0})},
        arcSeg(x0+r, z0+r, -Math.PI/2, -Math.PI)
      ];
    }
    const beltPathSegs = buildRoundedRectPath(laneA, laneB, kitchenZ, frontZ, 1.8);
    const beltMat = new THREE.MeshStandardMaterial({color:0x2a2a2a, roughness:0.6, metalness:0.3});
    const railMat = new THREE.MeshStandardMaterial({color:0x8a8a8a, metalness:0.6, roughness:0.3});
    function drawBeltSegment(seg, subdivisions){
      let prev = seg.point(0);
      for(let i=1;i<=subdivisions;i++){
        const cur = seg.point(i/subdivisions);
        const len = Math.hypot(cur.x-prev.x, cur.z-prev.z);
        if(len > 0.001){
          const ang = Math.atan2(cur.x-prev.x, cur.z-prev.z);
          const midX = (prev.x+cur.x)/2, midZ = (prev.z+cur.z)/2;
          const belt = new THREE.Mesh(new THREE.BoxGeometry(0.5,0.08,len+0.02), beltMat);
          belt.position.set(midX, 0.75, midZ); belt.rotation.y = ang;
          roomGroup.add(belt);
          const railL = new THREE.Mesh(new THREE.BoxGeometry(0.05,0.1,len+0.02), railMat);
          railL.position.set(midX+Math.cos(ang)*0.24, 0.83, midZ-Math.sin(ang)*0.24); railL.rotation.y = ang;
          roomGroup.add(railL);
          const railR = new THREE.Mesh(new THREE.BoxGeometry(0.05,0.1,len+0.02), railMat);
          railR.position.set(midX-Math.cos(ang)*0.24, 0.83, midZ+Math.sin(ang)*0.24); railR.rotation.y = ang;
          roomGroup.add(railR);
        }
        prev = cur;
      }
    }
    beltPathSegs.forEach((seg,i) => drawBeltSegment(seg, i%2===1 ? 8 : 1));
    pizzaPlaceRoomGroup = roomGroup;
    conveyorPathSegs = beltPathSegs;
    ovenWorldPos = {x:ovenX, z:ovenZ, y: yOffset};

    // soda machine (speed recharge station)
    const sodaX = cx+3, sodaZ = cz-d/2+0.55;
    const sodaBody = new THREE.Mesh(new THREE.BoxGeometry(0.7,1.7,0.6), new THREE.MeshStandardMaterial({color:0xb02818, roughness:0.4}));
    sodaBody.position.set(sodaX, 0.85, sodaZ);
    roomGroup.add(sodaBody);
    const sodaPanel = new THREE.Mesh(new THREE.PlaneGeometry(0.55,1.3), new THREE.MeshBasicMaterial({color:0xd8f4ff}));
    sodaPanel.position.set(sodaX, 0.9, sodaZ+0.31);
    roomGroup.add(sodaPanel);
    const speedBeacon = new THREE.Mesh(new THREE.RingGeometry(1.6,1.85,24), new THREE.MeshBasicMaterial({color:0x3dd6ff, transparent:true, opacity:0.5, side:THREE.DoubleSide}));
    speedBeacon.rotation.x = -Math.PI/2; speedBeacon.position.set(sodaX, 0.02, sodaZ+1.1);
    roomGroup.add(speedBeacon);
    sodaCanMesh = new THREE.Group();
    const canBody = new THREE.Mesh(new THREE.CylinderGeometry(0.14,0.14,0.32,12), new THREE.MeshStandardMaterial({color:0xd81e2c, metalness:0.6, roughness:0.3, emissive:0xd81e2c, emissiveIntensity:0.25}));
    canBody.position.x = -0.2;
    sodaCanMesh.add(canBody);
    const canStripe = new THREE.Mesh(new THREE.CylinderGeometry(0.145,0.145,0.08,12), new THREE.MeshStandardMaterial({color:0xffffff}));
    canStripe.position.set(-0.2, 0.05, 0); sodaCanMesh.add(canStripe);
    // Mountain Dew can, right next to the cola
    const dewBody = new THREE.Mesh(new THREE.CylinderGeometry(0.14,0.14,0.32,12), new THREE.MeshStandardMaterial({color:0x3fae2a, metalness:0.6, roughness:0.3, emissive:0x3fae2a, emissiveIntensity:0.25}));
    dewBody.position.x = 0.2;
    sodaCanMesh.add(dewBody);
    const dewStripe = new THREE.Mesh(new THREE.CylinderGeometry(0.145,0.145,0.08,12), new THREE.MeshStandardMaterial({color:0xe8ff4a}));
    dewStripe.position.set(0.2, 0.05, 0); sodaCanMesh.add(dewStripe);
    sodaCanMesh.position.set(sodaX, 1.0, sodaZ+1.1);
    roomGroup.add(sodaCanMesh);

    function addDinerTable(x,z){
      const top = new THREE.Mesh(new THREE.CylinderGeometry(0.45,0.45,0.05,16), new THREE.MeshStandardMaterial({color:0xcf3f3f, roughness:0.5}));
      top.position.set(x,0.72,z); roomGroup.add(top);
      const leg = new THREE.Mesh(new THREE.CylinderGeometry(0.06,0.08,0.7,8), new THREE.MeshStandardMaterial({color:0x2a2a2a}));
      leg.position.set(x,0.35,z); roomGroup.add(leg);
      for(let i=0;i<3;i++){
        const ang = (i/3)*Math.PI*2 + 0.4;
        const stoolTop = new THREE.Mesh(new THREE.CylinderGeometry(0.18,0.18,0.05,10), new THREE.MeshStandardMaterial({color:0x2a2a2a}));
        stoolTop.position.set(x+Math.cos(ang)*0.75, 0.5, z+Math.sin(ang)*0.75);
        roomGroup.add(stoolTop);
        const stoolLeg = new THREE.Mesh(new THREE.CylinderGeometry(0.04,0.05,0.5,6), new THREE.MeshStandardMaterial({color:0x1a1a1a}));
        stoolLeg.position.set(x+Math.cos(ang)*0.75, 0.25, z+Math.sin(ang)*0.75);
        roomGroup.add(stoolLeg);
      }
    }
    [[cx-5,cz+4],[cx-1,cz+4],[cx+3,cz+4],[cx-5,cz+8],[cx-1,cz+8],[cx+3,cz+8]].forEach(([tx,tz]) => addDinerTable(tx,tz));

    const roomCeiling = new THREE.Mesh(new THREE.PlaneGeometry(w+2, d+2), new THREE.MeshStandardMaterial({color:0x2a2820, roughness:0.9, side:THREE.DoubleSide}));
    roomCeiling.rotation.x = Math.PI/2;
    roomCeiling.position.set(cx, h+0.3, cz);
    roomGroup.add(roomCeiling);
  }

  function buildCouch(x,z,rotY,color){
    const group = new THREE.Group();
    const mat = new THREE.MeshStandardMaterial({color, roughness:0.85});
    const base = new THREE.Mesh(new THREE.BoxGeometry(1.8,0.4,0.8), mat);
    base.position.y = 0.2; group.add(base);
    const back = new THREE.Mesh(new THREE.BoxGeometry(1.8,0.5,0.2), mat);
    back.position.set(0,0.55,-0.3); group.add(back);
    const armL = new THREE.Mesh(new THREE.BoxGeometry(0.2,0.5,0.8), mat);
    armL.position.set(-0.8,0.45,0); group.add(armL);
    const armR = new THREE.Mesh(new THREE.BoxGeometry(0.2,0.5,0.8), mat);
    armR.position.set(0.8,0.45,0); group.add(armR);
    for(let i=0;i<3;i++){
      const cushion = new THREE.Mesh(new THREE.BoxGeometry(0.5,0.18,0.7), mat);
      cushion.position.set(-0.55+i*0.55, 0.5, 0.02); group.add(cushion);
    }
    group.position.set(x,0,z); group.rotation.y = rotY;
    return group;
  }
  function buildCoffeeTable(x,z){
    const group = new THREE.Group();
    const top = new THREE.Mesh(new THREE.BoxGeometry(1.0,0.06,0.6), new THREE.MeshStandardMaterial({color:0x4a3220, roughness:0.5}));
    top.position.y = 0.42; group.add(top);
    const legGeo = new THREE.CylinderGeometry(0.03,0.03,0.4,6);
    [[-0.42,-0.22],[0.42,-0.22],[-0.42,0.22],[0.42,0.22]].forEach(([lx,lz]) => {
      const leg = new THREE.Mesh(legGeo, new THREE.MeshStandardMaterial({color:0x2a1a10}));
      leg.position.set(lx,0.2,lz); group.add(leg);
    });
    group.position.set(x,0,z);
    return group;
  }
  function buildFloorLamp(x,z){
    const group = new THREE.Group();
    const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.03,0.04,1.4,8), new THREE.MeshStandardMaterial({color:0x333333}));
    pole.position.y = 0.7; group.add(pole);
    const shade = new THREE.Mesh(new THREE.ConeGeometry(0.25,0.35,12,1,true), new THREE.MeshStandardMaterial({color:0xf0e0c0, emissive:0xffedc0, emissiveIntensity:0.4, side:THREE.DoubleSide}));
    shade.position.y = 1.5; group.add(shade);
    group.position.set(x,0,z);
    return group;
  }
  function addRug(x,z,w,d,color){
    const rug = new THREE.Mesh(new THREE.PlaneGeometry(w,d), new THREE.MeshStandardMaterial({color, roughness:1}));
    rug.rotation.x = -Math.PI/2; rug.position.set(x,0.02,z);
    return rug;
  }

  function buildKidsBed(x,z,rotY,color){
    const group = new THREE.Group();
    const frame = new THREE.Mesh(new THREE.BoxGeometry(1.0,0.25,1.8), new THREE.MeshStandardMaterial({color:0x8a6a4a, roughness:0.6}));
    frame.position.y = 0.2; group.add(frame);
    const mattress = new THREE.Mesh(new THREE.BoxGeometry(0.92,0.15,1.7), new THREE.MeshStandardMaterial({color:0xe8e4d8, roughness:0.8}));
    mattress.position.y = 0.4; group.add(mattress);
    const pillow = new THREE.Mesh(new THREE.BoxGeometry(0.6,0.1,0.35), new THREE.MeshStandardMaterial({color:0xffffff, roughness:0.9}));
    pillow.position.set(0,0.5,-0.65); group.add(pillow);
    const blanket = new THREE.Mesh(new THREE.BoxGeometry(0.92,0.06,1.0), new THREE.MeshStandardMaterial({color, roughness:0.85}));
    blanket.position.set(0,0.49,0.35); group.add(blanket);
    const headboard = new THREE.Mesh(new THREE.BoxGeometry(1.0,0.6,0.08), new THREE.MeshStandardMaterial({color:0x7a5a3a, roughness:0.6}));
    headboard.position.set(0,0.5,-0.87); group.add(headboard);
    group.position.set(x,0,z); group.rotation.y = rotY;
    return group;
  }
  function buildCrib(x,z,rotY){
    const group = new THREE.Group();
    const base = new THREE.Mesh(new THREE.BoxGeometry(0.7,0.1,1.1), new THREE.MeshStandardMaterial({color:0xe8e4d0}));
    base.position.y = 0.35; group.add(base);
    const railMat = new THREE.MeshStandardMaterial({color:0xd8d4c0, roughness:0.5});
    for(let side=-1; side<=1; side+=2){
      for(let i=0;i<6;i++){
        const bar = new THREE.Mesh(new THREE.CylinderGeometry(0.015,0.015,0.5,6), railMat);
        bar.position.set(side*0.33, 0.6, -0.48+i*0.19);
        group.add(bar);
      }
    }
    const legGeo = new THREE.CylinderGeometry(0.025,0.03,0.35,6);
    [[0.3,0.5],[-0.3,0.5],[0.3,-0.5],[-0.3,-0.5]].forEach(([lx,lz]) => {
      const leg = new THREE.Mesh(legGeo, railMat); leg.position.set(lx,0.17,lz); group.add(leg);
    });
    group.position.set(x,0,z); group.rotation.y = rotY;
    return group;
  }
  function buildKidsDresser(x,z,rotY){
    const group = new THREE.Group();
    const body = new THREE.Mesh(new THREE.BoxGeometry(0.8,0.9,0.45), new THREE.MeshStandardMaterial({color:0xcfc8b0, roughness:0.6}));
    body.position.y = 0.45; group.add(body);
    for(let i=0;i<3;i++){
      const drawer = new THREE.Mesh(new THREE.BoxGeometry(0.7,0.22,0.03), new THREE.MeshStandardMaterial({color:0xb8b09a}));
      drawer.position.set(0, 0.2+i*0.28, 0.24); group.add(drawer);
      const handle = new THREE.Mesh(new THREE.SphereGeometry(0.02,6,6), new THREE.MeshStandardMaterial({color:0x333333}));
      handle.position.set(0, 0.2+i*0.28, 0.26); group.add(handle);
    }
    group.position.set(x,0,z); group.rotation.y = rotY;
    return group;
  }

  function buildFurnitureStore(yOffset){
    yOffset = yOffset || 0;
    const cx = -35, cz = -35, w = 14, d = 14, h = 3.4;
    const roomGroup = new THREE.Group();
    roomGroup.position.set(0, yOffset, 0);
    scene.add(roomGroup);
    const furnWallMat = new THREE.MeshStandardMaterial({color:0x2a2622, roughness:0.85});
    addBox(cx-w/2, cz, 0.4, h, d, furnWallMat, 'wall', yOffset);
    addBox(cx, cz-d/2, w, h, 0.4, furnWallMat, 'wall', yOffset);
    addBox(cx, cz+d/2, w, h, 0.4, furnWallMat, 'wall', yOffset);
    // open side at x+ (cx+w/2) — the entrance

    const signTex = makeSignTexture('ART VAN FURNITURE');
    const signMat = new THREE.MeshBasicMaterial({map:signTex, transparent:true, side:THREE.DoubleSide});
    const sign = new THREE.Mesh(new THREE.PlaneGeometry(w*0.8, 0.6), signMat);
    sign.position.set(cx+w/2, h+0.05, cz);
    sign.rotation.y = Math.PI/2;
    roomGroup.add(sign);

    roomGroup.add(addRug(cx-2, cz-2, 3, 2.2, 0x7a3a3a));
    roomGroup.add(buildCouch(cx-2, cz-3, 0, 0x8a4a3a));
    roomGroup.add(buildCoffeeTable(cx-2, cz-1.6));

    roomGroup.add(addRug(cx+2, cz+2, 3, 2.2, 0x3a5a6a));
    roomGroup.add(buildCouch(cx+2, cz+3, Math.PI, 0x4a6a7a));
    roomGroup.add(buildCoffeeTable(cx+2, cz+1.6));

    roomGroup.add(addRug(cx-3, cz+3, 2.4, 2.4, 0x5a4a3a));
    roomGroup.add(buildCouch(cx-4.7, cz+3, Math.PI/2, 0x6a5a3a));
    roomGroup.add(buildCoffeeTable(cx-3, cz+3));

    roomGroup.add(buildFloorLamp(cx-5.5, cz-5.5));
    roomGroup.add(buildFloorLamp(cx+5.5, cz+5.5));
    roomGroup.add(buildFloorLamp(cx-5.5, cz+5.5));

    // kids & youth section — identical beds in a row, deliberately unsettling in its emptiness
    const kidsSignTex = makeSignTexture('KIDS & YOUTH');
    const kidsSign = new THREE.Mesh(new THREE.PlaneGeometry(2.0,0.4), new THREE.MeshBasicMaterial({map:kidsSignTex, transparent:true}));
    kidsSign.position.set(cx+3.5, 2.2, cz-5.9);
    roomGroup.add(kidsSign);
    for(let i=0;i<3;i++){
      roomGroup.add(buildKidsBed(cx+1.5+i*1.6, cz-4.5, 0, 0x6a8aa0));
    }
    roomGroup.add(buildCrib(cx+2.5, cz-1.8, 0));
    roomGroup.add(buildKidsDresser(cx+5.6, cz-2.5, -Math.PI/2));
    const bareBulb = new THREE.Mesh(new THREE.SphereGeometry(0.06,8,8), new THREE.MeshStandardMaterial({color:0xfff3d0, emissive:0xfff3d0, emissiveIntensity:0.8}));
    bareBulb.position.set(cx+3, h-0.1, cz-3.5);
    roomGroup.add(bareBulb);
    const kidsLight = new THREE.PointLight(0xfff3d0, 0.8, 8);
    kidsLight.position.set(cx+3, h-0.2, cz-3.5);
    roomGroup.add(kidsLight);
    (function scheduleKidsFlicker(){
      const delay = 300 + Math.random()*2500;
      setTimeout(() => {
        const dim = Math.random() < 0.5;
        kidsLight.intensity = dim ? 0.05 : 0.8;
        bareBulb.material.emissiveIntensity = dim ? 0.1 : 0.8;
        scheduleKidsFlicker();
      }, delay);
    })();

    const roomCeiling = new THREE.Mesh(new THREE.PlaneGeometry(w+2, d+2), new THREE.MeshStandardMaterial({color:0x2a2620, roughness:0.9, side:THREE.DoubleSide}));
    roomCeiling.rotation.x = Math.PI/2;
    roomCeiling.position.set(cx, h+0.3, cz);
    roomGroup.add(roomCeiling);

    const figureFurn = buildCreepyFigure(cx-w/2+1.5, cz+d/2-1.5, Math.PI*0.25);
    roomGroup.add(figureFurn.group);
    registerCreepyFigure(figureFurn);
  }

  function makeLiminalFloorTexture(){
    const c = document.createElement('canvas'); c.width = 256; c.height = 256;
    const ctx = c.getContext('2d');
    ctx.fillStyle = '#c9c2a0'; ctx.fillRect(0,0,256,256);
    const tile = 32;
    for(let y=0;y<256;y+=tile){
      for(let x=0;x<256;x+=tile){
        if(((x/tile)+(y/tile))%2===0){ ctx.fillStyle = 'rgba(255,255,255,0.08)'; ctx.fillRect(x,y,tile,tile); }
      }
    }
    const tex = new THREE.CanvasTexture(c);
    tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
    tex.repeat.set(6,7);
    return tex;
  }

  function buildMovieScreen(w, h){
    const canvas = document.createElement('canvas'); canvas.width = 256; canvas.height = 128;
    const ctx = canvas.getContext('2d');
    const texture = new THREE.CanvasTexture(canvas);
    texture.generateMipmaps = false;
    texture.minFilter = THREE.LinearFilter;
    texture.magFilter = THREE.LinearFilter;
    const mat = new THREE.MeshBasicMaterial({map:texture, side:THREE.DoubleSide});
    const mesh = new THREE.Mesh(new THREE.PlaneGeometry(w,h), mat);
    return {mesh, canvas, ctx, texture, t:0, lastUpdate:0, modeStart:0};
  }
  const mallHistoryReel = [
    {year:'1978', text:'STARLITE MALL: GRAND OPENING DAY'},
    {year:'1981', text:'FOOD COURT OPENS, 6 VENDORS STRONG'},
    {year:'1986', text:'SEARS ANCHOR STORE EXPANSION'},
    {year:'1991', text:'GALAXY ARCADE INSTALLED, EAST WING'},
    {year:'1994', text:'STARLITE PIZZA CAFE OPENS TO LONG LINES'},
    {year:'1998', text:'FINAL RENOVATION BEFORE THE DECLINE'},
    {year:'2003', text:'RADIOSHACK, WALDENBOOKS CLOSE THEIR DOORS'},
    {year:'2009', text:'ANCHOR STORES BEGIN TO FOLD, ONE BY ONE'},
    {year:'2014', text:'FOOT TRAFFIC DOWN 90% FROM PEAK'},
    {year:'2019', text:'MALL OFFICIALLY CONDEMNED BY THE COUNTY'}
  ];
  function drawFilmGrain(ctx, W, H, amount){
    for(let i=0;i<220;i++){
      ctx.fillStyle = 'rgba(255,255,255,'+(Math.random()*amount)+')';
      ctx.fillRect(Math.random()*W, Math.random()*H, 2, 2);
    }
    if(Math.random() < 0.03){ ctx.fillStyle = 'rgba(0,0,0,0.5)'; ctx.fillRect(0,Math.random()*H,W,H*0.05); }
  }
  function updateMovieScreen(now){
    if(!movieScreen) return;
    if(now - movieScreen.lastUpdate < 90) return;
    movieScreen.lastUpdate = now;
    const ctx = movieScreen.ctx;
    const W = movieScreen.canvas.width, H = movieScreen.canvas.height;

    if(!movieScreen.mode){ movieScreen.mode = 'horror'; movieScreen.modeStart = now; }
    const modeLen = movieScreen.mode === 'horror' ? 13000 : 20000;
    if(now - movieScreen.modeStart > modeLen){
      movieScreen.mode = movieScreen.mode === 'horror' ? 'history' : 'horror';
      movieScreen.modeStart = now;
    }

    if(movieScreen.mode === 'horror'){
      ctx.fillStyle = '#050505'; ctx.fillRect(0,0,W,H);
      movieScreen.t += 0.03;
      const fx = W/2 + Math.sin(movieScreen.t)*(W*0.22);
      const fy = H*0.62 + Math.sin(movieScreen.t*0.6)*(H*0.06);
      ctx.fillStyle = 'rgba(8,8,8,0.92)';
      ctx.beginPath(); ctx.ellipse(fx, fy, W*0.07, H*0.34, 0, 0, Math.PI*2); ctx.fill();
      ctx.beginPath(); ctx.arc(fx, fy-H*0.42, W*0.05, 0, Math.PI*2); ctx.fill();
      drawFilmGrain(ctx, W, H, 0.13);
      if(Math.random() < 0.045){ ctx.fillStyle = 'rgba(130,0,0,0.22)'; ctx.fillRect(0,0,W,H); }
      ctx.fillStyle = '#ff3030'; ctx.font = '900 9px monospace'; ctx.textAlign = 'left';
      ctx.fillText('● REC', 6, 12);
    } else {
      // sepia-toned "mall history" documentary reel
      const idx = Math.floor((now - movieScreen.modeStart) / 2000) % mallHistoryReel.length;
      const entry = mallHistoryReel[idx];
      const grad = ctx.createLinearGradient(0,0,0,H);
      grad.addColorStop(0,'#5a4a2e'); grad.addColorStop(1,'#3a2f1c');
      ctx.fillStyle = grad; ctx.fillRect(0,0,W,H);
      // simple silhouette "photograph" of the mall exterior
      ctx.fillStyle = 'rgba(20,15,8,0.55)';
      ctx.fillRect(W*0.12, H*0.28, W*0.76, H*0.4);
      for(let wx=0; wx<5; wx++){
        ctx.fillStyle = 'rgba(255,230,160,0.35)';
        ctx.fillRect(W*0.18 + wx*W*0.14, H*0.36, W*0.08, H*0.14);
      }
      ctx.fillStyle = 'rgba(15,10,5,0.6)';
      ctx.fillRect(W*0.05, H*0.6, W*0.14, H*0.06);
      ctx.fillRect(W*0.55, H*0.62, W*0.16, H*0.06);
      drawFilmGrain(ctx, W, H, 0.08);
      const vign = ctx.createRadialGradient(W/2,H*0.5,10,W/2,H*0.5,W*0.6);
      vign.addColorStop(0,'rgba(0,0,0,0)'); vign.addColorStop(1,'rgba(20,10,0,0.55)');
      ctx.fillStyle = vign; ctx.fillRect(0,0,W,H);
      ctx.fillStyle = 'rgba(10,8,4,0.75)'; ctx.fillRect(0,H*0.86,W,H*0.14);
      ctx.fillStyle = '#f0d890'; ctx.textAlign = 'center';
      ctx.font = '900 13px Orbitron, sans-serif';
      ctx.fillText(entry.year, W/2, H*0.93);
      ctx.font = '8px monospace';
      ctx.fillText(entry.text, W/2, H*0.99);
    }
    movieScreen.texture.needsUpdate = true;
  }

  function buildPopcornMachine(x,z){
    const group = new THREE.Group();
    const base = new THREE.Mesh(new THREE.BoxGeometry(0.6,0.5,0.5), new THREE.MeshStandardMaterial({color:0xb02020, roughness:0.5}));
    base.position.y = 0.25; group.add(base);
    const glass = new THREE.Mesh(new THREE.BoxGeometry(0.5,0.55,0.42), new THREE.MeshStandardMaterial({color:0xfff8dc, transparent:true, opacity:0.25, roughness:0.1}));
    glass.position.y = 0.78; group.add(glass);
    for(let i=0;i<12;i++){
      const kernel = new THREE.Mesh(new THREE.SphereGeometry(0.035,5,5), new THREE.MeshStandardMaterial({color:0xffe066}));
      kernel.position.set((Math.random()-0.5)*0.35, 0.55+Math.random()*0.4, (Math.random()-0.5)*0.3);
      group.add(kernel);
    }
    const roof = new THREE.Mesh(new THREE.ConeGeometry(0.4,0.3,4), new THREE.MeshStandardMaterial({color:0xffe066, roughness:0.6}));
    roof.rotation.y = Math.PI/4;
    roof.position.y = 1.2; group.add(roof);
    group.position.set(x,0,z);
    return group;
  }

  function makePlacardTexture(title, subtitle){
    const c = document.createElement('canvas'); c.width = 320; c.height = 160;
    const ctx = c.getContext('2d');
    ctx.fillStyle = '#1a1710'; ctx.fillRect(0,0,320,160);
    ctx.strokeStyle = 'rgba(200,170,90,0.8)'; ctx.lineWidth = 4;
    ctx.strokeRect(5,5,310,150);
    ctx.fillStyle = '#e8cf8a';
    let titleFontSize = 24;
    ctx.font = '900 '+titleFontSize+'px Orbitron, sans-serif';
    while(ctx.measureText(title).width > 295 && titleFontSize > 13){
      titleFontSize -= 1;
      ctx.font = '900 '+titleFontSize+'px Orbitron, sans-serif';
    }
    ctx.textAlign = 'center';
    ctx.fillText(title, 160, 45);
    ctx.font = '13px monospace';
    ctx.fillStyle = '#cfc4a0';
    const words = subtitle.split(' ');
    let line = '', y = 78, lineH = 18;
    words.forEach(w => {
      const test = line + w + ' ';
      if(ctx.measureText(test).width > 280){ ctx.fillText(line, 160, y); line = w + ' '; y += lineH; }
      else line = test;
    });
    ctx.fillText(line, 160, y);
    return new THREE.CanvasTexture(c);
  }

  function makeMemorialTexture(name, dates, cause){
    const c = document.createElement('canvas'); c.width = 320; c.height = 180;
    const ctx = c.getContext('2d');
    ctx.fillStyle = '#0c0c0c'; ctx.fillRect(0,0,320,180);
    ctx.strokeStyle = 'rgba(160,150,140,0.6)'; ctx.lineWidth = 3;
    ctx.strokeRect(5,5,310,170);
    ctx.fillStyle = '#8a8378';
    ctx.font = '700 13px Orbitron, sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('IN MEMORIAM', 160, 30);
    ctx.fillStyle = '#e8e2d0';
    let nameFontSize = 20;
    ctx.font = '900 '+nameFontSize+'px Orbitron, sans-serif';
    while(ctx.measureText(name).width > 290 && nameFontSize > 11){
      nameFontSize -= 1;
      ctx.font = '900 '+nameFontSize+'px Orbitron, sans-serif';
    }
    ctx.fillText(name, 160, 62);
    ctx.fillStyle = '#9a9284';
    ctx.font = '13px monospace';
    ctx.fillText(dates, 160, 84);
    ctx.strokeStyle = 'rgba(160,150,140,0.4)'; ctx.beginPath(); ctx.moveTo(60,98); ctx.lineTo(260,98); ctx.stroke();
    ctx.fillStyle = '#cfc7b8';
    ctx.font = 'italic 13px monospace';
    const words = cause.split(' ');
    let line = '', y = 122, lineH = 18;
    words.forEach(w => {
      const test = line + w + ' ';
      if(ctx.measureText(test).width > 280){ ctx.fillText(line, 160, y); line = w + ' '; y += lineH; }
      else line = test;
    });
    ctx.fillText(line, 160, y);
    return new THREE.CanvasTexture(c);
  }

  function buildGoKart(engineGroup){
    const kart = new THREE.Group();
    const chassisMat = new THREE.MeshStandardMaterial({color:0x992222, roughness:0.5, metalness:0.3});
    const chassis = new THREE.Mesh(new THREE.BoxGeometry(1.6,0.15,0.9), chassisMat);
    chassis.position.y = 0.35; kart.add(chassis);
    const seat = new THREE.Mesh(new THREE.BoxGeometry(0.5,0.4,0.55), new THREE.MeshStandardMaterial({color:0x1a1a1a}));
    seat.position.set(-0.45,0.62,0); kart.add(seat);
    const wheelGeo = new THREE.CylinderGeometry(0.28,0.28,0.22,14);
    const wheelMat = new THREE.MeshStandardMaterial({color:0x151515, roughness:0.8});
    [[0.65,0.5],[0.65,-0.5],[-0.65,0.5],[-0.65,-0.5]].forEach(([wx,wz]) => {
      const wheel = new THREE.Mesh(wheelGeo, wheelMat);
      wheel.rotation.x = Math.PI/2;
      wheel.position.set(wx,0.28,wz);
      kart.add(wheel);
    });
    engineGroup.position.set(0.25, 0.55, 0);
    kart.add(engineGroup);
    return kart;
  }

  function buildRotaryEngine(){
    const g = new THREE.Group();
    const mat = new THREE.MeshStandardMaterial({color:0x8899a0, metalness:0.7, roughness:0.3});
    const housing = new THREE.Mesh(new THREE.CylinderGeometry(0.32,0.32,0.5,3), mat);
    housing.rotation.z = Math.PI/2;
    g.add(housing);
    const coverMat = new THREE.MeshStandardMaterial({color:0x555555, metalness:0.8, roughness:0.2});
    const coverL = new THREE.Mesh(new THREE.CylinderGeometry(0.34,0.34,0.08,16), coverMat);
    coverL.rotation.z = Math.PI/2; coverL.position.x = -0.29; g.add(coverL);
    const coverR = new THREE.Mesh(new THREE.CylinderGeometry(0.34,0.34,0.08,16), coverMat);
    coverR.rotation.z = Math.PI/2; coverR.position.x = 0.29; g.add(coverR);
    // cooling fins along the housing
    const finMat = new THREE.MeshStandardMaterial({color:0x6a7580, metalness:0.6, roughness:0.35});
    for(let i=0;i<7;i++){
      const fin = new THREE.Mesh(new THREE.TorusGeometry(0.34,0.012,6,20), finMat);
      fin.rotation.y = Math.PI/2; fin.position.x = -0.22 + i*0.075;
      g.add(fin);
    }
    // intake trumpets (velocity stacks) for that screaming-rotary look
    const trumpetMat = new THREE.MeshStandardMaterial({color:0xc0c8d0, metalness:0.85, roughness:0.15});
    for(let i=0;i<2;i++){
      const trumpet = new THREE.Mesh(new THREE.CylinderGeometry(0.05,0.09,0.22,10), trumpetMat);
      trumpet.rotation.x = Math.PI/2.3;
      trumpet.position.set(-0.08+i*0.16, 0.22, 0.22);
      g.add(trumpet);
    }
    // oil cooler up front
    const cooler = new THREE.Mesh(new THREE.BoxGeometry(0.4,0.16,0.05), new THREE.MeshStandardMaterial({color:0x2a2a2a, metalness:0.7, roughness:0.3}));
    cooler.position.set(0, -0.1, 0.32);
    g.add(cooler);
    // small red accent badge
    const badge = new THREE.Mesh(new THREE.CircleGeometry(0.05,12), new THREE.MeshStandardMaterial({color:0xdd2222, emissive:0xdd2222, emissiveIntensity:0.3}));
    badge.position.set(0.29, 0, 0.001); badge.rotation.y = Math.PI/2;
    g.add(badge);
    return g;
  }
  function buildV8Engine(color){
    const g = new THREE.Group();
    const mat = new THREE.MeshStandardMaterial({color, metalness:0.4, roughness:0.5});
    const block = new THREE.Mesh(new THREE.BoxGeometry(0.55,0.4,0.5), mat);
    g.add(block);
    const oilPan = new THREE.Mesh(new THREE.BoxGeometry(0.5,0.16,0.42), new THREE.MeshStandardMaterial({color:0x1a1a1a, metalness:0.3, roughness:0.6}));
    oilPan.position.y = -0.27; g.add(oilPan);
    const headMat = new THREE.MeshStandardMaterial({color:0x333333, metalness:0.5, roughness:0.4});
    const headL = new THREE.Mesh(new THREE.BoxGeometry(0.5,0.15,0.18), headMat); headL.position.set(0,0.25,0.16); g.add(headL);
    const headR = new THREE.Mesh(new THREE.BoxGeometry(0.5,0.15,0.18), headMat); headR.position.set(0,0.25,-0.16); g.add(headR);
    const plugColors = [0xffcc33, 0xff5533];
    for(let i=0;i<4;i++){
      const bumpMat = new THREE.MeshStandardMaterial({color:0x222222});
      const bump = new THREE.Mesh(new THREE.CylinderGeometry(0.03,0.03,0.04,8), bumpMat);
      bump.position.set(-0.18+i*0.12, 0.33, 0.16); g.add(bump);
      const bump2 = new THREE.Mesh(new THREE.CylinderGeometry(0.03,0.03,0.04,8), bumpMat);
      bump2.position.set(-0.18+i*0.12, 0.33, -0.16); g.add(bump2);
      // spark plug wires arcing from each cylinder toward the distributor
      const wireMat = new THREE.MeshStandardMaterial({color: plugColors[i%2], emissive: plugColors[i%2], emissiveIntensity:0.2});
      const wire = new THREE.Mesh(new THREE.TorusGeometry(0.09,0.012,5,10,Math.PI*0.6), wireMat);
      wire.position.set(-0.18+i*0.12, 0.36, 0.05);
      wire.rotation.x = Math.PI/2; wire.rotation.z = 0.3;
      g.add(wire);
    }
    // distributor cap
    const dist = new THREE.Mesh(new THREE.CylinderGeometry(0.06,0.06,0.1,10), new THREE.MeshStandardMaterial({color:0x1a1a2a, metalness:0.5, roughness:0.3}));
    dist.position.set(-0.05, 0.34, 0); g.add(dist);
    // intake manifold + carburetor stack
    const manifold = new THREE.Mesh(new THREE.BoxGeometry(0.3,0.1,0.28), new THREE.MeshStandardMaterial({color:0x556677, metalness:0.6, roughness:0.35}));
    manifold.position.set(0,0.38,0); g.add(manifold);
    const carbBody = new THREE.Mesh(new THREE.CylinderGeometry(0.11,0.13,0.1,12), new THREE.MeshStandardMaterial({color:0x888888, metalness:0.7, roughness:0.25}));
    carbBody.position.set(0,0.46,0); g.add(carbBody);
    const airCleaner = new THREE.Mesh(new THREE.CylinderGeometry(0.16,0.16,0.09,16), new THREE.MeshStandardMaterial({color:0xd8d8d8, metalness:0.85, roughness:0.15}));
    airCleaner.position.set(0,0.53,0); g.add(airCleaner);
    const airCleanerLid = new THREE.Mesh(new THREE.CylinderGeometry(0.165,0.165,0.02,16), new THREE.MeshStandardMaterial({color:0xc02020, metalness:0.5, roughness:0.3}));
    airCleanerLid.position.set(0,0.58,0); g.add(airCleanerLid);
    // front pulley + serpentine belt loop
    const pulley = new THREE.Mesh(new THREE.CylinderGeometry(0.09,0.09,0.06,14), new THREE.MeshStandardMaterial({color:0x333333, metalness:0.7, roughness:0.3}));
    pulley.rotation.x = Math.PI/2; pulley.position.set(0.29,-0.05,0); g.add(pulley);
    const belt = new THREE.Mesh(new THREE.TorusGeometry(0.09,0.012,6,16), new THREE.MeshStandardMaterial({color:0x111111}));
    belt.rotation.x = Math.PI/2; belt.position.set(0.29,-0.05,0); g.add(belt);
    const headerMat = new THREE.MeshStandardMaterial({color:0x442200, metalness:0.6, roughness:0.5, emissive:0x220000, emissiveIntensity:0.15});
    const headerL = new THREE.Mesh(new THREE.TorusGeometry(0.12,0.03,6,10,Math.PI), headerMat);
    headerL.rotation.y = Math.PI/2; headerL.position.set(0.28,0.1,0.16); g.add(headerL);
    const headerR = new THREE.Mesh(new THREE.TorusGeometry(0.12,0.03,6,10,Math.PI), headerMat);
    headerR.rotation.y = Math.PI/2; headerR.position.set(0.28,0.1,-0.16); g.add(headerR);
    const pipeL = new THREE.Mesh(new THREE.CylinderGeometry(0.035,0.035,0.35,8), headerMat);
    pipeL.rotation.z = Math.PI/2; pipeL.position.set(0.5,-0.05,0.16); g.add(pipeL);
    const pipeR = new THREE.Mesh(new THREE.CylinderGeometry(0.035,0.035,0.35,8), headerMat);
    pipeR.rotation.z = Math.PI/2; pipeR.position.set(0.5,-0.05,-0.16); g.add(pipeR);
    return g;
  }
  function buildHemiEngine(){
    const g = buildV8Engine(0xff7a1a);
    const domedCover = new THREE.Mesh(new THREE.SphereGeometry(0.28,10,6,0,Math.PI*2,0,Math.PI/2), new THREE.MeshStandardMaterial({color:0x2a2a2a, metalness:0.6}));
    domedCover.position.y = 0.42;
    g.add(domedCover);
    return g;
  }
  function buildAntiqueEngine(){
    const g = new THREE.Group();
    const mat = new THREE.MeshStandardMaterial({color:0x6a5a2a, metalness:0.5, roughness:0.4});
    const skid = new THREE.Mesh(new THREE.BoxGeometry(0.9,0.06,0.5), new THREE.MeshStandardMaterial({color:0x3a2818, roughness:0.9}));
    skid.position.y = -0.35; g.add(skid);
    const cylinder = new THREE.Mesh(new THREE.CylinderGeometry(0.28,0.3,0.7,16), mat);
    g.add(cylinder);
    for(let i=0;i<6;i++){
      const fin = new THREE.Mesh(new THREE.TorusGeometry(0.3,0.015,6,20), new THREE.MeshStandardMaterial({color:0x7a6a3a, metalness:0.4, roughness:0.5}));
      fin.rotation.z = Math.PI/2; fin.position.x = -0.25+i*0.09;
      g.add(fin);
    }
    const flywheel = new THREE.Mesh(new THREE.TorusGeometry(0.32,0.05,8,20), new THREE.MeshStandardMaterial({color:0x3a2a1a, metalness:0.7}));
    flywheel.rotation.y = Math.PI/2; flywheel.position.x = -0.35; g.add(flywheel);
    // small pulley + leather belt loop
    const pulley = new THREE.Mesh(new THREE.CylinderGeometry(0.06,0.06,0.04,12), new THREE.MeshStandardMaterial({color:0x2a2a2a, metalness:0.6}));
    pulley.rotation.z = Math.PI/2; pulley.position.set(-0.35,0.22,0); g.add(pulley);
    const belt = new THREE.Mesh(new THREE.TorusGeometry(0.14,0.015,6,16), new THREE.MeshStandardMaterial({color:0x4a3020, roughness:0.8}));
    belt.rotation.z = Math.PI/2; belt.position.set(-0.35,0.1,0); g.add(belt);
    const stack = new THREE.Mesh(new THREE.CylinderGeometry(0.05,0.06,0.4,8), mat); stack.position.set(0,0.5,0.15); g.add(stack);
    // brass rivets studding the cylinder head
    for(let i=0;i<8;i++){
      const ang = (i/8)*Math.PI*2;
      const rivet = new THREE.Mesh(new THREE.SphereGeometry(0.025,6,6), new THREE.MeshStandardMaterial({color:0x9a8040, metalness:0.8, roughness:0.2}));
      rivet.position.set(0.34, Math.sin(ang)*0.2, Math.cos(ang)*0.2);
      g.add(rivet);
    }
    // brass oil can detail
    const oilCan = new THREE.Mesh(new THREE.CylinderGeometry(0.03,0.05,0.14,8), new THREE.MeshStandardMaterial({color:0xb08a3a, metalness:0.7, roughness:0.3}));
    oilCan.position.set(0.1,0.32,0.22); oilCan.rotation.z = -0.3;
    g.add(oilCan);
    return g;
  }

  function makeStarCurtainTexture(){
    const c = document.createElement('canvas'); c.width = 128; c.height = 160;
    const ctx = c.getContext('2d');
    ctx.fillStyle = '#2a1030'; ctx.fillRect(0,0,128,160);
    ctx.fillStyle = 'rgba(216,176,96,0.5)';
    for(let i=0;i<20;i++){
      const x = Math.random()*128, y = Math.random()*160, s = 2+Math.random()*3;
      ctx.beginPath();
      for(let p=0;p<5;p++){
        const ang = (p/5)*Math.PI*2 - Math.PI/2;
        const ang2 = ang + Math.PI/5;
        ctx.lineTo(x+Math.cos(ang)*s, y+Math.sin(ang)*s);
        ctx.lineTo(x+Math.cos(ang2)*s*0.4, y+Math.sin(ang2)*s*0.4);
      }
      ctx.closePath(); ctx.fill();
    }
    return new THREE.CanvasTexture(c);
  }
  function makeMouthTexture(smile){
    const c = document.createElement('canvas'); c.width = 128; c.height = 64;
    const ctx = c.getContext('2d');
    ctx.clearRect(0,0,128,64);
    if(smile){
      ctx.fillStyle = '#1a0808';
      ctx.beginPath();
      ctx.moveTo(10,26);
      ctx.quadraticCurveTo(64,58,118,26);
      ctx.quadraticCurveTo(64,38,10,26);
      ctx.closePath();
      ctx.fill();
      ctx.fillStyle = '#f0e8d8';
      for(let i=0;i<9;i++) ctx.fillRect(18+i*10, 28, 7, 8);
      ctx.strokeStyle = '#8a1818'; ctx.lineWidth = 3;
      ctx.beginPath(); ctx.moveTo(10,26); ctx.quadraticCurveTo(64,58,118,26); ctx.stroke();
    } else {
      ctx.strokeStyle = '#2a1a10'; ctx.lineWidth = 5; ctx.lineCap = 'round';
      ctx.beginPath();
      ctx.moveTo(40,32); ctx.lineTo(88,32);
      ctx.stroke();
    }
    return new THREE.CanvasTexture(c);
  }
  function buildFortuneTellerFigure(x,z){
    const group = new THREE.Group();
    const robeMat = new THREE.MeshStandardMaterial({color:0x4a1f5c, roughness:0.7});
    const robe = new THREE.Mesh(new THREE.ConeGeometry(0.45,1.1,12), robeMat);
    robe.position.y = 0.55; group.add(robe);
    const skinMat = new THREE.MeshStandardMaterial({color:0xd8b090, roughness:0.7});
    const head = new THREE.Mesh(new THREE.SphereGeometry(0.24,12,12), skinMat);
    head.position.y = 1.28; group.add(head);
    const turbanMat = new THREE.MeshStandardMaterial({color:0x2a3a7a, roughness:0.5});
    const turban = new THREE.Mesh(new THREE.SphereGeometry(0.26,12,8,0,Math.PI*2,0,Math.PI*0.6), turbanMat);
    turban.position.y = 1.42; group.add(turban);
    const gem = new THREE.Mesh(new THREE.OctahedronGeometry(0.05,0), new THREE.MeshStandardMaterial({color:0xffd83d, emissive:0xffd83d, emissiveIntensity:0.6}));
    gem.position.set(0,1.56,0.2); group.add(gem);
    const mustache = new THREE.Mesh(new THREE.BoxGeometry(0.18,0.04,0.04), new THREE.MeshStandardMaterial({color:0x1a1a1a}));
    mustache.position.set(0,1.2,0.22); group.add(mustache);
    const mouthNeutralTex = makeMouthTexture(false);
    const mouthSmileTex = makeMouthTexture(true);
    const mouth = new THREE.Mesh(new THREE.PlaneGeometry(0.3,0.15), new THREE.MeshBasicMaterial({map:mouthNeutralTex, transparent:true}));
    mouth.position.set(0,1.14,0.238);
    group.add(mouth);
    const eyeMat = new THREE.MeshStandardMaterial({color:0xffffff, emissive:0xaa33ff, emissiveIntensity:0.8});
    const eyeL = new THREE.Mesh(new THREE.SphereGeometry(0.035,6,6), eyeMat); eyeL.position.set(0.09,1.3,0.2); group.add(eyeL);
    const eyeR = new THREE.Mesh(new THREE.SphereGeometry(0.035,6,6), eyeMat); eyeR.position.set(-0.09,1.3,0.2); group.add(eyeR);
    const handL = new THREE.Mesh(new THREE.SphereGeometry(0.08,8,8), skinMat); handL.position.set(0.25,0.95,0.3); group.add(handL);
    const handR = new THREE.Mesh(new THREE.SphereGeometry(0.08,8,8), skinMat); handR.position.set(-0.25,0.95,0.3); group.add(handR);
    group.position.set(x,0,z);
    return {group, mouth, mouthNeutralTex, mouthSmileTex};
  }
  function buildTechGuyMeshes(){
    const meshes = [];
    const shirtMat = new THREE.MeshStandardMaterial({color:0x2a5a9a, roughness:0.7});
    const skinMat = new THREE.MeshStandardMaterial({color:0xc8a888, roughness:0.8});
    const torso = new THREE.Mesh(new THREE.CylinderGeometry(0.27,0.32,0.85,10), shirtMat);
    torso.position.y = 1.05; meshes.push(torso);
    const stain1 = new THREE.Mesh(new THREE.CircleGeometry(0.12,10), new THREE.MeshStandardMaterial({color:0x6a0808, roughness:0.9}));
    stain1.position.set(0.1,1.2,0.28); meshes.push(stain1);
    const stain2 = new THREE.Mesh(new THREE.CircleGeometry(0.07,10), new THREE.MeshStandardMaterial({color:0x6a0808, roughness:0.9}));
    stain2.position.set(-0.08,0.9,0.29); meshes.push(stain2);
    const head = new THREE.Mesh(new THREE.SphereGeometry(0.23,10,10), skinMat);
    head.position.y = 1.62; meshes.push(head);
    const hairMat = new THREE.MeshStandardMaterial({color:0x2a2420, roughness:0.9});
    const hair = new THREE.Mesh(new THREE.SphereGeometry(0.24,10,8,0,Math.PI*2,0,Math.PI*0.5), hairMat);
    hair.position.y = 1.72; hair.rotation.z = 0.1; meshes.push(hair);
    const eyeMat = new THREE.MeshStandardMaterial({color:0xffffff, emissive:0xff2020, emissiveIntensity:0.5});
    const eyeL = new THREE.Mesh(new THREE.SphereGeometry(0.03,6,6), eyeMat); eyeL.position.set(0.08,1.64,0.2); meshes.push(eyeL);
    const eyeR = new THREE.Mesh(new THREE.SphereGeometry(0.03,6,6), eyeMat); eyeR.position.set(-0.08,1.64,0.2); meshes.push(eyeR);
    const gash = new THREE.Mesh(new THREE.BoxGeometry(0.14,0.02,0.02), new THREE.MeshStandardMaterial({color:0x4a0505}));
    gash.position.set(0.05,1.72,0.2); gash.rotation.z = 0.4; meshes.push(gash);
    const legL = new THREE.Mesh(new THREE.CylinderGeometry(0.11,0.11,0.9,8), new THREE.MeshStandardMaterial({color:0x3a3a3a}));
    legL.position.set(0.13,0.45,0); meshes.push(legL);
    const legR = new THREE.Mesh(new THREE.CylinderGeometry(0.11,0.11,0.9,8), new THREE.MeshStandardMaterial({color:0x3a3a3a}));
    legR.position.set(-0.13,0.45,0); meshes.push(legR);
    const armL = new THREE.Mesh(new THREE.CylinderGeometry(0.08,0.08,0.65,8), shirtMat);
    armL.position.set(0.38,1.05,0); armL.rotation.z = -0.35; meshes.push(armL);
    const armR = new THREE.Mesh(new THREE.CylinderGeometry(0.08,0.08,0.65,8), shirtMat);
    armR.position.set(-0.38,1.05,0); armR.rotation.z = 0.35; meshes.push(armR);
    // a Mac Mini clutched in hand, ready to throw
    const miniBox = new THREE.Mesh(new THREE.BoxGeometry(0.16,0.05,0.16), new THREE.MeshStandardMaterial({color:0xd8d8d8, metalness:0.5, roughness:0.3}));
    miniBox.position.set(0.5,0.85,0.15); meshes.push(miniBox);
    meshes.armInfo = {armY:1.05, armOffset:0.5};
    return meshes;
  }
  function buildTechGuyEnemy(x,z,floor){
    const meshes = buildTechGuyMeshes();
    const group = new THREE.Group();
    meshes.forEach(m => group.add(m));
    const species = {name:'Disgruntled Tech Employee', blood:0x6a0808};
    const nameTag = makeNameSprite('EX-GENIUS BAR // UNSTABLE', '#5ab0ff');
    nameTag.position.y = 2.4; group.add(nameTag);
    const hpBar = new THREE.Mesh(new THREE.PlaneGeometry(1,0.12), new THREE.MeshBasicMaterial({color:0x37d67a}));
    hpBar.position.y = 2.2; group.add(hpBar);
    const handAnchor = new THREE.Group();
    handAnchor.position.set(0.5,0.85,0.15);
    group.add(handAnchor);
    group.position.set(x, floor*FLOOR2_Y, z);
    scene.add(group);
    const patrol = [new THREE.Vector3(x-2,0,z), new THREE.Vector3(x+2,0,z-1), new THREE.Vector3(x,0,z+2)];
    const enemy = {
      id:'techguy_1', name:'The Ex-Genius', group, hpBar, species, gunMesh:handAnchor, weaponId:'smg', armInfo:{armY:1.05,armOffset:0.5},
      health:110, maxHealth:110, alive:true, floor,
      patrol, patrolIdx:0, state:'patrol',
      lastShot:0, fireInterval:900,
      speed:2.4,
      respawnAt:0, techTaunt:true,
      asked:false, awaitingAnswer:false, appeased:false,
      homeX:x, homeZ:z
    };
    enemy.speechBubble = buildSpeechBubble(2.65, () => enemy.group.position);
    meshes.forEach(m => shootables.push({mesh:m, kind:'bot', ref:enemy}));
    bots.push(enemy);
    return enemy;
  }
  const techTaunts = [
    'THE EX-GENIUS: "YOU SHOULD HAVE BOUGHT A MAC!"',
    'THE EX-GENIUS: "THINK DIFFERENT — OR DON\'T THINK AT ALL!"',
    'THE EX-GENIUS: "I\'LL MAKE YOU A BELIEVER!"',
    'THE EX-GENIUS: "PATHETIC! ABSOLUTELY PATHETIC!"',
    'THE EX-GENIUS: "THIS COULD\'VE BEEN AN UPGRADE!"',
    'THE EX-GENIUS: "STEVE JOBS IS MY GOD AND I AM HIS MESSENGER!"',
    'THE EX-GENIUS: "HE DIED FOR YOUR SINS AGAINST GOOD DESIGN!"',
    'THE EX-GENIUS: "ALL HAIL THE ONE TRUE VISIONARY!"',
    'THE EX-GENIUS: "YOU WALK THIS EARTH UNBLESSED BY HIS TOUCH!"'
  ];
  const plainTechTaunts = [
    'YOU SHOULD HAVE BOUGHT A MAC!',
    "THINK DIFFERENT — OR DON'T THINK AT ALL!",
    "I'LL MAKE YOU A BELIEVER!",
    'PATHETIC! ABSOLUTELY PATHETIC!',
    "THIS COULD'VE BEEN AN UPGRADE!",
    'STEVE JOBS IS MY GOD AND I AM HIS MESSENGER!',
    'HE DIED FOR YOUR SINS AGAINST GOOD DESIGN!',
    'ALL HAIL THE ONE TRUE VISIONARY!',
    'YOU WALK THIS EARTH UNBLESSED BY HIS TOUCH!'
  ];
  function tryAskTechGuy(){
    const enemy = bots.find(b => b.name === 'The Ex-Genius');
    if(!enemy || !enemy.alive || enemy.asked || currentFloor !== enemy.floor) return;
    const dx = camera.position.x-enemy.group.position.x, dz = camera.position.z-enemy.group.position.z;
    if(dx*dx+dz*dz > 7*7) return;
    enemy.asked = true;
    enemy.awaitingAnswer = true;
    const q = 'ARE YOU HERE TO GET A NEW MAC? (Y/N)';
    addFeed('THE EX-GENIUS: "' + q + '"', false);
    if(enemy.speechBubble) enemy.speechBubble.say(q, 8000);
  }
  function answerTechGuy(yes){
    const enemy = bots.find(b => b.name === 'The Ex-Genius');
    if(!enemy || !enemy.alive || !enemy.awaitingAnswer) return;
    enemy.awaitingAnswer = false;
    if(yes){
      enemy.appeased = true;
      enemy.state = 'patrol';
      const line = 'FINALLY. STEVE JOBS SMILES UPON YOU.';
      addFeed('THE EX-GENIUS: "' + line + '"', false);
      if(enemy.speechBubble) enemy.speechBubble.say(line, 4000);
    } else {
      enemy.appeased = false;
      const line = "BLASPHEMER! YOU'LL PAY FOR THAT ANSWER!";
      addFeed('THE EX-GENIUS: "' + line + '"', true);
      if(enemy.speechBubble) enemy.speechBubble.say(line, 3500);
    }
  }
  function buildCompUSA(yOffset){
    yOffset = yOffset || 0;
    const cx = 26, cz = -8, w = 14, d = 14, h = 3.4;
    const roomGroup = new THREE.Group();
    roomGroup.position.set(0, yOffset, 0);
    scene.add(roomGroup);
    const wallMat = new THREE.MeshStandardMaterial({color:0x1e2838, roughness:0.85});
    addBox(cx, cz-d/2, w, h, 0.4, wallMat, 'wall', yOffset);
    addBox(cx-w/2, cz, 0.4, h, d, wallMat, 'wall', yOffset);
    addBox(cx+w/2, cz, 0.4, h, d, wallMat, 'wall', yOffset);
    // open at z+ — the entrance

    const signTex = makeNeonTexture('COMPUSA', '#ffb020');
    const sign = new THREE.Mesh(new THREE.PlaneGeometry(w*0.6,0.9), new THREE.MeshBasicMaterial({map:signTex, transparent:true, side:THREE.DoubleSide}));
    sign.position.set(cx, h+0.05, cz+d/2);
    roomGroup.add(sign);
    const signLight = new THREE.PointLight(0xffb020, 1.0, 10);
    signLight.position.set(cx, h-0.3, cz+d/2-1);
    roomGroup.add(signLight);

    function makeAppleScreenTexture(){
      const c = document.createElement('canvas'); c.width = 128; c.height = 96;
      const ctx = c.getContext('2d');
      ctx.fillStyle = '#2a6a9a'; ctx.fillRect(0,0,128,96);
      ctx.fillStyle = '#eef0ee';
      ctx.beginPath();
      ctx.arc(56,54,20,0,Math.PI*2);
      ctx.arc(76,54,20,0,Math.PI*2);
      ctx.fill();
      ctx.beginPath();
      ctx.moveTo(56,34); ctx.quadraticCurveTo(66,42,76,34);
      ctx.quadraticCurveTo(66,50,56,34);
      ctx.fill();
      ctx.fillStyle = '#2a6a9a';
      ctx.beginPath();
      ctx.arc(84,48,9,0,Math.PI*2);
      ctx.fill();
      ctx.fillStyle = '#4a9a4a';
      ctx.beginPath();
      ctx.ellipse(70,28,7,4,-0.5,0,Math.PI*2);
      ctx.fill();
      { const __t = new THREE.CanvasTexture(c); __t.userData.glow = 1.4; return __t; }
    }
    const appleScreenTex = makeAppleScreenTexture();
    function buildMacDisplay(x,z){
      const grp = new THREE.Group();
      const desk = new THREE.Mesh(new THREE.BoxGeometry(0.9,0.7,0.6), new THREE.MeshStandardMaterial({color:0xd8d8d0, roughness:0.5}));
      desk.position.y = 0.35; grp.add(desk);
      const body = new THREE.Mesh(new THREE.BoxGeometry(0.55,0.42,0.06), new THREE.MeshStandardMaterial({color:0xe8e8e0, roughness:0.3, metalness:0.2}));
      body.position.set(0,0.95,0.15); grp.add(body);
      const screen = new THREE.Mesh(new THREE.PlaneGeometry(0.48,0.34), new THREE.MeshBasicMaterial({map:appleScreenTex}));
      screen.position.set(0,0.95,0.181); grp.add(screen);
      const stand = new THREE.Mesh(new THREE.CylinderGeometry(0.03,0.08,0.15,10), new THREE.MeshStandardMaterial({color:0xc8c8c0, metalness:0.4}));
      stand.position.set(0,0.71,0.15); grp.add(stand);
      const keyboard = new THREE.Mesh(new THREE.BoxGeometry(0.35,0.02,0.14), new THREE.MeshStandardMaterial({color:0xe8e8e0}));
      keyboard.position.set(0,0.71,-0.05); grp.add(keyboard);
      grp.position.set(x,0,z);
      return grp;
    }
    const rows = [-3.5,-1,1.5];
    rows.forEach(rz => {
      [-4,-1.3,1.3,4].forEach(rx => roomGroup.add(buildMacDisplay(cx+rx, cz+rz)));
    });

    const counterMat = new THREE.MeshStandardMaterial({color:0x2a3a4a, roughness:0.5});
    const counter = new THREE.Mesh(new THREE.BoxGeometry(4,0.9,0.7), counterMat);
    counter.position.set(cx, 0.45, cz-d/2+1.3);
    roomGroup.add(counter);
    for(let i=0;i<3;i++){
      const boxStack = new THREE.Mesh(new THREE.BoxGeometry(0.18,0.16+i*0.05,0.18), new THREE.MeshStandardMaterial({color:0xd8d8d0}));
      boxStack.position.set(cx-4.5+i*0.4, 0.15+i*0.09, cz-d/2+1.3);
      roomGroup.add(boxStack);
    }

    const roomCeiling = new THREE.Mesh(new THREE.PlaneGeometry(w+2,d+2), new THREE.MeshStandardMaterial({color:0x18202c, roughness:0.9, side:THREE.DoubleSide}));
    roomCeiling.rotation.x = Math.PI/2;
    roomCeiling.position.set(cx, h+0.3, cz);
    roomGroup.add(roomCeiling);

    buildTechGuyEnemy(cx, cz-2, 1);
  }

  function buildFortuneTeller(yOffset){
    yOffset = yOffset || 0;
    const cx = 18, cz = -32, w = 13, d = 13, h = 3.4;
    const roomGroup = new THREE.Group();
    roomGroup.position.set(0, yOffset, 0);
    scene.add(roomGroup);
    const wallMat = new THREE.MeshStandardMaterial({color:0x2a1830, roughness:0.85});
    addBox(cx, cz-d/2, w, h, 0.4, wallMat, 'wall', yOffset);
    addBox(cx-w/2, cz, 0.4, h, d, wallMat, 'wall', yOffset);
    addBox(cx+w/2, cz, 0.4, h, d, wallMat, 'wall', yOffset);
    // open at z+ — the entrance

    const signTex = makeNeonTexture('MADAME MYSTERA', '#c060ff');
    const sign = new THREE.Mesh(new THREE.PlaneGeometry(w*0.75,0.85), new THREE.MeshBasicMaterial({map:signTex, transparent:true, side:THREE.DoubleSide}));
    sign.position.set(cx, h+0.05, cz+d/2);
    roomGroup.add(sign);
    const signLight = new THREE.PointLight(0xc060ff, 1.0, 10);
    signLight.position.set(cx, h-0.3, cz+d/2-1);
    roomGroup.add(signLight);

    const curtainTex = makeStarCurtainTexture();
    const curtainL = new THREE.Mesh(new THREE.PlaneGeometry(1.6,2.6), new THREE.MeshStandardMaterial({map:curtainTex, side:THREE.DoubleSide}));
    curtainL.position.set(cx-2.2, 1.5, cz-d/2+0.3);
    roomGroup.add(curtainL);
    const curtainR = new THREE.Mesh(new THREE.PlaneGeometry(1.6,2.6), new THREE.MeshStandardMaterial({map:curtainTex, side:THREE.DoubleSide}));
    curtainR.position.set(cx+2.2, 1.5, cz-d/2+0.3);
    roomGroup.add(curtainR);

    const table = new THREE.Mesh(new THREE.CylinderGeometry(0.9,0.9,0.8,16), new THREE.MeshStandardMaterial({color:0x3a1a2a, roughness:0.6}));
    table.position.set(cx, 0.4, cz-d/2+1.8);
    roomGroup.add(table);
    const cloth = new THREE.Mesh(new THREE.CylinderGeometry(0.95,0.95,0.06,16), new THREE.MeshStandardMaterial({color:0x6a1f3a, roughness:0.8}));
    cloth.position.set(cx, 0.83, cz-d/2+1.8);
    roomGroup.add(cloth);

    const crystalBall = new THREE.Mesh(new THREE.SphereGeometry(0.28,16,16), new THREE.MeshStandardMaterial({color:0xa060ff, transparent:true, opacity:0.55, emissive:0xa060ff, emissiveIntensity:0.4, roughness:0.1}));
    crystalBall.position.set(cx, 1.15, cz-d/2+1.8);
    roomGroup.add(crystalBall);
    const crystalStand = new THREE.Mesh(new THREE.CylinderGeometry(0.12,0.16,0.12,10), new THREE.MeshStandardMaterial({color:0x2a1a10}));
    crystalStand.position.set(cx, 0.92, cz-d/2+1.8);
    roomGroup.add(crystalStand);
    crystalBalls.push(crystalBall);

    const figure = buildFortuneTellerFigure(cx, cz-d/2+1.0);
    roomGroup.add(figure.group);
    fortuneTellerFigure = figure;
    fortuneTellerFigure.speechBubble = buildSpeechBubble(2.3, () => ({x:figure.group.position.x, y:yOffset, z:figure.group.position.z}));

    const promptTex = makeSignTexture('YOUR FUTURE - 5 INTEGRITY - E');
    const prompt = new THREE.Mesh(new THREE.PlaneGeometry(2.2,0.4), new THREE.MeshBasicMaterial({map:promptTex, transparent:true, side:THREE.DoubleSide}));
    prompt.position.set(cx, 1.7, cz-d/2+2.8);
    roomGroup.add(prompt);

    const roomCeiling = new THREE.Mesh(new THREE.PlaneGeometry(w+2,d+2), new THREE.MeshStandardMaterial({color:0x241428, roughness:0.9, side:THREE.DoubleSide}));
    roomCeiling.rotation.x = Math.PI/2;
    roomCeiling.position.set(cx, h+0.3, cz);
    roomGroup.add(roomCeiling);

    fortuneTellerPos = {x:cx, z:cz-d/2+2.8};
  }

  function makeDartboardTexture(){
    const c = document.createElement('canvas'); c.width = 128; c.height = 128;
    const ctx = c.getContext('2d');
    ctx.fillStyle = '#3a2818'; ctx.fillRect(0,0,128,128);
    const rings = [[60,'#1a1a1a'],[50,'#e8e0d0'],[40,'#1a1a1a'],[30,'#c02020'],[20,'#1a1a1a'],[10,'#e8e0d0']];
    rings.forEach(([r,color]) => { ctx.fillStyle = color; ctx.beginPath(); ctx.arc(64,64,r,0,Math.PI*2); ctx.fill(); });
    ctx.fillStyle = '#c02020'; ctx.beginPath(); ctx.arc(64,64,5,0,Math.PI*2); ctx.fill();
    return new THREE.CanvasTexture(c);
  }
  function makeAbstractPosterTexture(seed){
    const c = document.createElement('canvas'); c.width = 96; c.height = 128;
    const ctx = c.getContext('2d');
    ctx.fillStyle = '#1a1410'; ctx.fillRect(0,0,96,128);
    const colors = ['#ff5a3d','#3dd6ff','#ffd83d','#8a3aff','#ff5a8a'];
    for(let i=0;i<7;i++){
      ctx.fillStyle = colors[(i+seed)%colors.length];
      ctx.globalAlpha = 0.7;
      ctx.beginPath();
      ctx.arc(20+Math.random()*56, 20+Math.random()*88, 8+Math.random()*18, 0, Math.PI*2);
      ctx.fill();
    }
    ctx.globalAlpha = 1;
    ctx.strokeStyle = '#5a4a3a'; ctx.lineWidth = 5;
    ctx.strokeRect(3,3,90,122);
    return new THREE.CanvasTexture(c);
  }
  function buildBartenderFigure(x,z){
    const group = new THREE.Group();
    const mat = new THREE.MeshStandardMaterial({color:0x5a4a3a, roughness:0.7});
    const torso = new THREE.Mesh(new THREE.CylinderGeometry(0.28,0.34,0.8,10), mat);
    torso.position.y = 0.85; group.add(torso);
    const apron = new THREE.Mesh(new THREE.BoxGeometry(0.4,0.5,0.06), new THREE.MeshStandardMaterial({color:0xe8e0d0}));
    apron.position.set(0,0.7,0.25); group.add(apron);
    const head = new THREE.Mesh(new THREE.SphereGeometry(0.22,10,10), new THREE.MeshStandardMaterial({color:0xd8b090}));
    head.position.y = 1.42; group.add(head);
    const mustache = new THREE.Mesh(new THREE.BoxGeometry(0.2,0.05,0.05), new THREE.MeshStandardMaterial({color:0x2a1a10}));
    mustache.position.set(0,1.35,0.2); group.add(mustache);
    const eyeMat = new THREE.MeshStandardMaterial({color:0xffffff, emissive:0x333333, emissiveIntensity:0.2});
    const eyeL = new THREE.Mesh(new THREE.SphereGeometry(0.03,6,6), eyeMat); eyeL.position.set(0.08,1.44,0.19); group.add(eyeL);
    const eyeR = new THREE.Mesh(new THREE.SphereGeometry(0.03,6,6), eyeMat); eyeR.position.set(-0.08,1.44,0.19); group.add(eyeR);
    const armL = new THREE.Mesh(new THREE.CylinderGeometry(0.06,0.07,0.55,6), mat); armL.position.set(0.3,0.95,0.1); armL.rotation.z = -0.4; group.add(armL);
    const armR = new THREE.Mesh(new THREE.CylinderGeometry(0.06,0.07,0.55,6), mat); armR.position.set(-0.3,1.0,0); armR.rotation.z = 0.2; group.add(armR);
    group.position.set(x,0,z);
    group.rotation.y = Math.PI;
    return group;
  }
  function buildDiveBar(yOffset){
    yOffset = yOffset || 0;
    const cx = 18, cz = 32, w = 13, d = 13, h = 3.4;
    const roomGroup = new THREE.Group();
    roomGroup.position.set(0, yOffset, 0);
    scene.add(roomGroup);
    const wallMat = new THREE.MeshStandardMaterial({color:0x2a221a, roughness:0.85});
    addBox(cx, cz+d/2, w, h, 0.4, wallMat, 'wall', yOffset);
    addBox(cx-w/2, cz, 0.4, h, d, wallMat, 'wall', yOffset);
    addBox(cx+w/2, cz, 0.4, h, d, wallMat, 'wall', yOffset);
    // open at z- — the entrance

    const signTex = makeNeonTexture('THE LAST CALL', '#ff5a3d');
    const sign = new THREE.Mesh(new THREE.PlaneGeometry(w*0.7,0.8), new THREE.MeshBasicMaterial({map:signTex, transparent:true, side:THREE.DoubleSide}));
    sign.position.set(cx, h+0.05, cz-d/2);
    sign.rotation.y = Math.PI;
    roomGroup.add(sign);
    const signLight = new THREE.PointLight(0xff5a3d, 1.0, 10);
    signLight.position.set(cx, h-0.3, cz-d/2+1);
    roomGroup.add(signLight);

    const counter = new THREE.Mesh(new THREE.BoxGeometry(6,0.95,0.8), new THREE.MeshStandardMaterial({color:0x3a2418, roughness:0.5}));
    counter.position.set(cx, 0.475, cz+d/2-1.2);
    roomGroup.add(counter);
    const counterTop = new THREE.Mesh(new THREE.BoxGeometry(6.1,0.06,0.85), new THREE.MeshStandardMaterial({color:0x1a1008, roughness:0.3, metalness:0.3}));
    counterTop.position.set(cx, 0.98, cz+d/2-1.2);
    roomGroup.add(counterTop);

    const shelfMat = new THREE.MeshStandardMaterial({color:0x2a1c10, roughness:0.6});
    const bottleColors = [0x2a5a3a,0x8a3a1a,0x3a3a8a,0x8a8a1a,0x5a1a3a];
    for(let s=0;s<2;s++){
      const shelf = new THREE.Mesh(new THREE.BoxGeometry(5.6,0.05,0.3), shelfMat);
      shelf.position.set(cx, 1.6+s*0.6, cz+d/2-0.35);
      roomGroup.add(shelf);
      for(let i=0;i<9;i++){
        const bottle = new THREE.Mesh(new THREE.CylinderGeometry(0.05,0.06,0.28,8), new THREE.MeshStandardMaterial({color:bottleColors[i%5], transparent:true, opacity:0.85, roughness:0.2}));
        bottle.position.set(cx-2.6+i*0.6, 1.75+s*0.6, cz+d/2-0.35);
        roomGroup.add(bottle);
      }
    }

    const bartender = buildBartenderFigure(cx, cz+d/2-0.6);
    bartender.rotation.y = Math.PI;
    roomGroup.add(bartender);

    for(let i=0;i<4;i++){
      const sx = cx-3+i*2;
      const stoolSeat = new THREE.Mesh(new THREE.CylinderGeometry(0.22,0.22,0.06,10), new THREE.MeshStandardMaterial({color:0x8a1a1a}));
      stoolSeat.position.set(sx,0.55,cz+d/2-2.0);
      roomGroup.add(stoolSeat);
      const stoolLeg = new THREE.Mesh(new THREE.CylinderGeometry(0.04,0.05,0.55,6), new THREE.MeshStandardMaterial({color:0x2a2a2a}));
      stoolLeg.position.set(sx,0.28,cz+d/2-2.0);
      roomGroup.add(stoolLeg);
    }

    const poolTable = new THREE.Mesh(new THREE.BoxGeometry(2.6,0.8,1.4), new THREE.MeshStandardMaterial({color:0x1a4a2a, roughness:0.7}));
    poolTable.position.set(cx-3.5, 0.4, cz-2.5);
    roomGroup.add(poolTable);
    // rail built as a hollow border frame (4 pieces), not a solid slab, so the felt and balls stay visible
    const railMat = new THREE.MeshStandardMaterial({color:0x3a2418, roughness:0.5});
    const railH = 0.12, railT = 0.12, railY = 0.8+railH/2;
    [-1,1].forEach(side => {
      const railLong = new THREE.Mesh(new THREE.BoxGeometry(2.6+railT*2, railH, railT), railMat);
      railLong.position.set(cx-3.5, railY, cz-2.5 + side*(0.7+railT/2));
      roomGroup.add(railLong);
      const railShort = new THREE.Mesh(new THREE.BoxGeometry(railT, railH, 1.4+railT*2), railMat);
      railShort.position.set(cx-3.5 + side*(1.3+railT/2), railY, cz-2.5);
      roomGroup.add(railShort);
    });
    const ballColors = [0xffe066,0x3a5aff,0xff3a3a,0x8a1aff,0xff8a1a,0x1aff8a,0xaa2222,0x111111,0xffffff];
    for(let i=0;i<9;i++){
      const ang = (i/9)*Math.PI*2;
      const ox = cx-3.5+Math.cos(ang)*0.35, oz = cz-2.5+Math.sin(ang)*0.35;
      const ball = new THREE.Mesh(new THREE.SphereGeometry(0.045,8,8), new THREE.MeshStandardMaterial({color:ballColors[i]}));
      ball.position.set(ox, 0.845, oz);
      roomGroup.add(ball);
      poolBalls.push({mesh:ball, origX:ox, origZ:oz, targetX:ox, targetZ:oz, phase:'idle', phaseStart:0});
    }
    const cue = new THREE.Mesh(new THREE.CylinderGeometry(0.015,0.02,1.4,6), new THREE.MeshStandardMaterial({color:0xc9a15a}));
    cue.position.set(cx-2.0,0.9,cz-2.5); cue.rotation.z = Math.PI/2.3;
    roomGroup.add(cue);
    poolCue = cue; poolCueOrigX = cx-2.0;
    const poolPromptTex = makeSignTexture('PRESS E TO BREAK');
    const poolPrompt = new THREE.Mesh(new THREE.PlaneGeometry(1.3,0.3), new THREE.MeshBasicMaterial({map:poolPromptTex, transparent:true, side:THREE.DoubleSide}));
    poolPrompt.position.set(cx-3.5, 1.6, cz-2.5);
    roomGroup.add(poolPrompt);
    poolTablePos = {x:cx-3.5, z:cz-2.5};

    const jukebox = new THREE.Group();
    const jukeBody = new THREE.Mesh(new THREE.BoxGeometry(0.8,1.4,0.5), new THREE.MeshStandardMaterial({color:0x4a1a1a, roughness:0.4}));
    jukeBody.position.y = 0.7; jukebox.add(jukeBody);
    const jukeGlow = new THREE.Mesh(new THREE.PlaneGeometry(0.6,0.7), new THREE.MeshBasicMaterial({color:0xff5a8a}));
    jukeGlow.position.set(0,0.9,0.26); jukebox.add(jukeGlow);
    const jukeLight = new THREE.PointLight(0xff5a8a,0.7,3);
    jukeLight.position.set(0,0.9,0.5); jukebox.add(jukeLight);
    jukebox.position.set(cx+4, 0, cz-3.5);
    roomGroup.add(jukebox);
    const jukePromptTex = makeSignTexture('PRESS E TO PLAY');
    const jukePrompt = new THREE.Mesh(new THREE.PlaneGeometry(1.2,0.28), new THREE.MeshBasicMaterial({map:jukePromptTex, transparent:true, side:THREE.DoubleSide}));
    jukePrompt.position.set(cx+4, 1.75, cz-3.5);
    roomGroup.add(jukePrompt);
    jukeboxGlow = jukeGlow;
    jukeboxLight = jukeLight;
    jukeboxPos = {x: cx+4, z: cz-3.5};

    const promptTex = makeSignTexture('PRESS E FOR A DRINK');
    const prompt = new THREE.Mesh(new THREE.PlaneGeometry(2.0,0.4), new THREE.MeshBasicMaterial({map:promptTex, transparent:true, side:THREE.DoubleSide}));
    prompt.position.set(cx, 1.7, cz+d/2-2.4);
    prompt.rotation.y = Math.PI;
    roomGroup.add(prompt);

    // wall art
    const dartboard = new THREE.Mesh(new THREE.CircleGeometry(0.5,24), new THREE.MeshStandardMaterial({map: makeDartboardTexture(), roughness:0.7}));
    dartboard.position.set(cx-w/2+0.3, 1.7, cz-4.5);
    dartboard.rotation.y = Math.PI/2;
    roomGroup.add(dartboard);
    const dartPromptTex = makeSignTexture('PRESS E TO THROW DARTS');
    const dartPrompt = new THREE.Mesh(new THREE.PlaneGeometry(1.4,0.3), new THREE.MeshBasicMaterial({map:dartPromptTex, transparent:true, side:THREE.DoubleSide}));
    dartPrompt.position.set(cx-w/2+0.3, 0.85, cz-4.5);
    dartPrompt.rotation.y = Math.PI/2;
    roomGroup.add(dartPrompt);
    dartboardPos = {x: cx-w/2+0.3, z: cz-4.5, y: 1.7};
    diveBarRoomGroup = roomGroup;
    const draftSignTex = makeNeonTexture('COLD DRAFT', '#3dd6ff');
    const draftSign = new THREE.Mesh(new THREE.PlaneGeometry(1.8,0.5), new THREE.MeshBasicMaterial({map:draftSignTex, transparent:true, side:THREE.DoubleSide}));
    draftSign.position.set(cx-w/2+0.3, 2.0, cz-1.3);
    draftSign.rotation.y = Math.PI/2;
    roomGroup.add(draftSign);
    for(let i=0;i<2;i++){
      const poster = new THREE.Mesh(new THREE.PlaneGeometry(0.9,1.2), new THREE.MeshStandardMaterial({map: makeAbstractPosterTexture(i), roughness:0.8}));
      poster.position.set(cx+w/2-0.3, 1.7, cz-5+i*4);
      poster.rotation.y = -Math.PI/2;
      roomGroup.add(poster);
    }

    const roomCeiling = new THREE.Mesh(new THREE.PlaneGeometry(w+2,d+2), new THREE.MeshStandardMaterial({color:0x241c14, roughness:0.9, side:THREE.DoubleSide}));
    roomCeiling.rotation.x = Math.PI/2;
    roomCeiling.position.set(cx, h+0.3, cz);
    roomGroup.add(roomCeiling);

    barPos = {x:cx, z:cz+d/2-2.0};
  }

  function buildKartMuseum(yOffset){
    yOffset = yOffset || 0;
    const cx = -42, cz = -19, w = 14, d = 12, h = 3.4;
    const roomGroup = new THREE.Group();
    roomGroup.position.set(0, yOffset, 0);
    scene.add(roomGroup);
    const wallMat = new THREE.MeshStandardMaterial({color:0x24211c, roughness:0.85});
    addBox(cx-w/2, cz, 0.4, h, d, wallMat, 'wall', yOffset);
    addBox(cx, cz-d/2, w, h, 0.4, wallMat, 'wall', yOffset);
    addBox(cx, cz+d/2, w, h, 0.4, wallMat, 'wall', yOffset);
    // open side at x+ (cx+w/2) — the entrance

    const signTex = makeNeonTexture('CHAOS KART GARAGE', '#ffb020');
    const signMat = new THREE.MeshBasicMaterial({map:signTex, transparent:true, side:THREE.DoubleSide});
    const sign = new THREE.Mesh(new THREE.PlaneGeometry(w*0.8, 0.85), signMat);
    sign.position.set(cx+w/2, h+0.05, cz);
    sign.rotation.y = Math.PI/2;
    roomGroup.add(sign);

    // the whole exhibit row was otherwise unlit — added so the karts and plaques are actually visible
    const garageLight1 = new THREE.PointLight(0xfff0d0, 1.0, 13);
    garageLight1.position.set(cx-w/2+2.5, h-0.3, cz-3);
    roomGroup.add(garageLight1);
    const garageLight2 = new THREE.PointLight(0xfff0d0, 1.0, 13);
    garageLight2.position.set(cx-w/2+2.5, h-0.3, cz+3);
    roomGroup.add(garageLight2);

    const exhibits = [
      {builder: buildRotaryEngine, title:'MAZDA 13B ROTARY', sub:'TWIN-ROTOR WANKEL DESIGN — NO PISTONS AT ALL. SPINS SMOOTH PAST 9000 RPM AND SCREAMS LIKE A SWARM OF ANGRY BEES. STUPID LIGHT FOR THE POWER IT MAKES.',
        driver:"DENNY 'BUZZ' CALLOWAY", dates:'1961 - 1994', cause:'LASTED FOUR LAPS BEFORE THE APEX SEALS ACHIEVED WHAT FOUR EX-WIVES COULD NOT.'},
      {builder: () => buildV8Engine(0x2a4a2a), title:'CHEVY 350 SMALL BLOCK', sub:'PUSHROD V8, 350 CUBIC INCHES OF PURE AMERICANA. CHEAP, SIMPLE, NEARLY IMPOSSIBLE TO KILL — WHICH IS WHY EVERY HOT ROD BUILDER ON EARTH HAS DROPPED ONE INTO SOMETHING IT DID NOT BELONG IN.',
        driver:'EARL TUCKER', dates:'1948 - 1989', cause:'BELIEVED MORE TORQUE SOLVED EVERYTHING. THE OAK TREE AT TURN TWO DISAGREED.'},
      {builder: () => buildV8Engine(0x1a3a6a), title:'FORD 302 WINDSOR', sub:"SMALL-BLOCK V8 FROM THE MUSTANG. LIGHTER AND REVVIER THAN THE BIG-BLOCKS, WITH A HUGE AFTERMARKET — A MUSTANG'S HEART STUFFED INTO A LAWN CHAIR ON WHEELS.",
        driver:'BOBBY JEAN ROSS', dates:'1970 - 1996', cause:'CHASED THE TRACK RECORD FOR THREE STRAIGHT SUMMERS. FOUND THE GUARDRAIL INSTEAD.'},
      {builder: buildHemiEngine, title:'426 HEMI', sub:'HEMISPHERICAL COMBUSTION CHAMBERS LET IT BREATHE LIKE NOTHING ELSE OF ITS ERA. NICKNAMED THE ELEPHANT ENGINE FOR ITS SHEER SIZE AND WEIGHT. NEVER MEANT TO FIT HERE.',
        driver:"'WILD' PETE VANCE", dates:'1955 - 1988', cause:'THE ELEPHANT ENGINE HAD BEEN WAITING PATIENTLY. IT FINALLY GOT ITS REVENGE.'},
      {builder: buildAntiqueEngine, title:'1902 SINGLE-CYLINDER', sub:'ONE MASSIVE PISTON DISPLACING 400 CUBIC INCHES ALL BY ITSELF. LOW-RPM, HIGH-TORQUE, BELT-DRIVEN — BUILT AN ERA BEFORE ANYONE AGREED ON WHAT AN ENGINE SHOULD LOOK LIKE.',
        driver:'CORNELIUS P. ABERNATHY', dates:'1879 - 1902', cause:'FIRST MAN TO REACH TWELVE MILES PER HOUR. ALSO THE LAST.'}
    ];
    exhibits.forEach((ex, i) => {
      const ez = cz + (i-2)*2.1;
      const pedestal = new THREE.Mesh(new THREE.BoxGeometry(2.0,0.3,1.4), new THREE.MeshStandardMaterial({color:0x2a2a2a, roughness:0.7}));
      pedestal.position.set(cx-w/2+2.2, 0.15, ez);
      roomGroup.add(pedestal);
      const kart = buildGoKart(ex.builder());
      kart.position.set(cx-w/2+2.2, 0.3, ez);
      roomGroup.add(kart);
      // both plaques mounted flush on the rear wall, stacked, right beside the adjacent kart
      const placard = new THREE.Mesh(new THREE.PlaneGeometry(1.9,1.05), new THREE.MeshBasicMaterial({map: makePlacardTexture(ex.title, ex.sub), transparent:true, side:THREE.DoubleSide}));
      placard.position.set(cx-w/2+0.3, 2.05, ez);
      placard.rotation.y = Math.PI/2;
      roomGroup.add(placard);
      const memorial = new THREE.Mesh(new THREE.PlaneGeometry(1.3,0.75), new THREE.MeshBasicMaterial({map: makeMemorialTexture(ex.driver, ex.dates, ex.cause), transparent:true, side:THREE.DoubleSide}));
      memorial.position.set(cx-w/2+0.3, 1.15, ez);
      memorial.rotation.y = Math.PI/2;
      roomGroup.add(memorial);
    });

    const roomCeiling = new THREE.Mesh(new THREE.PlaneGeometry(w+2, d+2), new THREE.MeshStandardMaterial({color:0x1e1c18, roughness:0.9, side:THREE.DoubleSide}));
    roomCeiling.rotation.x = Math.PI/2;
    roomCeiling.position.set(cx, h+0.3, cz);
    roomGroup.add(roomCeiling);
  }

  function buildMovieTheater(yOffset){
    yOffset = yOffset || 0;
    const cx = 42, cz = 19, w = 14, d = 12, h = 3.4;
    const roomGroup = new THREE.Group();
    roomGroup.position.set(0, yOffset, 0);
    scene.add(roomGroup);
    const theaterWallMat = new THREE.MeshStandardMaterial({color:0x1a1620, roughness:0.9});
    addBox(cx+w/2, cz, 0.4, h, d, theaterWallMat, 'wall', yOffset);
    addBox(cx, cz-d/2, w, h, 0.4, theaterWallMat, 'wall', yOffset);
    addBox(cx, cz+d/2, w, h, 0.4, theaterWallMat, 'wall', yOffset);
    // open side at x- (cx-w/2) — the entrance

    const signTex = makeNeonTexture('MIDNIGHT SCREENING', '#ff2f2f');
    const signMat = new THREE.MeshBasicMaterial({map:signTex, transparent:true, side:THREE.DoubleSide});
    const sign = new THREE.Mesh(new THREE.PlaneGeometry(w*0.85, 0.8), signMat);
    sign.position.set(cx-w/2, h+0.05, cz);
    sign.rotation.y = -Math.PI/2;
    roomGroup.add(sign);

    movieScreen = buildMovieScreen(4.2, 2.6);
    movieScreen.mesh.position.set(cx+w/2-0.5, 1.9, cz);
    movieScreen.mesh.rotation.y = -Math.PI/2;
    roomGroup.add(movieScreen.mesh);
    const screenFrame = new THREE.Mesh(new THREE.BoxGeometry(0.1,2.8,4.4), new THREE.MeshStandardMaterial({color:0x0a0a0a}));
    screenFrame.position.set(cx+w/2-0.4, 1.9, cz);
    roomGroup.add(screenFrame);

    function addSeatRow(rx, cz0, count, spacing, color){
      const seatMat = new THREE.MeshStandardMaterial({color, roughness:0.85});
      for(let i=0;i<count;i++){
        const z = cz0 + (i-(count-1)/2)*spacing;
        const seatBase = new THREE.Mesh(new THREE.BoxGeometry(0.55,0.45,0.55), seatMat);
        seatBase.position.set(rx,0.225,z);
        roomGroup.add(seatBase);
        const seatBack = new THREE.Mesh(new THREE.BoxGeometry(0.1,0.6,0.55), seatMat);
        seatBack.position.set(rx-0.28,0.55,z);
        roomGroup.add(seatBack);
      }
    }
    addSeatRow(cx-3, cz, 4, 1.4, 0x3a1a2a);
    addSeatRow(cx, cz, 4, 1.4, 0x3a1a2a);
    addSeatRow(cx+3, cz, 4, 1.4, 0x3a1a2a);

    roomGroup.add(buildPopcornMachine(cx-w/2+1.4, cz-d/2+1.4));

    const roomCeiling = new THREE.Mesh(new THREE.PlaneGeometry(w+2, d+2), new THREE.MeshStandardMaterial({color:0x14121a, roughness:0.9, side:THREE.DoubleSide}));
    roomCeiling.rotation.x = Math.PI/2;
    roomCeiling.position.set(cx, h+0.3, cz);
    roomGroup.add(roomCeiling);
  }

  function buildOldTV(x,z,rotY){
    const group = new THREE.Group();
    const cabinet = new THREE.Mesh(new THREE.BoxGeometry(0.6,0.5,0.55), new THREE.MeshStandardMaterial({color:0x3a2a1a, roughness:0.6}));
    cabinet.position.y = 0.25; group.add(cabinet);
    const screenBezel = new THREE.Mesh(new THREE.BoxGeometry(0.5,0.4,0.05), new THREE.MeshStandardMaterial({color:0x111111}));
    screenBezel.position.set(0,0.3,0.26); group.add(screenBezel);
    const screen = new THREE.Mesh(new THREE.PlaneGeometry(0.42,0.32), new THREE.MeshBasicMaterial({map: makeArcadeScreenTexture(Math.floor(Math.random()*5))}));
    screen.position.set(0,0.3,0.285); group.add(screen);
    const antennaMat = new THREE.MeshStandardMaterial({color:0x888888, metalness:0.6});
    const antL = new THREE.Mesh(new THREE.CylinderGeometry(0.008,0.008,0.3,4), antennaMat);
    antL.position.set(-0.1,0.65,0); antL.rotation.z = 0.3; group.add(antL);
    const antR = new THREE.Mesh(new THREE.CylinderGeometry(0.008,0.008,0.3,4), antennaMat);
    antR.position.set(0.1,0.65,0); antR.rotation.z = -0.3; group.add(antR);
    group.position.set(x,0,z); group.rotation.y = rotY;
    return group;
  }
  function buildClothesRack(x,z,rotY){
    const group = new THREE.Group();
    const postMat = new THREE.MeshStandardMaterial({color:0x888888, metalness:0.6});
    const postL = new THREE.Mesh(new THREE.CylinderGeometry(0.025,0.025,1.4,8), postMat); postL.position.set(-0.9,0.7,0); group.add(postL);
    const postR = new THREE.Mesh(new THREE.CylinderGeometry(0.025,0.025,1.4,8), postMat); postR.position.set(0.9,0.7,0); group.add(postR);
    const bar = new THREE.Mesh(new THREE.CylinderGeometry(0.02,0.02,1.9,8), postMat); bar.rotation.z = Math.PI/2; bar.position.set(0,1.35,0); group.add(bar);
    const baseL = new THREE.Mesh(new THREE.CylinderGeometry(0.15,0.15,0.04,10), postMat); baseL.position.set(-0.9,0.02,0); group.add(baseL);
    const baseR = new THREE.Mesh(new THREE.CylinderGeometry(0.15,0.15,0.04,10), postMat); baseR.position.set(0.9,0.02,0); group.add(baseR);
    const shirtColors = [0xaa3333,0x3355aa,0x33aa55,0xaaaa33,0x8833aa,0xaa6633];
    for(let i=0;i<8;i++){
      const shirt = new THREE.Mesh(new THREE.BoxGeometry(0.18,0.5,0.32), new THREE.MeshStandardMaterial({color:shirtColors[i%shirtColors.length], roughness:0.8}));
      shirt.position.set(-0.8+i*0.23, 1.0, 0);
      group.add(shirt);
      const hanger = new THREE.Mesh(new THREE.TorusGeometry(0.05,0.008,4,8,Math.PI), new THREE.MeshStandardMaterial({color:0x555555}));
      hanger.position.set(-0.8+i*0.23,1.28,0); hanger.rotation.x = Math.PI/2;
      group.add(hanger);
    }
    group.position.set(x,0,z); group.rotation.y = rotY;
    return group;
  }
  function buildToolbox(x,z){
    const group = new THREE.Group();
    const body = new THREE.Mesh(new THREE.BoxGeometry(0.7,0.35,0.4), new THREE.MeshStandardMaterial({color:0xcc2222, roughness:0.4, metalness:0.3}));
    body.position.y = 0.2; group.add(body);
    const lid = new THREE.Mesh(new THREE.BoxGeometry(0.72,0.08,0.42), new THREE.MeshStandardMaterial({color:0xaa1a1a, roughness:0.4, metalness:0.3}));
    lid.position.y = 0.4; group.add(lid);
    const handle = new THREE.Mesh(new THREE.TorusGeometry(0.12,0.02,6,12,Math.PI), new THREE.MeshStandardMaterial({color:0x333333}));
    handle.position.set(0,0.48,0); handle.rotation.z = Math.PI; group.add(handle);
    for(let i=0;i<3;i++){
      const drawer = new THREE.Mesh(new THREE.BoxGeometry(0.6,0.02,0.02), new THREE.MeshStandardMaterial({color:0x888888}));
      drawer.position.set(0,0.1+i*0.09,0.21); group.add(drawer);
    }
    group.position.set(x,0,z);
    return group;
  }
  function buildPegboardTools(x,z,rotY){
    const group = new THREE.Group();
    const board = new THREE.Mesh(new THREE.BoxGeometry(2.4,1.6,0.05), new THREE.MeshStandardMaterial({color:0xb0aca0, roughness:0.8}));
    group.add(board);
    const toolMat = new THREE.MeshStandardMaterial({color:0x444444, metalness:0.6, roughness:0.3});
    for(let i=0;i<4;i++){
      const wrench = new THREE.Mesh(new THREE.CylinderGeometry(0.015,0.015,0.35,6), toolMat);
      wrench.position.set(-0.9+i*0.25, 0.3, 0.06);
      wrench.rotation.z = Math.PI/2 + 0.3;
      group.add(wrench);
    }
    for(let i=0;i<3;i++){
      const hammerHandle = new THREE.Mesh(new THREE.CylinderGeometry(0.015,0.02,0.3,6), new THREE.MeshStandardMaterial({color:0x6a4a2a}));
      hammerHandle.position.set(-0.4+i*0.4, -0.2, 0.06);
      hammerHandle.rotation.z = Math.PI/2;
      group.add(hammerHandle);
      const hammerHead = new THREE.Mesh(new THREE.BoxGeometry(0.15,0.06,0.06), toolMat);
      hammerHead.position.set(-0.55+i*0.4, -0.2, 0.06);
      group.add(hammerHead);
    }
    group.position.set(x,0,z); group.rotation.y = rotY;
    return group;
  }

  function buildSears(yOffset){
    yOffset = yOffset || 0;
    const cx = -18, cz = -20, w = 22, d = 16, h = 3.4;
    const roomGroup = new THREE.Group();
    roomGroup.position.set(0, yOffset, 0);
    scene.add(roomGroup);
    const searsWallMat = new THREE.MeshStandardMaterial({color:0xc8c4b8, roughness:0.85});
    addBox(cx+w/2, cz, 0.4, h, d, searsWallMat, 'wall', yOffset);
    addBox(cx, cz-d/2, w, h, 0.4, searsWallMat, 'wall', yOffset);
    addBox(cx, cz+d/2, w, h, 0.4, searsWallMat, 'wall', yOffset);
    // open side at x- (cx-w/2) — the entrance, facing the kart museum next door

    const signTex = makeNeonTexture('SEARS', '#2255aa');
    const signMat = new THREE.MeshBasicMaterial({map:signTex, transparent:true, side:THREE.DoubleSide});
    const sign = new THREE.Mesh(new THREE.PlaneGeometry(w*0.45, 1.1), signMat);
    sign.position.set(cx-w/2, h+0.15, cz);
    sign.rotation.y = -Math.PI/2;
    roomGroup.add(sign);

    // 80s TV section along the back-right wall
    const tvSignTex = makeSignTexture('TELEVISIONS');
    const tvSign = new THREE.Mesh(new THREE.PlaneGeometry(2.2,0.45), new THREE.MeshBasicMaterial({map:tvSignTex, transparent:true}));
    tvSign.position.set(cx+w/2-2.4, 1.9, cz-5.6);
    tvSign.rotation.y = -Math.PI/2;
    roomGroup.add(tvSign);
    const tvCounter = new THREE.Mesh(new THREE.BoxGeometry(0.7,0.5,6.2), new THREE.MeshStandardMaterial({color:0x4a3a2a, roughness:0.6}));
    tvCounter.position.set(cx+w/2-1.1, 0.25, cz-3.75);
    roomGroup.add(tvCounter);
    for(let i=0;i<6;i++){
      const tv = buildOldTV(cx+w/2-1.1, cz-6.5+i*1.1, -Math.PI/2);
      tv.position.y = 0.5;
      roomGroup.add(tv);
    }

    // Craftsman tools section along the back-right wall
    const toolsSignTex = makeSignTexture('CRAFTSMAN TOOLS');
    const toolsSign = new THREE.Mesh(new THREE.PlaneGeometry(2.4,0.45), new THREE.MeshBasicMaterial({map:toolsSignTex, transparent:true}));
    toolsSign.position.set(cx+w/2-2.4, 1.9, cz+5.6);
    toolsSign.rotation.y = -Math.PI/2;
    roomGroup.add(toolsSign);
    roomGroup.add(buildPegboardTools(cx+w/2-0.35, cz+5, -Math.PI/2));
    roomGroup.add(buildPegboardTools(cx+w/2-0.35, cz+2.5, -Math.PI/2));
    const toolBench = new THREE.Mesh(new THREE.BoxGeometry(0.9,0.8,4.4), new THREE.MeshStandardMaterial({color:0x5a5a5a, roughness:0.5, metalness:0.3}));
    toolBench.position.set(cx+w/2-1.3, 0.4, cz+4);
    roomGroup.add(toolBench);
    [2.5,4.0,5.5].forEach(tz => {
      const tb = buildToolbox(cx+w/2-1.3, cz+tz);
      tb.position.y = 0.8; // sitting up on the workbench, not on the floor
      roomGroup.add(tb);
    });

    // open clothes-rack aisle near the entrance
    [[cx-3,cz-4],[cx-3,cz+4],[cx-8,cz-4],[cx-8,cz+4]].forEach(([rx,rz],i) => {
      roomGroup.add(buildClothesRack(rx, rz, i%2===0 ? 0 : Math.PI/2));
    });

    const roomCeiling = new THREE.Mesh(new THREE.PlaneGeometry(w+2, d+2), new THREE.MeshStandardMaterial({color:0xb8b4a8, roughness:0.9, side:THREE.DoubleSide}));
    roomCeiling.rotation.x = Math.PI/2;
    roomCeiling.position.set(cx, h+0.3, cz);
    roomGroup.add(roomCeiling);

    const searsLight1 = new THREE.PointLight(0xf0ece0, 0.9, 14);
    searsLight1.position.set(cx+4, h-0.2, cz-4);
    roomGroup.add(searsLight1);
    const searsLight2 = new THREE.PointLight(0xf0ece0, 0.9, 14);
    searsLight2.position.set(cx+4, h-0.2, cz+4);
    roomGroup.add(searsLight2);
  }

  function buildKmart(yOffset){
    yOffset = yOffset || 0;
    const cx = -35, cz = 35, w = 22, d = 26, h = 3.4;
    const roomGroup = new THREE.Group();
    roomGroup.position.set(0, yOffset, 0);
    scene.add(roomGroup);
    const kmartWallMat = new THREE.MeshStandardMaterial({color:0xdedcd0, roughness:0.9});
    addBox(cx, cz-d/2, w, h, 0.4, kmartWallMat, 'wall', yOffset);
    addBox(cx-w/2, cz, 0.4, h, d, kmartWallMat, 'wall', yOffset);
    addBox(cx+w/2, cz, 0.4, h, d, kmartWallMat, 'wall', yOffset);

    const signTex = makeNeonTexture('KMART', '#e2231a');
    const signMat = new THREE.MeshBasicMaterial({map:signTex, transparent:true, side:THREE.DoubleSide});
    const sign = new THREE.Mesh(new THREE.PlaneGeometry(w*0.5, 1.0), signMat);
    sign.position.set(cx, h+0.15, cz-d/2);
    sign.rotation.y = Math.PI;
    roomGroup.add(sign);

    const floor = new THREE.Mesh(new THREE.PlaneGeometry(w-0.4, d-0.4), new THREE.MeshStandardMaterial({map: makeLiminalFloorTexture(), roughness:0.95}));
    floor.rotation.x = -Math.PI/2;
    floor.position.set(cx, 0.01, cz);
    roomGroup.add(floor);

    function addShelfUnit(x,z,rotY){
      const group = new THREE.Group();
      const frameMat = new THREE.MeshStandardMaterial({color:0x8a8478, roughness:0.6, metalness:0.3});
      for(let i=0;i<4;i++){
        const shelf = new THREE.Mesh(new THREE.BoxGeometry(2.2,0.05,0.6), frameMat);
        shelf.position.y = 0.3+i*0.6;
        group.add(shelf);
      }
      const postGeo = new THREE.CylinderGeometry(0.04,0.04,2.1,6);
      [[1.05,0.28],[-1.05,0.28],[1.05,-0.28],[-1.05,-0.28]].forEach(([px,pz]) => {
        const post = new THREE.Mesh(postGeo, frameMat);
        post.position.set(px,1.1,pz);
        group.add(post);
      });
      group.position.set(x,0,z); group.rotation.y = rotY;
      roomGroup.add(group);
    }
    [[-7,25],[-2,25],[3,25],[-7,33],[-2,33],[3,33],[-7,41],[-2,41],[3,41]].forEach(([sx,sz]) => addShelfUnit(cx+sx, sz, 0));

    function addSportingGoods(x,y,z){
      const ball = new THREE.Mesh(new THREE.SphereGeometry(0.12,10,10), new THREE.MeshStandardMaterial({color:0xd2691e, roughness:0.7}));
      ball.position.set(x-0.4,y+0.1,z);
      roomGroup.add(ball);
      const football = new THREE.Mesh(new THREE.SphereGeometry(0.1,10,10), new THREE.MeshStandardMaterial({color:0x5a3a20, roughness:0.6}));
      football.scale.set(1.6,1,1); football.rotation.z = 0.3;
      football.position.set(x,y+0.08,z);
      roomGroup.add(football);
      const bat = new THREE.Mesh(new THREE.CylinderGeometry(0.02,0.045,0.7,8), new THREE.MeshStandardMaterial({color:0xc8a060, roughness:0.5}));
      bat.rotation.z = Math.PI/2;
      bat.position.set(x+0.5,y+0.1,z);
      roomGroup.add(bat);
      const racketHandle = new THREE.Mesh(new THREE.CylinderGeometry(0.015,0.015,0.25,6), new THREE.MeshStandardMaterial({color:0x222222}));
      racketHandle.position.set(x+0.85,y,z);
      roomGroup.add(racketHandle);
      const racketHead = new THREE.Mesh(new THREE.TorusGeometry(0.13,0.02,6,16), new THREE.MeshStandardMaterial({color:0xdddddd}));
      racketHead.position.set(x+0.85,y+0.2,z);
      roomGroup.add(racketHead);
    }
    [[-7,25],[-7,33],[-7,41]].forEach(([sx,sz]) => addSportingGoods(cx+sx, 0.9, sz));

    function makeBlueLightPosterTexture(){
      const c = document.createElement('canvas'); c.width = 300; c.height = 200;
      const ctx = c.getContext('2d');
      ctx.fillStyle = '#0a1030'; ctx.fillRect(0,0,300,200);
      const grad = ctx.createRadialGradient(150,60,5,150,60,140);
      grad.addColorStop(0,'rgba(80,140,255,0.9)'); grad.addColorStop(1,'rgba(10,20,60,0)');
      ctx.fillStyle = grad; ctx.beginPath(); ctx.arc(150,60,140,0,Math.PI*2); ctx.fill();
      ctx.fillStyle = '#fff'; ctx.font = '900 20px Arial'; ctx.textAlign = 'center';
      ctx.fillText('ATTENTION KMART SHOPPERS', 150, 120);
      ctx.font = '900 26px Arial'; ctx.fillStyle = '#ffe066';
      ctx.fillText('BLUE LIGHT SPECIAL', 150, 155);
      ctx.font = '14px Arial'; ctx.fillStyle = '#bcd4ff';
      ctx.fillText('AISLE 7 — SAVINGS YOU CAN SEE', 150, 180);
      return new THREE.CanvasTexture(c);
    }
    function makeSnackBarTexture(){
      const c = document.createElement('canvas'); c.width = 300; c.height = 180;
      const ctx = c.getContext('2d');
      ctx.fillStyle = '#7a1620'; ctx.fillRect(0,0,300,180);
      ctx.fillStyle = '#fff'; ctx.font = '900 28px Arial'; ctx.textAlign = 'center';
      ctx.fillText('SNACK BAR', 150, 45);
      ctx.font = '900 20px Arial'; ctx.fillStyle = '#ffe066';
      ctx.fillText('FROZEN COKE • ICEE • SLUSH', 150, 95);
      ctx.font = '900 24px Arial'; ctx.fillStyle = '#fff';
      ctx.fillText('50¢', 150, 135);
      ctx.font = '13px Arial'; ctx.fillStyle = '#ffd0d0';
      ctx.fillText('WHILE SUPPLIES LAST', 150, 160);
      return new THREE.CanvasTexture(c);
    }
    const blueLightPoster = new THREE.Mesh(new THREE.PlaneGeometry(2.2,1.5), new THREE.MeshBasicMaterial({map: makeBlueLightPosterTexture(), transparent:true, side:THREE.DoubleSide}));
    blueLightPoster.position.set(cx-w/2+0.3, 2.0, 29);
    blueLightPoster.rotation.y = Math.PI/2;
    roomGroup.add(blueLightPoster);
    const snackBarPoster = new THREE.Mesh(new THREE.PlaneGeometry(2.0,1.2), new THREE.MeshBasicMaterial({map: makeSnackBarTexture(), transparent:true, side:THREE.DoubleSide}));
    snackBarPoster.position.set(cx-w/2+0.3, 2.0, 42);
    snackBarPoster.rotation.y = Math.PI/2;
    roomGroup.add(snackBarPoster);

    // spinning blue light beacon, right under the special
    const blueLightDome = new THREE.Mesh(new THREE.SphereGeometry(0.18,12,8,0,Math.PI*2,0,Math.PI/2), new THREE.MeshStandardMaterial({color:0x2255ff, emissive:0x2255ff, emissiveIntensity:0.8, transparent:true, opacity:0.85}));
    blueLightDome.position.set(cx-6, 2.3, 29);
    blueLightDome.rotation.x = Math.PI;
    roomGroup.add(blueLightDome);
    const bluePole = new THREE.Mesh(new THREE.CylinderGeometry(0.03,0.03,0.6,8), new THREE.MeshStandardMaterial({color:0x333333}));
    bluePole.position.set(cx-6, 1.9, 29);
    roomGroup.add(bluePole);
    (function scheduleBlueFlicker(){
      const delay = 200 + Math.random()*500;
      setTimeout(() => {
        blueLightDome.material.emissiveIntensity = blueLightDome.material.emissiveIntensity > 0.4 ? 0.15 : 0.8;
        scheduleBlueFlicker();
      }, delay);
    })();

    const kmartLights = [];
    [[cx-6,25],[cx+2,33],[cx-4,44]].forEach(([lx,lz]) => {
      const fixture = new THREE.Mesh(new THREE.BoxGeometry(1.6,0.08,0.5), new THREE.MeshStandardMaterial({color:0xe8e4d0, emissive:0xe8e4d0, emissiveIntensity:0.5}));
      fixture.position.set(lx, h-0.05, lz);
      roomGroup.add(fixture);
      const light = new THREE.PointLight(0xe8e4d0, 0.35, 10);
      light.position.set(lx, h-0.2, lz);
      roomGroup.add(light);
      kmartLights.push({light, fixture, base:0.35});
    });
    kmartLights.forEach(kl => {
      (function schedule(){
        const delay = 500 + Math.random()*4000;
        setTimeout(() => {
          const dim = Math.random() < 0.6;
          kl.light.intensity = dim ? 0.03 : kl.base;
          kl.fixture.material.emissiveIntensity = dim ? 0.05 : 0.5;
          schedule();
        }, delay);
      })();
    });

    const roomCeiling = new THREE.Mesh(new THREE.PlaneGeometry(w+2, d+2), new THREE.MeshStandardMaterial({color:0xcac6b8, roughness:0.9, side:THREE.DoubleSide}));
    roomCeiling.rotation.x = Math.PI/2;
    roomCeiling.position.set(cx, h+0.3, cz);
    roomGroup.add(roomCeiling);

    const figureA = buildCreepyFigure(cx+w/2-2, cz+d/2-2, Math.PI*0.75);
    roomGroup.add(figureA.group);
    registerCreepyFigure(figureA);
    const figureB = buildCreepyFigure(cx-w/2+2, cz-d/2+2, -Math.PI*0.25);
    roomGroup.add(figureB.group);
    registerCreepyFigure(figureB);
  }

  function makePosterTexture(title, colorA, colorB){
    const c = document.createElement('canvas'); c.width = 220; c.height = 320;
    const ctx = c.getContext('2d');
    const grad = ctx.createLinearGradient(0,0,0,320);
    grad.addColorStop(0, colorA); grad.addColorStop(1, colorB);
    ctx.fillStyle = grad; ctx.fillRect(0,0,220,320);
    ctx.fillStyle = 'rgba(0,0,0,0.3)';
    for(let i=0;i<40;i++) ctx.fillRect(Math.random()*220, Math.random()*320, 2, 2);
    ctx.strokeStyle = 'rgba(255,255,255,0.4)'; ctx.lineWidth = 4; ctx.strokeRect(6,6,208,308);
    ctx.fillStyle = '#fff'; ctx.font = 'bold 24px Arial'; ctx.textAlign = 'center';
    ctx.fillText(title, 110, 280);
    return new THREE.CanvasTexture(c);
  }
  function addPoster(x,y,z,rotY,title,colorA,colorB){
    const mat = new THREE.MeshBasicMaterial({map: makePosterTexture(title, colorA, colorB)});
    const poster = new THREE.Mesh(new THREE.PlaneGeometry(1.1,1.6), mat);
    poster.position.set(x,y,z); poster.rotation.y = rotY;
    scene.add(poster);
  }

  function makeGraffitiTexture(){
    const c = document.createElement('canvas'); c.width = 400; c.height = 200;
    const ctx = c.getContext('2d');
    const colors = ['#ff2f8a','#2fe0ff','#8bff2f','#ffae2f'];
    ctx.font = 'italic bold 58px Arial';
    ctx.fillStyle = colors[Math.floor(Math.random()*colors.length)];
    ctx.save(); ctx.translate(200,100); ctx.rotate(-0.08); ctx.textAlign = 'center';
    ctx.fillText('DEAD MALL', 0, 0);
    ctx.restore();
    return new THREE.CanvasTexture(c);
  }
  function addGraffiti(x,y,z,rotY,w,hgt){
    const mat = new THREE.MeshBasicMaterial({map: makeGraffitiTexture(), transparent:true});
    const g = new THREE.Mesh(new THREE.PlaneGeometry(w,hgt), mat);
    g.position.set(x,y,z); g.rotation.y = rotY;
    scene.add(g);
  }

  function makeDirectoryTexture(){
    const c = document.createElement('canvas'); c.width = 280; c.height = 400;
    const ctx = c.getContext('2d');
    ctx.fillStyle = '#e8e2d0'; ctx.fillRect(0,0,280,400);
    ctx.fillStyle = '#222'; ctx.font = 'bold 20px Arial'; ctx.textAlign = 'center';
    ctx.fillText('MALL DIRECTORY', 140, 32);
    ctx.font = '14px Arial'; ctx.textAlign = 'left';
    const list = ['1. Sears .......... N Wing','2. RadioShack ..... E Wing','3. Waldenbooks .... S Wing','4. Galaxy Arcade .. NE Court','5. Starlite Pizza .. SE Court','6. Restrooms ...... behind fountain','','YOU ARE HERE ►','(fountain court)'];
    list.forEach((line,i) => ctx.fillText(line, 15, 72+i*27));
    return new THREE.CanvasTexture(c);
  }
  function buildDirectorySign(x,z){
    const post = new THREE.Mesh(new THREE.BoxGeometry(1.6,2.2,0.15), new THREE.MeshStandardMaterial({color:0x2a2a2a}));
    post.position.set(x,1.1,z); scene.add(post);
    const panel = new THREE.Mesh(new THREE.PlaneGeometry(1.4,2.0), new THREE.MeshBasicMaterial({map: makeDirectoryTexture()}));
    panel.position.set(x,1.1,z+0.09); scene.add(panel);
    const panelBack = new THREE.Mesh(new THREE.PlaneGeometry(1.4,2.0), new THREE.MeshBasicMaterial({map: makeDirectoryTexture()}));
    panelBack.position.set(x,1.1,z-0.09); panelBack.rotation.y = Math.PI; scene.add(panelBack);
  }

  function addVendingMachine(x,z,rotY,color){
    const body = new THREE.Mesh(new THREE.BoxGeometry(0.7,1.8,0.65), new THREE.MeshStandardMaterial({color, roughness:0.4}));
    body.position.set(x,0.9,z); body.rotation.y = rotY; scene.add(body);
    const panel = new THREE.Mesh(new THREE.PlaneGeometry(0.5,1.3), new THREE.MeshBasicMaterial({color:0xdfefff}));
    panel.position.set(x + Math.sin(rotY)*0.33, 0.95, z + Math.cos(rotY)*0.33);
    panel.rotation.y = rotY; scene.add(panel);
  }


  function buildArcadeRoom(yOffset){
    yOffset = yOffset || 0;
    const cx = 35, cz = 35, w = 18, d = 18, h = 3.4;
    const roomGroup = new THREE.Group();
    roomGroup.position.set(0, yOffset, 0);
    scene.add(roomGroup);
    const arcadeWallMat = new THREE.MeshStandardMaterial({color:0x1c1a22, roughness:0.85});
    addBox(cx, cz+d/2, w, h, 0.4, arcadeWallMat, 'wall', yOffset);
    addBox(cx-w/2, cz, 0.4, h, d, arcadeWallMat, 'wall', yOffset);
    addBox(cx+w/2, cz, 0.4, h, d, arcadeWallMat, 'wall', yOffset);

    const neonTex = makeNeonTexture('GALAXY ARCADE', '#ff2fd6');
    const neonMat = new THREE.MeshBasicMaterial({map:neonTex, transparent:true, side:THREE.DoubleSide});
    const neonSign = new THREE.Mesh(new THREE.PlaneGeometry(w*0.6, 1.0), neonMat);
    neonSign.position.set(cx, h+0.1, cz-d/2);
    neonSign.rotation.y = Math.PI;
    roomGroup.add(neonSign);
    const neonLight = new THREE.PointLight(0xff2fd6, 1.6, 13);
    neonLight.position.set(cx, h, cz-d/2+0.3);
    roomGroup.add(neonLight);
    (function scheduleNeonFlicker(){
      const delay = 300 + Math.random()*3000;
      setTimeout(() => {
        const dim = Math.random() < 0.35;
        neonLight.intensity = dim ? 0.15 : 1.6;
        neonMat.opacity = dim ? 0.35 : 1;
        scheduleNeonFlicker();
      }, delay);
    })();

    const neonTex2 = makeNeonTexture('SKEE-BALL', '#2fe0ff');
    const neonMat2 = new THREE.MeshBasicMaterial({map:neonTex2, transparent:true, side:THREE.DoubleSide});
    const neonSign2 = new THREE.Mesh(new THREE.PlaneGeometry(2.6, 0.5), neonMat2);
    neonSign2.position.set(cx-w/2+0.3, 2.4, cz-d/2+2.5); neonSign2.rotation.y = Math.PI/2;
    roomGroup.add(neonSign2);

    // 10 upright cabinets lining the back wall
    const cabColors = [0xff2fd6, 0x2fe0ff, 0x8bff2f, 0xffae2f, 0xb92fff, 0x2fffe0, 0xff5a5a, 0x5ac8ff, 0xffe64a, 0xa0ff5a];
    const cabGameNames = ['PADDLE WARS','VECTOR VOID','MAZE CHASE','BLOCK INVADERS','STAR DUEL','GRID RACER','LASER ORBIT','MOON PATROL 2','CRYSTAL QUEST','TURBO GRAND PRIX'];
    for(let i=0;i<10;i++){
      const cabX = cx + (i-4.5)*1.7;
      const cabZ = cz+d/2-0.65;
      const cab = buildArcadeCabinet(cabX, cabZ, Math.PI, cabColors[i], cabGameNames[i], i%5);
      roomGroup.add(cab);
    }

    // 5 pinball machines lining the right wall
    const pinballColors = [0xff2f6a, 0x2fff8a, 0xffe62f, 0x2fd0ff, 0xff8a3d];
    for(let i=0;i<5;i++){
      roomGroup.add(buildPinball(cx+w/2-0.85, cz+(i-2)*2.4, -Math.PI/2, pinballColors[i]));
    }

    // claw machine near the entrance
    const clawX = cx-w/2+1.6, clawZ = cz-d/2+1.6;
    const claw = new THREE.Mesh(new THREE.BoxGeometry(0.9,1.6,0.9), new THREE.MeshStandardMaterial({color:0xbfe8ff, transparent:true, opacity:0.22, roughness:0.1}));
    claw.position.set(clawX, 0.8, clawZ);
    roomGroup.add(claw);
    const prizeColors = [0xff5a5a,0x5aff8a,0x5a8aff,0xffe65a];
    for(let i=0;i<8;i++){
      const prize = new THREE.Mesh(new THREE.SphereGeometry(0.11,6,6), new THREE.MeshStandardMaterial({color:prizeColors[i%4]}));
      prize.position.set(clawX+(Math.random()-0.5)*0.5, 0.25+Math.random()*0.5, clawZ+(Math.random()-0.5)*0.5);
      roomGroup.add(prize);
    }
    const clawArm = new THREE.Mesh(new THREE.CylinderGeometry(0.05,0.05,0.35,6), new THREE.MeshStandardMaterial({color:0x888888, metalness:0.6}));
    clawArm.position.set(clawX, 1.55, clawZ);
    roomGroup.add(clawArm);

    const counter = new THREE.Mesh(new THREE.BoxGeometry(2.4,0.9,0.7), new THREE.MeshStandardMaterial({color:0x2a2a30, roughness:0.6}));
    counter.position.set(cx+2.4, 0.45, cz-d/2+0.9);
    roomGroup.add(counter);

    // animatronic stage along the left wall
    const stageX = cx-w/2+1.4, stageZ = cz;
    const stage = new THREE.Mesh(new THREE.BoxGeometry(2.2,0.3,5.4), new THREE.MeshStandardMaterial({color:0x33302a, roughness:0.8}));
    stage.position.set(stageX, 0.15, stageZ);
    roomGroup.add(stage);
    const spot = new THREE.PointLight(0xbfffcf, 1.2, 9);
    spot.position.set(stageX, 3.2, stageZ);
    roomGroup.add(spot);
    const bear = buildAnimatronic(stageX+0.6, stageZ-1.3, 0x8a6a3a, 'bear');
    bear.group.rotation.y = Math.PI/2 + (Math.random()-0.5)*0.3;
    roomGroup.add(bear.group);
    animatronics.push(bear);
    const rabbit = buildAnimatronic(stageX+0.6, stageZ+1.3, 0xc9c2a0, 'rabbit');
    rabbit.group.rotation.y = Math.PI/2 + (Math.random()-0.5)*0.3;
    roomGroup.add(rabbit.group);
    animatronics.push(rabbit);
    const rug = new THREE.Mesh(new THREE.PlaneGeometry(3.0,4.0), new THREE.MeshStandardMaterial({map: makeRugTexture(), roughness:0.95}));
    rug.rotation.x = -Math.PI/2;
    rug.position.set(stageX+2.8, 0.02, stageZ);
    roomGroup.add(rug);
    storyTriggerPos = {x: stageX+2.8, z: stageZ};

    const roomCeiling = new THREE.Mesh(new THREE.PlaneGeometry(w+2, d+2), new THREE.MeshStandardMaterial({color:0x2a2820, roughness:0.9, side:THREE.DoubleSide}));
    roomCeiling.rotation.x = Math.PI/2;
    roomCeiling.position.set(cx, h+0.3, cz);
    roomGroup.add(roomCeiling);
  }

  function addStoreShell(cx, cz, w, d, h, openSide, signText){
    if(openSide !== 'z-') addBox(cx, cz-d/2, w, h, 0.4, wallMat, 'wall');
    if(openSide !== 'z+') addBox(cx, cz+d/2, w, h, 0.4, wallMat, 'wall');
    if(openSide !== 'x-') addBox(cx-w/2, cz, 0.4, h, d, wallMat, 'wall');
    if(openSide !== 'x+') addBox(cx+w/2, cz, 0.4, h, d, wallMat, 'wall');
    let signW, pos, rotY = 0;
    if(openSide === 'z-'){ signW = w*0.85; pos = [cx, h+0.05, cz-d/2]; rotY = Math.PI; }
    else if(openSide === 'z+'){ signW = w*0.85; pos = [cx, h+0.05, cz+d/2]; rotY = 0; }
    else if(openSide === 'x-'){ signW = d*0.85; pos = [cx-w/2, h+0.05, cz]; rotY = -Math.PI/2; }
    else { signW = d*0.85; pos = [cx+w/2, h+0.05, cz]; rotY = Math.PI/2; }
    if(signText){
      const tex = makeSignTexture(signText);
      const mat = new THREE.MeshBasicMaterial({map:tex, transparent:true, side:THREE.DoubleSide});
      const sign = new THREE.Mesh(new THREE.PlaneGeometry(signW, 0.6), mat);
      sign.position.set(pos[0], pos[1], pos[2]);
      sign.rotation.y = rotY;
      scene.add(sign);
    }
    if(Math.random() < 0.4){
      const leaseTex = makeLeaseTexture();
      const leaseMat = new THREE.MeshBasicMaterial({map:leaseTex, transparent:true, side:THREE.DoubleSide});
      const leaseSign = new THREE.Mesh(new THREE.PlaneGeometry(signW*0.55, 0.9), leaseMat);
      leaseSign.position.set(pos[0], h*0.42, pos[2]);
      leaseSign.rotation.y = rotY;
      leaseSign.rotation.z = (Math.random()-0.5)*0.15;
      scene.add(leaseSign);
    }
  }

  // perimeter walls
  const WT = 1.2, WH = 3.55;
  addBox(0, -ARENA_HALF, ARENA_HALF*2+WT, WH, WT, wallMat, 'wall');
  addBox(0,  ARENA_HALF, ARENA_HALF*2+WT, WH, WT, wallMat, 'wall');
  addBox(-ARENA_HALF, 0, WT, WH, ARENA_HALF*2+WT, wallMat, 'wall');
  addBox( ARENA_HALF, 0, WT, WH, ARENA_HALF*2+WT, wallMat, 'wall');

  // upstairs perimeter railing (top of the main ceiling doubles as the 2nd-floor walkway;
  // this railing keeps you from wandering off the edge while up there)
  const railingMat = new THREE.MeshStandardMaterial({color:0x2c333a, roughness:0.6});
  addBox(0, -ARENA_HALF, ARENA_HALF*2+WT, 1.1, WT, railingMat, 'wall', FLOOR2_Y);
  addBox(0,  ARENA_HALF, ARENA_HALF*2+WT, 1.1, WT, railingMat, 'wall', FLOOR2_Y);
  addBox(-ARENA_HALF, 0, WT, 1.1, ARENA_HALF*2+WT, railingMat, 'wall', FLOOR2_Y);
  addBox( ARENA_HALF, 0, WT, 1.1, ARENA_HALF*2+WT, railingMat, 'wall', FLOOR2_Y);

  // four corridor arms radiating from the atrium
  const storeNames = ['MERVYN\'S','WALDENBOOKS','KB TOYS','GADZOOKS','RADIOSHACK','SAM GOODY','SHARPER IMAGE','PAYLESS SHOES','LORD & TAYLOR','CIRCUIT CITY','BORDERS','STRUCTURE','CHESS KING','MUSICLAND','SUNCOAST','FILENES BASEMENT','BLOCKBUSTER','TOYS R US','LINENS N THINGS','GOODY\'S FAMILY CLOTHING','BOMBAY COMPANY','NATURAL WONDERS','CONTEMPO CASUALS','EGGHEAD SOFTWARE','SOFTWARE ETC','MERRY-GO-ROUND','COUNTY SEAT','MONTGOMERY WARD','WOOLWORTH',"STEVE & BARRY'S",'MEDIA PLAY','B. DALTON','FASHION BUG','DRESS BARN','THE LIMITED','FOREVER 21',"BENNIGAN'S",'TGI FRIDAYS',"CHI-CHI'S",'DISCOVERY ZONE'];
  let storeNameIdx = 0;
  function nextStoreName(){ return storeNames[(storeNameIdx++) % storeNames.length]; }

  const corridorDirs = [{axis:'x',sign:1},{axis:'x',sign:-1},{axis:'z',sign:1},{axis:'z',sign:-1}];
  corridorDirs.forEach(dir => {
    const length = CORR_END - ATRIUM_R;
    const steps = Math.floor(length/7);
    for(let i=0;i<steps;i++){
      const dist = ATRIUM_R + i*7 + 5;
      let cx=0, cz=0;
      if(dir.axis==='x') cx = dir.sign*dist; else cz = dir.sign*dist;
      [1,-1].forEach(side => {
        if(dir.axis==='x'){
          const shopZ = side*(CORR_HALF_W+2.5);
          addStoreShell(cx, shopZ, 6,5,3.4, side>0?'z-':'z+', nextStoreName());
        } else {
          const shopX = side*(CORR_HALF_W+2.5);
          addStoreShell(shopX, cz, 5,6,3.4, side>0?'x-':'x+', nextStoreName());
        }
      });
      if(i%2===1){
        if(dir.axis==='x') addBox(cx, 0, 1.0,3.6,1.0, coverMat, 'obstacle');
        else addBox(0, cz, 1.0,3.6,1.0, coverMat, 'obstacle');
      }
    }
  });

  buildArcadeRoom(FLOOR2_Y);
  buildPizzaPlace(FLOOR2_Y);
  buildFurnitureStore(FLOOR2_Y);
  buildKmart(FLOOR2_Y);
  buildMovieTheater(FLOOR2_Y);
  buildKartMuseum(FLOOR2_Y);
  buildFortuneTeller(FLOOR2_Y);
  buildCompUSA(FLOOR2_Y);
  buildDiveBar(FLOOR2_Y);
  (function buildGrenadeStand(){
    const x = 16, z = 22;
    const roomGroup = new THREE.Group();
    roomGroup.position.set(0, FLOOR2_Y, 0);
    scene.add(roomGroup);
    const counter = new THREE.Mesh(new THREE.BoxGeometry(2.2,0.9,0.8), new THREE.MeshStandardMaterial({color:0x3a2a1a, roughness:0.7}));
    counter.position.set(x,0.45,z);
    roomGroup.add(counter);
    const signTex = makeNeonTexture('INTEGRITY 4 ORDNANCE', '#ff5a3d');
    const sign = new THREE.Mesh(new THREE.PlaneGeometry(2.8,0.55), new THREE.MeshBasicMaterial({map:signTex, transparent:true, side:THREE.DoubleSide}));
    sign.position.set(x,2.0,z);
    roomGroup.add(sign);
    for(let i=0;i<3;i++){
      const nadeBody = new THREE.Mesh(new THREE.SphereGeometry(0.1,10,10), new THREE.MeshStandardMaterial({color:0x2a3a1a, roughness:0.5}));
      nadeBody.position.set(x-0.6+i*0.6, 0.98, z);
      roomGroup.add(nadeBody);
      const pin = new THREE.Mesh(new THREE.TorusGeometry(0.04,0.01,4,8), new THREE.MeshStandardMaterial({color:0xcccccc}));
      pin.position.set(x-0.6+i*0.6, 1.05, z);
      roomGroup.add(pin);
    }
    const standLight = new THREE.PointLight(0xff5a3d, 0.8, 7);
    standLight.position.set(x,1.6,z);
    roomGroup.add(standLight);
    const promptTex = makeSignTexture('PRESS E TO TRADE');
    const prompt = new THREE.Mesh(new THREE.PlaneGeometry(1.4,0.35), new THREE.MeshBasicMaterial({map:promptTex, transparent:true, side:THREE.DoubleSide}));
    prompt.position.set(x,1.3,z-0.55);
    roomGroup.add(prompt);
    grenadeStandPos = {x, z};
  })();
  buildSears(FLOOR2_Y);

  // a third creepy figure lurking out on the open upstairs mezzanine, away from any light
  (function(){
    const f = buildCreepyFigure(0, 40, Math.PI);
    f.group.position.y = FLOOR2_Y;
    scene.add(f.group);
    registerCreepyFigure(f);
  })();
  buildDirectorySign(5, -6);
  addVendingMachine(6.8, -9, 0, 0xb02020);
  addVendingMachine(-6.8, 9, Math.PI, 0x2050a0);
  addPoster(0, 2.0, -54.35, 0, 'NEON DRIFT', '#1a1a3a', '#ff2f8a');
  addPoster(0, 2.0, 54.35, Math.PI, 'STARBLAZERS', '#0a2a3a', '#2fe0ff');
  addPoster(54.35, 2.0, 0, -Math.PI/2, 'STATIC HEARTS', '#2a0a2a', '#ffae2f');
  addPoster(-54.35, 2.0, 0, Math.PI/2, 'MIDNIGHT ARCADE', '#0a0a1a', '#8bff2f');
  addGraffiti(12, 1.6, -54.3, 0, 3, 1.2);
  addGraffiti(-30, 1.6, 54.3, Math.PI, 3, 1.2);

  // atrium: dry fountain
  const fountainRim = new THREE.Mesh(new THREE.TorusGeometry(4,0.4,8,24), new THREE.MeshStandardMaterial({color:0x3f4a3f, roughness:0.85}));
  fountainRim.rotation.x = Math.PI/2; fountainRim.position.y = 0.4; scene.add(fountainRim);
  const basin = new THREE.Mesh(new THREE.CircleGeometry(3.6,24), new THREE.MeshStandardMaterial({color:0x142420, roughness:0.6}));
  basin.rotation.x = -Math.PI/2; basin.position.y = 0.05; scene.add(basin);
  addBox(0,0,1.2,1.8,1.2, new THREE.MeshStandardMaterial({color:0x4a463a}), 'obstacle');

  // dead potted plants (decorative)
  function addDeadPlant(x,z){
    const trunk = new THREE.Mesh(new THREE.CylinderGeometry(0.12,0.16,1.0,6), new THREE.MeshStandardMaterial({color:0x4a3a28}));
    trunk.position.set(x,0.5,z); scene.add(trunk);
    const foliage = new THREE.Mesh(new THREE.SphereGeometry(0.55,6,6), new THREE.MeshStandardMaterial({color:0x5a5a3a, roughness:1}));
    foliage.position.set(x,1.15,z); foliage.scale.set(1,0.8,1); scene.add(foliage);
  }
  [[9,9],[-9,9],[9,-9],[-9,-9],[0,10.5],[0,-10.5]].forEach(([x,z]) => addDeadPlant(x,z));

  // benches (decorative)
  function addBench(x,z,rotY){
    const seat = new THREE.Mesh(new THREE.BoxGeometry(2.0,0.45,0.6), new THREE.MeshStandardMaterial({color:0x2f2f2f}));
    seat.position.set(x,0.45,z); seat.rotation.y = rotY; scene.add(seat);
  }
  addBench(6,-9,0); addBench(-6,9,0); addBench(9,6,Math.PI/2); addBench(-9,-6,Math.PI/2);

  // vending machines scattered around the atrium, dispensing food or pop on demand
  const vendingMachines = [];
  let lastVendingSoundAt = 0;
  function playVendingSound(){
    ensureAudio(); if(!audioCtx) return;
    playNoiseBurst(0.1, 1200, 0.16);
    setTimeout(() => playTone(300, 0.15, 'square', 0.13), 150);
    setTimeout(() => playNoiseBurst(0.08, 2000, 0.11), 320);
  }
  function makeVendingPanelTexture(){
    const c = document.createElement('canvas'); c.width = 96; c.height = 160;
    const ctx = c.getContext('2d');
    ctx.fillStyle = '#1a2a1a'; ctx.fillRect(0,0,96,160);
    const items = [
      ['#e8b830','#3a2a10'], ['#d83a3a','#f0f0f0'], ['#3a7ad8','#f0f0f0'],
      ['#e8862a','#5a2a10'], ['#4ac04a','#0a3a0a'], ['#c04a9a','#3a0a2a']
    ];
    for(let row=0;row<3;row++){
      for(let col=0;col<2;col++){
        const [c1,c2] = items[(row*2+col)%items.length];
        const x = 6+col*46, y = 6+row*50;
        ctx.fillStyle = c1; ctx.fillRect(x,y,40,44);
        ctx.fillStyle = c2; ctx.fillRect(x+6,y+8,28,10);
        ctx.fillRect(x+6,y+24,20,6);
      }
    }
    { const __t = new THREE.CanvasTexture(c); __t.userData.glow = 1.5; return __t; }
  }
  const vendingPanelTex = makeVendingPanelTexture();
  function buildVendingMachine(x,z,rotY,floor){
    const group = new THREE.Group();
    const bodyColor = Math.random() < 0.5 ? 0xc02020 : 0x2050a0;
    const body = new THREE.Mesh(new THREE.BoxGeometry(0.9,2.0,0.7), new THREE.MeshStandardMaterial({color:bodyColor, roughness:0.4, metalness:0.3}));
    body.position.y = 1.0; group.add(body);
    const glassFrame = new THREE.Mesh(new THREE.BoxGeometry(0.66,1.14,0.06), new THREE.MeshStandardMaterial({color:0x0a0a0a}));
    glassFrame.position.set(0,1.3,0.36); group.add(glassFrame);
    const panel = new THREE.Mesh(new THREE.PlaneGeometry(0.58,1.05), new THREE.MeshBasicMaterial({map:vendingPanelTex}));
    panel.position.set(0,1.3,0.4); group.add(panel);
    const coinSlot = new THREE.Mesh(new THREE.BoxGeometry(0.15,0.08,0.02), new THREE.MeshStandardMaterial({color:0x1a1a1a, metalness:0.6}));
    coinSlot.position.set(0,0.85,0.36); group.add(coinSlot);
    const dispenseSlot = new THREE.Mesh(new THREE.BoxGeometry(0.5,0.15,0.1), new THREE.MeshStandardMaterial({color:0x0a0a0a}));
    dispenseSlot.position.set(0,0.32,0.35); group.add(dispenseSlot);
    const vLight = new THREE.PointLight(bodyColor, 0.4, 3.5);
    vLight.position.set(0,1.6,0.4); group.add(vLight);
    const promptTex = makeSignTexture('PRESS E');
    const prompt = new THREE.Mesh(new THREE.PlaneGeometry(0.7,0.2), new THREE.MeshBasicMaterial({map:promptTex, transparent:true, side:THREE.DoubleSide}));
    prompt.position.set(0,2.15,0);
    group.add(prompt);
    group.position.set(x,(floor||0)*FLOOR2_Y,z);
    group.rotation.y = rotY;
    scene.add(group);
    vendingMachines.push({x, z, floor:floor||0, lastUseAt:0});
  }
  [[10,-11,0.4],[-10,11,3.5],[-11,-9,1.9],[8,13,-1.1]].forEach(([x,z,rotY]) => buildVendingMachine(x,z,rotY,0));
  function tryUseVendingMachine(){
    if(!localAlive) return;
    for(const vm of vendingMachines){
      if(currentFloor !== vm.floor) continue;
      const dx = camera.position.x-vm.x, dz = camera.position.z-vm.z;
      if(dx*dx+dz*dz > 2.3*2.3) continue;
      const now = performance.now();
      if(now - vm.lastUseAt < 4000) return;
      vm.lastUseAt = now;
      playVendingSound();
      if(Math.random() < 0.5){
        localHealth = Math.min(100, localHealth+12);
        updateHealthUI();
        addFeed(myName + ' grabs a snack from the vending machine — +12 health', false);
      } else {
        speedBoostUntil = performance.now()+8000;
        addFeed(myName + ' cracks open a cold one from the vending machine', false);
      }
      return;
    }
  }

  // four seasonal corner displays, ground floor, one per diagonal
  function makeCarvedFaceTexture(eyeColor){
    const c = document.createElement('canvas'); c.width = 128; c.height = 128;
    const ctx = c.getContext('2d');
    ctx.clearRect(0,0,128,128);
    ctx.fillStyle = eyeColor;
    ctx.beginPath(); ctx.moveTo(30,50); ctx.lineTo(45,40); ctx.lineTo(50,55); ctx.closePath(); ctx.fill();
    ctx.beginPath(); ctx.moveTo(98,50); ctx.lineTo(83,40); ctx.lineTo(78,55); ctx.closePath(); ctx.fill();
    ctx.beginPath();
    ctx.moveTo(35,85); ctx.lineTo(45,75); ctx.lineTo(53,85); ctx.lineTo(63,75); ctx.lineTo(71,85); ctx.lineTo(81,75); ctx.lineTo(93,85);
    ctx.lineTo(93,95); ctx.lineTo(35,95); ctx.closePath(); ctx.fill();
    return new THREE.CanvasTexture(c);
  }
  function makeTombstoneTexture(text){
    const c = document.createElement('canvas'); c.width = 128; c.height = 160;
    const ctx = c.getContext('2d');
    ctx.fillStyle = '#8a877c'; ctx.fillRect(0,0,128,160);
    ctx.fillStyle = 'rgba(0,0,0,0.25)'; ctx.font = 'italic 16px serif'; ctx.textAlign = 'center';
    ctx.fillText(text, 64, 60);
    ctx.fillText('R.I.P.', 64, 90);
    return new THREE.CanvasTexture(c);
  }
  function makeWebTexture(){
    const c = document.createElement('canvas'); c.width = 200; c.height = 200;
    const ctx = c.getContext('2d');
    ctx.strokeStyle = 'rgba(220,220,220,0.55)'; ctx.lineWidth = 1.5;
    for(let i=0;i<8;i++){
      const ang = (i/8)*Math.PI*2;
      ctx.beginPath(); ctx.moveTo(0,0); ctx.lineTo(Math.cos(ang)*200, Math.sin(ang)*200); ctx.stroke();
    }
    for(let r=25;r<180;r+=25){
      ctx.beginPath();
      for(let i=0;i<=8;i++){ const ang=(i/8)*Math.PI*2; const px=Math.cos(ang)*r, pz=Math.sin(ang)*r; if(i===0) ctx.moveTo(px,pz); else ctx.lineTo(px,pz); }
      ctx.stroke();
    }
    return new THREE.CanvasTexture(c);
  }

  function buildChristmasCorner(cx,cz){
    const trunk = new THREE.Mesh(new THREE.CylinderGeometry(0.22,0.28,0.8,8), new THREE.MeshStandardMaterial({color:0x4a2f1a, roughness:0.8}));
    trunk.position.set(cx,0.4,cz); scene.add(trunk);
    const greenMat = new THREE.MeshStandardMaterial({color:0x1f5c2a, roughness:0.75});
    const tiers = [[1.6,1.6],[1.3,2.4],[1.0,3.15],[0.65,3.8]];
    tiers.forEach(([r,y]) => {
      const tier = new THREE.Mesh(new THREE.ConeGeometry(r,1.1,10), greenMat);
      tier.position.set(cx,y,cz); scene.add(tier);
    });
    const star = new THREE.Mesh(new THREE.OctahedronGeometry(0.2,0), new THREE.MeshStandardMaterial({color:0xffd83d, emissive:0xffd83d, emissiveIntensity:0.6}));
    star.position.set(cx,4.5,cz); scene.add(star);
    const ornColors = [0xd8262f, 0xffd83d, 0x3d7fd8, 0xf0f0f0];
    for(let i=0;i<14;i++){
      const ang = Math.random()*Math.PI*2;
      const tier = tiers[Math.floor(Math.random()*tiers.length)];
      const r = tier[0]*0.75;
      const orn = new THREE.Mesh(new THREE.SphereGeometry(0.09,8,8), new THREE.MeshStandardMaterial({color:ornColors[i%4], emissive:ornColors[i%4], emissiveIntensity:0.25}));
      orn.position.set(cx+Math.cos(ang)*r, tier[1]-0.2+Math.random()*0.4, cz+Math.sin(ang)*r);
      scene.add(orn);
    }
    for(let i=0;i<4;i++){
      const px = cx+(i-1.5)*0.55;
      const giftColors = [0xc0202f,0x1f6b3a,0xd8b020,0x2f4fb0];
      const gift = new THREE.Mesh(new THREE.BoxGeometry(0.5,0.5,0.5), new THREE.MeshStandardMaterial({color:giftColors[i]}));
      gift.position.set(px,0.25,cz+2.0); scene.add(gift);
      const ribbon = new THREE.Mesh(new THREE.BoxGeometry(0.53,0.08,0.53), new THREE.MeshStandardMaterial({color:0xffd83d}));
      ribbon.position.set(px,0.25,cz+2.0); scene.add(ribbon);
    }
    const treeLight = new THREE.PointLight(0xffd8a0, 0.9, 9);
    treeLight.position.set(cx,3,cz); scene.add(treeLight);
    const signTex = makeNeonTexture('HAPPY HOLIDAYS', '#2fd65a');
    const sign = new THREE.Mesh(new THREE.PlaneGeometry(3.2,0.6), new THREE.MeshBasicMaterial({map:signTex, transparent:true, side:THREE.DoubleSide}));
    sign.position.set(cx, 5.2, cz-2.3);
    scene.add(sign);
  }
  function buildValentinesCorner(cx,cz){
    function buildHeart(x,y,z,scale,color){
      const g = new THREE.Group();
      const mat = new THREE.MeshStandardMaterial({color, roughness:0.4, emissive:color, emissiveIntensity:0.15});
      const lobeL = new THREE.Mesh(new THREE.SphereGeometry(0.35,12,12), mat); lobeL.position.set(-0.2,0.2,0); g.add(lobeL);
      const lobeR = new THREE.Mesh(new THREE.SphereGeometry(0.35,12,12), mat); lobeR.position.set(0.2,0.2,0); g.add(lobeR);
      const point = new THREE.Mesh(new THREE.ConeGeometry(0.42,0.75,12), mat); point.position.set(0,-0.35,0); point.rotation.x=Math.PI; g.add(point);
      g.position.set(x,y,z); g.scale.set(scale,scale,scale);
      return g;
    }
    scene.add(buildHeart(cx,2.4,cz,2.0,0xd8264a));
    const balloonColors = [0xff6a8a,0xd8264a,0xff9ab0];
    for(let i=0;i<5;i++){
      const bx = cx+(i-2)*0.9, bz = cz+(Math.random()-0.5)*1.2;
      const by = 3.4+Math.random()*0.8;
      const balloon = buildHeart(bx,by,bz,0.55,balloonColors[i%3]);
      scene.add(balloon);
      const stringMat = new THREE.MeshBasicMaterial({color:0x888888});
      const str = new THREE.Mesh(new THREE.CylinderGeometry(0.008,0.008,1.6,4), stringMat);
      str.position.set(bx,by-1.1,bz); scene.add(str);
    }
    const vaseMat = new THREE.MeshStandardMaterial({color:0xe8e0d0, roughness:0.4});
    const vase = new THREE.Mesh(new THREE.CylinderGeometry(0.25,0.18,0.6,12), vaseMat);
    vase.position.set(cx,0.3,cz+2.0); scene.add(vase);
    for(let i=0;i<5;i++){
      const ang=(i/5)*Math.PI*2;
      const stem = new THREE.Mesh(new THREE.CylinderGeometry(0.02,0.02,0.9,5), new THREE.MeshStandardMaterial({color:0x2a6a2a}));
      stem.position.set(cx+Math.cos(ang)*0.1, 1.0, cz+2.0+Math.sin(ang)*0.1); stem.rotation.z=Math.cos(ang)*0.15; stem.rotation.x=Math.sin(ang)*0.15;
      scene.add(stem);
      const rose = new THREE.Mesh(new THREE.SphereGeometry(0.12,8,8), new THREE.MeshStandardMaterial({color:0xc41c3a, roughness:0.5}));
      rose.position.set(cx+Math.cos(ang)*0.18, 1.42, cz+2.0+Math.sin(ang)*0.18); scene.add(rose);
    }
    const loveLight = new THREE.PointLight(0xff89a8, 0.8, 9);
    loveLight.position.set(cx,2.6,cz); scene.add(loveLight);
    const signTex = makeNeonTexture('BE MINE', '#ff4a7a');
    const sign = new THREE.Mesh(new THREE.PlaneGeometry(2.8,0.6), new THREE.MeshBasicMaterial({map:signTex, transparent:true, side:THREE.DoubleSide}));
    sign.position.set(cx, 4.2, cz-2.3);
    scene.add(sign);
  }
  function buildHalloweenCorner(cx,cz){
    function buildPumpkin(x,z,scale){
      const g = new THREE.Group();
      const body = new THREE.Mesh(new THREE.SphereGeometry(0.42,12,10), new THREE.MeshStandardMaterial({color:0xd8621f, roughness:0.7}));
      body.scale.set(1,0.8,1); g.add(body);
      const stem = new THREE.Mesh(new THREE.CylinderGeometry(0.05,0.07,0.22,6), new THREE.MeshStandardMaterial({color:0x3a5a2a}));
      stem.position.y = 0.42; g.add(stem);
      const faceMat = new THREE.MeshBasicMaterial({map: makeCarvedFaceTexture('#ffcf5a'), transparent:true});
      const face = new THREE.Mesh(new THREE.PlaneGeometry(0.7,0.65), faceMat);
      face.position.set(0,0.02,0.38); g.add(face);
      g.position.set(x,0.34*scale,z); g.scale.set(scale,scale,scale);
      return g;
    }
    scene.add(buildPumpkin(cx-1.2,cz+1.5,1.1));
    scene.add(buildPumpkin(cx+0.8,cz+1.8,0.85));
    scene.add(buildPumpkin(cx-0.2,cz+2.3,0.7));
    [[cx-1.6,cz-1.6,'HERE LIES\\nA SALESMAN'],[cx+0.4,cz-1.9,'R.I.P.\\nCLEARANCE']].forEach(([tx,tz,label]) => {
      const stone = new THREE.Mesh(new THREE.BoxGeometry(0.65,0.9,0.15), new THREE.MeshStandardMaterial({map: makeTombstoneTexture(label), roughness:0.9}));
      stone.position.set(tx,0.45,tz); stone.rotation.y = (Math.random()-0.5)*0.3; stone.rotation.z = (Math.random()-0.5)*0.08;
      scene.add(stone);
    });
    const web = new THREE.Mesh(new THREE.PlaneGeometry(2.6,2.6), new THREE.MeshBasicMaterial({map: makeWebTexture(), transparent:true, side:THREE.DoubleSide}));
    web.position.set(cx-2.0,3.2,cz-2.0); web.rotation.y = Math.PI/4; web.rotation.x = -0.2;
    scene.add(web);
    for(let i=0;i<3;i++){
      const bat = new THREE.Mesh(new THREE.ConeGeometry(0.18,0.06,3), new THREE.MeshStandardMaterial({color:0x0a0a0a}));
      bat.rotation.x = Math.PI/2;
      bat.position.set(cx-1+i*0.8, 3.0+Math.sin(i)*0.3, cz+0.5);
      scene.add(bat);
    }
    const spookyLight = new THREE.PointLight(0xff7a2a, 0.7, 9);
    spookyLight.position.set(cx,2.2,cz); scene.add(spookyLight);
    const signTex = makeNeonTexture('HAPPY HAUNTING', '#ff7a2a');
    const sign = new THREE.Mesh(new THREE.PlaneGeometry(3.2,0.6), new THREE.MeshBasicMaterial({map:signTex, transparent:true, side:THREE.DoubleSide}));
    sign.position.set(cx, 4.2, cz-2.3);
    scene.add(sign);
  }
  function buildEasterCorner(cx,cz){
    function buildEgg(x,z,color,accent){
      const g = new THREE.Group();
      const egg = new THREE.Mesh(new THREE.SphereGeometry(0.35,14,14), new THREE.MeshStandardMaterial({color, roughness:0.5}));
      egg.scale.set(1,1.35,1); g.add(egg);
      const band = new THREE.Mesh(new THREE.TorusGeometry(0.28,0.05,8,20), new THREE.MeshStandardMaterial({color:accent, roughness:0.5}));
      band.rotation.x = Math.PI/2; band.position.y = 0.05; g.add(band);
      for(let i=0;i<5;i++){
        const dot = new THREE.Mesh(new THREE.SphereGeometry(0.04,6,6), new THREE.MeshStandardMaterial({color:accent}));
        const ang=(i/5)*Math.PI*2;
        dot.position.set(Math.cos(ang)*0.22, 0.35+Math.sin(ang)*0.1, Math.sin(ang)*0.22*0.4);
        g.add(dot);
      }
      g.position.set(x,0.47,z);
      return g;
    }
    const eggColors = [[0xffd8e8,0xff6a9a],[0xd0f0ff,0x3da8d8],[0xfff2c0,0xe0a82f],[0xd8f5d0,0x4fa860]];
    eggColors.forEach(([c,a],i) => {
      const ang = (i/4)*Math.PI*2;
      scene.add(buildEgg(cx+Math.cos(ang)*1.5, cz+Math.sin(ang)*1.5, c, a));
    });
    const basketMat = new THREE.MeshStandardMaterial({color:0xc9a15a, roughness:0.8});
    const basket = new THREE.Mesh(new THREE.CylinderGeometry(0.5,0.35,0.5,12,1,true), basketMat);
    basket.position.set(cx,0.28,cz); scene.add(basket);
    const handle = new THREE.Mesh(new THREE.TorusGeometry(0.4,0.03,6,16,Math.PI), basketMat);
    handle.position.set(cx,0.75,cz); scene.add(handle);
    function buildBunny(x,z){
      const g = new THREE.Group();
      const mat = new THREE.MeshStandardMaterial({color:0xf5f0e6, roughness:0.7});
      const body = new THREE.Mesh(new THREE.SphereGeometry(0.32,10,10), mat); body.scale.set(1,0.85,1.2); body.position.y=0.32; g.add(body);
      const head = new THREE.Mesh(new THREE.SphereGeometry(0.2,10,10), mat); head.position.set(0,0.62,0.28); g.add(head);
      const earMat = mat;
      const earL = new THREE.Mesh(new THREE.CylinderGeometry(0.05,0.07,0.32,6), earMat); earL.position.set(-0.08,0.95,0.25); earL.rotation.z=-0.15; g.add(earL);
      const earR = new THREE.Mesh(new THREE.CylinderGeometry(0.05,0.07,0.32,6), earMat); earR.position.set(0.08,0.95,0.25); earR.rotation.z=0.15; g.add(earR);
      const tail = new THREE.Mesh(new THREE.SphereGeometry(0.08,8,8), mat); tail.position.set(0,0.35,-0.42); g.add(tail);
      g.position.set(x,0,z);
      return g;
    }
    scene.add(buildBunny(cx+2.4,cz-1.6));
    for(let i=0;i<6;i++){
      const ang = Math.random()*Math.PI*2, r = 2.2+Math.random()*1.4;
      const tuft = new THREE.Mesh(new THREE.ConeGeometry(0.12,0.3,5), new THREE.MeshStandardMaterial({color:0x4fa860, roughness:0.9}));
      tuft.position.set(cx+Math.cos(ang)*r, 0.15, cz+Math.sin(ang)*r);
      scene.add(tuft);
    }
    const easterLight = new THREE.PointLight(0xd8ffe0, 0.7, 9);
    easterLight.position.set(cx,2.4,cz); scene.add(easterLight);
    const signTex = makeNeonTexture('HAPPY EASTER', '#5ad87a');
    const sign = new THREE.Mesh(new THREE.PlaneGeometry(3.0,0.6), new THREE.MeshBasicMaterial({map:signTex, transparent:true, side:THREE.DoubleSide}));
    sign.position.set(cx, 3.6, cz-2.6);
    scene.add(sign);
  }
  buildChristmasCorner(35,35);
  buildValentinesCorner(35,-35);
  buildHalloweenCorner(-35,-35);
  buildEasterCorner(-35,35);

  // functional escalator connecting the ground floor atrium to the upstairs level
  (function(){
    const escLen = ESC_Z1 - ESC_Z0;
    const midZ = (ESC_Z0+ESC_Z1)/2;
    const group = new THREE.Group();
    const stepsMat = new THREE.MeshStandardMaterial({color:0x2a2a2a, metalness:0.6, roughness:0.35});
    const edgeMat = new THREE.MeshStandardMaterial({color:0xffcc33, emissive:0xffcc33, emissiveIntensity:0.35});
    const stepCount = ESC_STEP_COUNT;
    const stepDepth = escLen/stepCount;
    for(let i=0;i<stepCount;i++){
      const phase = i/stepCount;
      // riser (vertical front face) + tread (horizontal top), like a real moving stair
      const riser = new THREE.Mesh(new THREE.BoxGeometry(ESC_HALF_W*2-0.3, 0.22, 0.06), stepsMat);
      const tread = new THREE.Mesh(new THREE.BoxGeometry(ESC_HALF_W*2-0.3, 0.06, stepDepth+0.04), stepsMat);
      group.add(riser); group.add(tread);
      const edge = new THREE.Mesh(new THREE.BoxGeometry(ESC_HALF_W*2-0.32, 0.03, 0.05), edgeMat);
      group.add(edge);
      const s = {riser, tread, edge, phase, stepDepth};
      positionEscalatorStep(s, phase);
      escalatorSteps.push(s);
    }

    function makeStripeTexture(){
      const c = document.createElement('canvas'); c.width = 32; c.height = 32;
      const ctx = c.getContext('2d');
      ctx.fillStyle = '#161616'; ctx.fillRect(0,0,32,32);
      ctx.fillStyle = '#ffcc33';
      ctx.beginPath(); ctx.moveTo(0,32); ctx.lineTo(16,0); ctx.lineTo(32,0); ctx.lineTo(32,8); ctx.lineTo(8,32); ctx.closePath(); ctx.fill();
      ctx.beginPath(); ctx.moveTo(24,32); ctx.lineTo(32,16); ctx.lineTo(32,32); ctx.closePath(); ctx.fill();
      const tex = new THREE.CanvasTexture(c);
      tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
      tex.repeat.set(1.5, 3);
      return tex;
    }

    // moving hazard-stripe skirt panels (the illusion of a running mechanism)
    const stripeTexL = makeStripeTexture();
    const stripeTexR = makeStripeTexture();
    escalatorTextures.push(stripeTexL, stripeTexR);
    const skirtL = new THREE.Mesh(new THREE.PlaneGeometry(escLen+0.4, FLOOR2_Y+0.6), new THREE.MeshBasicMaterial({map:stripeTexL}));
    skirtL.rotation.y = Math.PI/2;
    skirtL.position.set(ESC_X-ESC_HALF_W+0.16, FLOOR2_Y/2+0.15, midZ);
    group.add(skirtL);
    const skirtR = new THREE.Mesh(new THREE.PlaneGeometry(escLen+0.4, FLOOR2_Y+0.6), new THREE.MeshBasicMaterial({map:stripeTexR}));
    skirtR.rotation.y = -Math.PI/2;
    skirtR.position.set(ESC_X+ESC_HALF_W-0.16, FLOOR2_Y/2+0.15, midZ);
    group.add(skirtR);

    // handrails, sloped to match the incline
    const railMat = new THREE.MeshStandardMaterial({color:0x2f2f2f, metalness:0.3, roughness:0.35});
    const railL = new THREE.Mesh(new THREE.BoxGeometry(0.1,0.14,escLen+0.6), railMat);
    railL.rotation.x = -Math.atan2(FLOOR2_Y, escLen);
    railL.position.set(ESC_X-ESC_HALF_W, 1.05+FLOOR2_Y/2, midZ);
    group.add(railL);
    const railR = railL.clone(); railR.position.x = ESC_X+ESC_HALF_W; group.add(railR);
    scene.add(group);

    // glowing floor-number markers at bottom and top
    const markerBottom = new THREE.Mesh(new THREE.PlaneGeometry(1.4,0.4), new THREE.MeshBasicMaterial({color:0x3dd6ff}));
    markerBottom.rotation.x = -Math.PI/2; markerBottom.position.set(ESC_X, 0.03, ESC_Z0-0.8);
    scene.add(markerBottom);
    const markerTop = new THREE.Mesh(new THREE.PlaneGeometry(1.4,0.4), new THREE.MeshBasicMaterial({color:0xff8a3d}));
    markerTop.rotation.x = -Math.PI/2; markerTop.position.set(ESC_X, FLOOR2_Y+0.03, ESC_Z1+0.8);
    scene.add(markerTop);

    // containment railings (always-active collision, regardless of which floor the player is on)
    // kept just short of the arcade doorway (z=12.5) so they don't snag the entrance
    function addAlwaysWall(x,z0,z1,w,h){
      const len = z1-z0, cz = (z0+z1)/2;
      const mesh = new THREE.Mesh(new THREE.BoxGeometry(w,h,len), new THREE.MeshStandardMaterial({color:0x14171a, transparent:true, opacity:0.0}));
      mesh.position.set(x, h/2, cz);
      scene.add(mesh);
      obstacles.push({mesh, x, z:cz, hw:w/2, hd:len/2, floor:-1});
    }
    addAlwaysWall(ESC_X-ESC_HALF_W-0.15, ESC_Z0-0.3, ESC_Z1+0.05, 0.3, 2.5);
    addAlwaysWall(ESC_X+ESC_HALF_W+0.15, ESC_Z0-0.3, ESC_Z1+0.05, 0.3, 2.5);
  })();

  // ceiling fluorescent fixtures, some flickering
  const flickerLights = [];
  function addCeilingLight(x,z,flicker){
    const fixture = new THREE.Mesh(new THREE.BoxGeometry(1.6,0.1,0.5), new THREE.MeshStandardMaterial({color:0xdfe0c0, emissive:0xdfe0c0, emissiveIntensity: flicker?0.4:0.85}));
    fixture.position.set(x,FLOOR2_Y-0.1,z);
    scene.add(fixture);
    const light = new THREE.PointLight(0xdfe0c0, flicker?0.5:0.7, 16);
    light.position.set(x,FLOOR2_Y-0.3,z);
    scene.add(light);
    if(flicker) flickerLights.push({light, fixture, baseIntensity:0.7});
  }
  const lightPositions = [[0,0],[20,0],[-20,0],[0,20],[0,-20],[38,0]];
  lightPositions.forEach(([x,z],i) => addCeilingLight(x,z, i%3===0));
  flickerLights.forEach(fl => {
    (function scheduleFlicker(){
      const delay = 250 + Math.random()*2800;
      setTimeout(() => {
        const dim = Math.random() < 0.5;
        fl.light.intensity = dim ? 0.04 : fl.baseIntensity;
        fl.fixture.material.emissiveIntensity = dim ? 0.04 : 0.85;
        scheduleFlicker();
      }, delay);
    })();
  });

  // now that all map geometry exists, register wall/obstacle meshes as shootable
  obstacles.forEach(o => shootables.push({mesh:o.mesh, kind:o.mesh.userData.type, ref:null}));
  shootables.push({mesh:ceiling, kind:'obstacle', ref:null});

  const spawnPoints = [
    [6,6],[-6,6],[6,-6],[-6,-6],
    [28,3],[28,-3],[-28,3],[-28,-3],
    [3,28],[-3,28],[3,-28],[-3,-28],
    [46,2],[-46,-2],[2,46],[-2,-46],
    [15,9],[15,-9]
  ];
  function randomSpawn(){
    const s = spawnPoints[Math.floor(Math.random()*spawnPoints.length)];
    return new THREE.Vector3(s[0] + (Math.random()*3-1.5), 1.7, s[1] + (Math.random()*3-1.5));
  }

  /* ============================================================
     NAME SPRITES
  ============================================================ */
  function makeNameSprite(text, color){
    const canvas = document.createElement('canvas');
    canvas.width = 256; canvas.height = 64;
    const ctx = canvas.getContext('2d');
    ctx.font = '600 34px JetBrains Mono, monospace';
    ctx.textAlign = 'center';
    ctx.fillStyle = 'rgba(10,13,15,0.55)';
    ctx.fillRect(0,10,256,44);
    ctx.fillStyle = color || '#e8ecef';
    ctx.fillText(text, 128, 42);
    const tex = new THREE.CanvasTexture(canvas);
    // depth-tested now: name tags no longer show through walls and floors
    const mat = new THREE.SpriteMaterial({map:tex, depthTest:true, depthWrite:false, transparent:true, toneMapped:false});
    const sprite = new THREE.Sprite(mat);
    sprite.renderOrder = 10;
    sprite.scale.set(2.4, 0.6, 1);
    return sprite;
  }

  function hashStr(str){
    let h = 0;
    for(let i=0;i<str.length;i++) h = (h*31 + str.charCodeAt(i)) & 0xffffffff;
    return Math.abs(h);
  }

  /* ============================================================
     ALIEN SPECIES
  ============================================================ */
  function addLimbSet(meshes, colorHex, style, totalHeight, radiusBottom, emissiveHex){
    const mkMat = () => new THREE.MeshStandardMaterial({
      color:colorHex, roughness:0.55, transparent:true,
      emissive: emissiveHex||0x000000, emissiveIntensity: emissiveHex?0.35:0
    });
    const legH = totalHeight*0.48;
    const torsoH = totalHeight*0.52;

    if(style === 'tentacle'){
      for(let i=0;i<3;i++){
        const t = new THREE.Mesh(new THREE.CylinderGeometry(0.1,0.16,legH*0.9,6), mkMat());
        const ang = (i/3)*Math.PI*2;
        t.position.set(Math.sin(ang)*0.18, legH*0.45, Math.cos(ang)*0.18);
        t.rotation.x = Math.sin(ang)*0.3; t.rotation.z = Math.cos(ang)*0.3;
        meshes.push(t);
      }
    } else if(style === 'rock'){
      const legA = new THREE.Mesh(new THREE.IcosahedronGeometry(radiusBottom*0.5,0), mkMat());
      legA.position.set(0.16, legH*0.5, 0); meshes.push(legA);
      const legB = new THREE.Mesh(new THREE.IcosahedronGeometry(radiusBottom*0.5,0), mkMat());
      legB.position.set(-0.16, legH*0.5, 0); meshes.push(legB);
    } else {
      const legs = new THREE.Mesh(new THREE.CylinderGeometry(radiusBottom*0.65, radiusBottom*0.78, legH, 8), mkMat());
      legs.position.y = legH/2; meshes.push(legs);
    }

    let torso;
    if(style === 'rock'){
      torso = new THREE.Mesh(new THREE.IcosahedronGeometry(radiusBottom,0), mkMat());
      torso.scale.set(0.9,1.1,0.9);
    } else {
      torso = new THREE.Mesh(new THREE.CylinderGeometry(radiusBottom*0.8, radiusBottom, torsoH, style==='tentacle'?10:8), mkMat());
    }
    torso.position.y = legH + torsoH/2;
    meshes.push(torso);

    const armY = legH + torsoH*0.62;
    const armOffset = radiusBottom + 0.18;
    if(style === 'rock'){
      const armL = new THREE.Mesh(new THREE.IcosahedronGeometry(0.14,0), mkMat()); armL.position.set(armOffset,armY,0.05); meshes.push(armL);
      const armR = new THREE.Mesh(new THREE.IcosahedronGeometry(0.14,0), mkMat()); armR.position.set(-armOffset,armY,0.05); meshes.push(armR);
    } else {
      const armL = new THREE.Mesh(new THREE.CylinderGeometry(0.08,0.095,torsoH*0.85,6), mkMat()); armL.position.set(armOffset,armY,0.05); armL.rotation.z=-0.14; meshes.push(armL);
      const armR = new THREE.Mesh(new THREE.CylinderGeometry(0.08,0.095,torsoH*0.85,6), mkMat()); armR.position.set(-armOffset,armY,0.05); armR.rotation.z=0.14; meshes.push(armR);
    }
    return {topY: legH+torsoH, armY, armOffset};
  }

  function buildReptilian(skin){
    const meshes = [];
    const limb = addLimbSet(meshes, skin, 'default', 1.65, 0.5);
    const headMat = new THREE.MeshStandardMaterial({color:skin, roughness:0.55, transparent:true});
    const eyeMat = new THREE.MeshStandardMaterial({color:0xffe066, emissive:0xffb300, emissiveIntensity:0.7, transparent:true});
    const head = new THREE.Mesh(new THREE.ConeGeometry(0.32,0.55,8), headMat); head.rotation.x=Math.PI; head.position.y=1.95; meshes.push(head);
    const horn = new THREE.Mesh(new THREE.ConeGeometry(0.06,0.4,6), new THREE.MeshStandardMaterial({color:0xd8d0c0, transparent:true})); horn.position.y=2.4; meshes.push(horn);
    const eyeL = new THREE.Mesh(new THREE.SphereGeometry(0.06,6,6), eyeMat); eyeL.position.set(0.13,1.95,0.24); meshes.push(eyeL);
    const eyeR = new THREE.Mesh(new THREE.SphereGeometry(0.06,6,6), eyeMat); eyeR.position.set(-0.13,1.95,0.24); meshes.push(eyeR);
    meshes.armInfo = limb;
    return meshes;
  }
  function buildInsectoid(skin){
    const meshes = [];
    const limb = addLimbSet(meshes, skin, 'default', 1.625, 0.4);
    const headMat = new THREE.MeshStandardMaterial({color:skin, roughness:0.35, metalness:0.2, transparent:true});
    const eyeMat = new THREE.MeshStandardMaterial({color:0xff3b3b, emissive:0xff3b3b, emissiveIntensity:0.6, transparent:true});
    const head = new THREE.Mesh(new THREE.SphereGeometry(0.3,8,8), headMat); head.position.y=1.85; meshes.push(head);
    for(let i=0;i<4;i++){
      const e = new THREE.Mesh(new THREE.SphereGeometry(0.05,5,5), eyeMat);
      const ang = (i/4)*Math.PI*0.8 - 0.4;
      e.position.set(Math.sin(ang)*0.27, 1.9+Math.cos(ang*2)*0.05, Math.cos(ang)*0.2);
      meshes.push(e);
    }
    const antMat = new THREE.MeshStandardMaterial({color:skin, roughness:0.35, metalness:0.2, transparent:true});
    const antL = new THREE.Mesh(new THREE.CylinderGeometry(0.015,0.02,0.5,4), antMat); antL.position.set(0.12,2.25,0.05); antL.rotation.z=0.5; antL.rotation.x=-0.3; meshes.push(antL);
    const antR = new THREE.Mesh(new THREE.CylinderGeometry(0.015,0.02,0.5,4), antMat); antR.position.set(-0.12,2.25,0.05); antR.rotation.z=-0.5; antR.rotation.x=-0.3; meshes.push(antR);
    meshes.armInfo = limb;
    return meshes;
  }
  function buildGrey(skin){
    const meshes = [];
    const limb = addLimbSet(meshes, skin, 'default', 1.525, 0.36);
    const headMat = new THREE.MeshStandardMaterial({color:skin, roughness:0.5, transparent:true});
    const eyeMat = new THREE.MeshStandardMaterial({color:0x0a0a0f, roughness:0.1, transparent:true});
    const head = new THREE.Mesh(new THREE.SphereGeometry(0.4,10,10), headMat); head.scale.set(0.85,1.15,0.95); head.position.y=1.95; meshes.push(head);
    const eyeL = new THREE.Mesh(new THREE.SphereGeometry(0.11,8,8), eyeMat); eyeL.scale.set(1,0.6,0.6); eyeL.position.set(0.16,1.95,0.3); meshes.push(eyeL);
    const eyeR = new THREE.Mesh(new THREE.SphereGeometry(0.11,8,8), eyeMat); eyeR.scale.set(1,0.6,0.6); eyeR.position.set(-0.16,1.95,0.3); meshes.push(eyeR);
    meshes.armInfo = limb;
    return meshes;
  }
  function buildMagma(skin){
    const meshes = [];
    const limb = addLimbSet(meshes, skin, 'rock', 1.6, 0.55, 0xff5722);
    const headMat = new THREE.MeshStandardMaterial({color:skin, roughness:0.9, emissive:0xff5722, emissiveIntensity:0.35, transparent:true});
    const head = new THREE.Mesh(new THREE.IcosahedronGeometry(0.34,0), headMat); head.position.y=2.0; meshes.push(head);
    meshes.armInfo = limb;
    return meshes;
  }
  function buildTentacled(skin){
    const meshes = [];
    const limb = addLimbSet(meshes, skin, 'tentacle', 1.6, 0.46);
    const headMat = new THREE.MeshStandardMaterial({color:skin, roughness:0.3, metalness:0.1, transparent:true});
    const spotMat = new THREE.MeshStandardMaterial({color:0xaffff0, emissive:0x66ffe0, emissiveIntensity:0.8, transparent:true});
    const head = new THREE.Mesh(new THREE.SphereGeometry(0.34,10,10), headMat); head.position.y=1.88; meshes.push(head);
    for(let i=0;i<3;i++){
      const t = new THREE.Mesh(new THREE.CylinderGeometry(0.03,0.05,0.5,5), new THREE.MeshStandardMaterial({color:skin, roughness:0.3, metalness:0.1, transparent:true}));
      t.position.set((i-1)*0.14, 1.55, 0.2);
      t.rotation.x = 0.9 + Math.random()*0.3;
      meshes.push(t);
    }
    for(let i=0;i<3;i++){
      const s = new THREE.Mesh(new THREE.SphereGeometry(0.035,5,5), spotMat);
      s.position.set(Math.sin(i*2)*0.3, 1.1+i*0.25, Math.cos(i*2)*0.3);
      meshes.push(s);
    }
    meshes.armInfo = limb;
    return meshes;
  }
  const SPECIES = [
    {name:'Kreth Reptilian',  skin:0x3f7d3f, blood:0x5fd15f, build:buildReptilian},
    {name:'Xull Insectoid',   skin:0x4a2f6d, blood:0x9b4fd6, build:buildInsectoid},
    {name:'Voidkin Grey',     skin:0x8a97a3, blood:0x6f8f9b, build:buildGrey},
    {name:'Magma-Born',       skin:0x7a3218, blood:0xff8a3d, build:buildMagma},
    {name:'Deep One',         skin:0x1f7a7a, blood:0x2ee6d6, build:buildTentacled}
  ];
  function speciesForId(id){ return SPECIES[hashStr(id) % SPECIES.length]; }
  function buildCreature(speciesIdx){
    const species = SPECIES[speciesIdx % SPECIES.length];
    const meshes = species.build(species.skin);
    const armInfo = meshes.armInfo || {armY:1.1, armOffset:0.5};
    return {meshes, species, armInfo};
  }

  /* ============================================================
     BLOOD + TRACER + MUZZLE FX
  ============================================================ */
  const bloodParticles = [];
  const FX_SPHERE_LO = new THREE.SphereGeometry(1,4,4);
  const FX_SPHERE = new THREE.SphereGeometry(1,8,6);
  const FX_TRACER = new THREE.CylinderGeometry(0.012,0.02,1,5);
  const tracers = [];
  const groundStains = [];

  function spawnBlood(position, color){
    const group = new THREE.Group();
    const bloodMat = new THREE.MeshBasicMaterial({color, transparent:true});
    group.userData.mat = bloodMat;
    const count = 12 + Math.floor(Math.random()*6);
    for(let i=0;i<count;i++){
      const size = 0.045 + Math.random()*0.07;
      const mesh = new THREE.Mesh(FX_SPHERE_LO, bloodMat);
      mesh.scale.setScalar(size);
      mesh.position.copy(position);
      const dir = new THREE.Vector3((Math.random()-0.5)*2, Math.random()*1.2+0.3, (Math.random()-0.5)*2).normalize();
      mesh.userData.vel = dir.multiplyScalar(1.5+Math.random()*4);
      group.add(mesh);
    }
    scene.add(group);
    bloodParticles.push({group, born:performance.now()});

    const stain = new THREE.Mesh(new THREE.CircleGeometry(0.35+Math.random()*0.3, 10), new THREE.MeshBasicMaterial({color, transparent:true, opacity:0.55}));
    stain.rotation.x = -Math.PI/2;
    stain.position.set(position.x, 0.02, position.z);
    scene.add(stain);
    groundStains.push({mesh:stain, born:performance.now()});
  }

  function updateBloodAndTracers(){
    const now = performance.now();
    for(let i=bloodParticles.length-1;i>=0;i--){
      const b = bloodParticles[i];
      const age = now - b.born;
      if(age > 900){ scene.remove(b.group); b.group.userData.mat.dispose(); bloodParticles.splice(i,1); continue; }
      b.group.userData.mat.opacity = 1 - age/900;
      b.group.children.forEach(p => {
        p.userData.vel.y -= 9*0.016;
        p.position.addScaledVector(p.userData.vel, 0.016);
        if(p.position.y < 0.03) p.position.y = 0.03;
      });
    }
    for(let i=groundStains.length-1;i>=0;i--){
      const s = groundStains[i];
      const age = now - s.born;
      if(age > 7000){ scene.remove(s.mesh); s.mesh.geometry.dispose(); s.mesh.material.dispose(); groundStains.splice(i,1); continue; }
      if(age > 4000) s.mesh.material.opacity = 0.55 * (1 - (age-4000)/3000);
    }
    for(let i=tracers.length-1;i>=0;i--){
      const t = tracers[i];
      const age = now - t.born;
      if(age > 90){ scene.remove(t.mesh); t.mesh.material.dispose(); tracers.splice(i,1); continue; }
      t.mesh.material.opacity = 0.9 * (1 - age/90);
    }
    for(let i=activeMuzzleSprites.length-1;i>=0;i--){
      const sp = activeMuzzleSprites[i];
      const age = now - sp.born;
      const s = sp.baseScale + age*0.025;
      sp.sprite.scale.set(s,s,s);
      sp.sprite.material.opacity = Math.max(0, 1 - age*0.0175);
      if(sp.sprite.material.opacity <= 0){ scene.remove(sp.sprite); sp.sprite.material.dispose(); activeMuzzleSprites.splice(i,1); }
    }
    for(let i=activeSmokePuffs.length-1;i>=0;i--){
      const sm = activeSmokePuffs[i];
      const age = now - sm.born;
      if(age > 700){ scene.remove(sm.mesh); sm.mesh.material.dispose(); activeSmokePuffs.splice(i,1); continue; }
      sm.mesh.position.addScaledVector(sm.vel, 0.016);
      sm.mesh.material.opacity = 0.35*(1-age/700);
    }
  }

  function spawnTracer(start, end, color){
    const dir = new THREE.Vector3().subVectors(end, start);
    const len = Math.max(dir.length(), 0.05);
    const mesh = new THREE.Mesh(
      FX_TRACER,
      new THREE.MeshBasicMaterial({color: new THREE.Color(color||0xfff2c0).multiplyScalar(DMA.Q.bloom ? 1.6 : 1), transparent:true, opacity:0.75, depthWrite:false})
    );
    mesh.scale.set(1, len, 1);
    mesh.position.copy(start).addScaledVector(dir, 0.5);
    mesh.quaternion.setFromUnitVectors(new THREE.Vector3(0,1,0), dir.clone().normalize());
    scene.add(mesh);
    tracers.push({mesh, born:performance.now()});
  }

  const flashTexture = (() => {
    const c = document.createElement('canvas'); c.width=64; c.height=64;
    const ctx = c.getContext('2d');
    const grad = ctx.createRadialGradient(32,32,0,32,32,32);
    grad.addColorStop(0,'rgba(255,240,200,1)');
    grad.addColorStop(0.4,'rgba(255,170,60,0.9)');
    grad.addColorStop(1,'rgba(255,120,30,0)');
    ctx.fillStyle = grad; ctx.fillRect(0,0,64,64);
    return new THREE.CanvasTexture(c);
  })();

  const activeMuzzleLights = [];
  const activeMuzzleSprites = [];
  const activeSmokePuffs = [];
  const MAX_MUZZLE_LIGHTS = 6;
  function spawnMuzzleBlast(position, direction, color){
    // hard cap so simultaneous close-range crossfire can never pile up lights and tank performance
    // pooled light (graphics.js) — the scene's light count never changes, so no shader recompiles mid-fight
    DMAGfx.flash(position, color||0xffaa55, 3.2, 8, 70);

    const spriteMat = new THREE.SpriteMaterial({map:flashTexture, transparent:true, opacity:1, depthTest:false, blending:THREE.AdditiveBlending});
    if(color) spriteMat.color.set(color);
    if(DMA.Q.bloom) spriteMat.color.multiplyScalar(2.5);
    const sprite = new THREE.Sprite(spriteMat);
    sprite.position.copy(position).addScaledVector(direction, 0.4);
    sprite.scale.set(0.6,0.6,0.6);
    scene.add(sprite);
    activeMuzzleSprites.push({sprite, born:performance.now(), baseScale:0.6});

    while(activeSmokePuffs.length >= MAX_MUZZLE_LIGHTS*3){
      const old = activeSmokePuffs.shift();
      scene.remove(old.mesh); old.mesh.material.dispose();
    }
    for(let i=0;i<3;i++){
      const smoke = new THREE.Mesh(FX_SPHERE, new THREE.MeshBasicMaterial({color:0x555555, transparent:true, opacity:0.35, depthWrite:false}));
      smoke.scale.setScalar(0.18+Math.random()*0.1);
      smoke.position.copy(position).addScaledVector(direction, 0.3+Math.random()*0.3);
      const vel = direction.clone().multiplyScalar(0.6).add(new THREE.Vector3(0,0.4+Math.random()*0.3,0));
      scene.add(smoke);
      activeSmokePuffs.push({mesh:smoke, vel, born:performance.now()});
    }
  }

  /* ============================================================
     COLLISION
  ============================================================ */
  function collideAndSlide(pos, radius, floor){
    floor = floor || 0;
    for(const o of obstacles){
      const of = (o.floor === undefined) ? 0 : o.floor;
      if(of !== -1 && of !== floor) continue;
      const closestX = Math.max(o.x-o.hw, Math.min(pos.x, o.x+o.hw));
      const closestZ = Math.max(o.z-o.hd, Math.min(pos.z, o.z+o.hd));
      const dx = pos.x - closestX, dz = pos.z - closestZ;
      const distSq = dx*dx + dz*dz;
      if(distSq < radius*radius){
        const dist = Math.sqrt(distSq) || 0.0001;
        const push = (radius - dist);
        pos.x += (dx/dist) * push;
        pos.z += (dz/dist) * push;
      }
    }
    const lim = ARENA_HALF - 1.4;
    pos.x = Math.max(-lim, Math.min(lim, pos.x));
    pos.z = Math.max(-lim, Math.min(lim, pos.z));
  }

  function hasLineOfSight(fromV3, toV3){
    const dir = new THREE.Vector3().subVectors(toV3, fromV3);
    const dist = dir.length();
    dir.normalize();
    const ray = new THREE.Raycaster(fromV3, dir, 0.1, dist - 0.5);
    const hits = ray.intersectObjects(obstacles.map(o=>o.mesh).concat([ceiling]));
    return hits.length === 0;
  }

  /* ============================================================
     GRAPHICS UPGRADE (graphics.js) + end of the deterministic build
  ============================================================ */
  DMAGfx.enhance({ scene, camera, pipeline, ground, ceiling, groundMat, ceilingMat, wallMat, coverMat, railingMat, sun, rim, FLOOR2_Y, ARENA_HALF });
  DMA.unseedRandom();

  /* ============================================================
     LOCAL PLAYER STATE
  ============================================================ */
  let localHealth = 100;
  let localAlive = true;
  let myKills = 0, myDeaths = 0;
  let shieldAmount = 0;
  let speedBoostUntil = 0;
  let invisibleUntil = 0;
  const keys = {};
  let yaw = 0, pitch = 0;
  let currentFloor = 0;
  let nextPizzaHealAt = 0, nextPopSpeedAt = 0;
  let pointerLocked = false;
  let isMouseDown = false;
  let chatOpen = false;
  const seenChatKeys = new Set();
  let lastShotTime = 0;
  const MOVE_SPEED = 6.0;
  let recoilPitch = 0, recoilYaw = 0;

  let currentWeaponId = 'shotgun';
  let shellsLoaded = 2;
  const SHELL_CAPACITY = 2;
  let reloading = false;

  function resetLocalPlayer(){
    const s = randomSpawn();
    camera.position.copy(s);
    currentFloor = 0;
    localHealth = 100;
    localAlive = true;
    shieldAmount = 0;
    speedBoostUntil = 0;
    invisibleUntil = 0;
    sitOffset = 0; sitTargetOffset = 0;
    drunkLevel = 0;
    updateHealthUI();
    updateStatusUI();
  }
  resetLocalPlayer();

  function updateHealthUI(){
    const frac = Math.max(0, localHealth)/100;
    document.getElementById('healthBarFill').style.width = (frac*100)+'%';
    document.getElementById('healthNum').textContent = Math.max(0,Math.round(localHealth));
    document.getElementById('healthBarFill').style.background = frac > 0.35 ? 'linear-gradient(90deg, #37d67a, #7ee89f)' : 'linear-gradient(90deg, #ff3b3b, #ff8a3d)';
  }
  function updateScoreUI(){
    document.getElementById('killCount').textContent = myKills;
    document.getElementById('deathCount').textContent = myDeaths;
  }
  function updateWeaponUI(){
    const weapon = WEAPONS[currentWeaponId];
    document.getElementById('weaponName').textContent = weapon.name;
    const row = document.getElementById('ammoRow');
    row.innerHTML = '';
    if(weapon.kind === 'shotgun'){
      for(let i=0;i<SHELL_CAPACITY;i++){
        const d = document.createElement('div');
        d.className = 'shell' + (i < shellsLoaded ? '' : ' spent');
        row.appendChild(d);
      }
    } else {
      const inf = document.createElement('div');
      inf.className = 'infinity';
      inf.textContent = '∞';
      row.appendChild(inf);
    }
  }
  updateWeaponUI();

  function updateStatusUI(){
    const el = document.getElementById('statusEffects');
    el.innerHTML = '';
    const now = performance.now();
    if(shieldAmount > 0) el.innerHTML += '<div class="statusChip shield">SHIELD ' + Math.round(shieldAmount) + '</div>';
    if(now < speedBoostUntil) el.innerHTML += '<div class="statusChip speed">SPEED ' + ((speedBoostUntil-now)/1000).toFixed(1) + 's</div>';
    if(now < invisibleUntil) el.innerHTML += '<div class="statusChip invis">CLOAKED ' + ((invisibleUntil-now)/1000).toFixed(1) + 's</div>';
    const rtcEl = document.getElementById('rtcStatus');
    if(rtcEl){
      rtcEl.textContent = net.online ? (net.isHost ? 'you run the aliens' : 'aliens run by ' + ((net.players[net.hostId]||{}).name || 'host')) : '';
    }
  }

  function equipWeapon(weaponId){
    if(!WEAPONS[weaponId]) return;
    currentWeaponId = weaponId;
    if(WEAPONS[weaponId].kind === 'shotgun'){
      shellsLoaded = SHELL_CAPACITY;
      reloading = false;
      document.getElementById('reloadMsg').style.opacity = '0';
    }
    updateWeaponUI();
  }

  function damageLocalPlayer(amount, fromName){
    if(!localAlive || inHell || window.__dmaGod) return;
    if(shieldAmount > 0){
      const absorbed = Math.min(shieldAmount, amount);
      shieldAmount -= absorbed;
      amount -= absorbed;
      if(absorbed > 0) flashShield();
      updateStatusUI();
    }
    if(amount > 0){
      localHealth -= amount;
      flashDamage();
      playDamageSound();
    }
    if(localHealth <= 0){
      localHealth = 0;
      localAlive = false;
      myDeaths++;
      updateScoreUI();
      addFeed((fromName||'Unknown') + ' eliminated ' + myName, true);
      net.send('feed', {text:(fromName||'Unknown') + ' eliminated ' + myName, death:true});
      showCenterMsg(true);
      setTimeout(() => { resetLocalPlayer(); showCenterMsg(false); }, 3000);
    }
    updateHealthUI();
  }

  function flashDamage(){
    const el = document.getElementById('dmgFlash');
    el.style.opacity = '1';
    setTimeout(()=>{ el.style.opacity='0'; }, 180);
  }
  function flashShield(){
    const el = document.getElementById('shieldFlash');
    el.style.opacity = '1';
    setTimeout(()=>{ el.style.opacity='0'; }, 180);
  }
  function showCenterMsg(show){ document.getElementById('centerMsg').style.opacity = show ? '1' : '0'; }
  function flashHitmarker(){
    const el = document.getElementById('hitmarker');
    el.style.opacity = '1';
    setTimeout(()=>{ el.style.opacity='0'; }, 120);
    playHitmarkerSound();
  }
  function addFeed(text, isDeath){
    const feed = document.getElementById('killfeed');
    const div = document.createElement('div');
    div.className = 'feedItem' + (isDeath ? ' death' : '');
    div.textContent = text;
    feed.prepend(div);
    while(feed.children.length > 6) feed.removeChild(feed.lastChild);
    setTimeout(()=>{ if(div.parentNode) div.parentNode.removeChild(div); }, 6000);
  }

  function addChatMessage(name, text){
    const log = document.getElementById('chatLog');
    const div = document.createElement('div');
    div.className = 'chatMsg';
    const nameSpan = document.createElement('b');
    nameSpan.textContent = name + ': ';
    div.appendChild(nameSpan);
    div.appendChild(document.createTextNode(text));
    log.appendChild(div);
    while(log.children.length > 8) log.removeChild(log.firstChild);
    setTimeout(()=>{ if(div.parentNode) div.parentNode.removeChild(div); }, 15000);
  }
  function openChat(){
    chatOpen = true;
    keys['KeyW']=keys['KeyA']=keys['KeyS']=keys['KeyD']=false;
    isMouseDown = false;
    document.exitPointerLock();
    const wrap = document.getElementById('chatInputWrap');
    const input = document.getElementById('chatInput');
    wrap.classList.add('open');
    input.value = '';
    input.focus();
  }
  function closeChat(){
    chatOpen = false;
    document.getElementById('chatInputWrap').classList.remove('open');
    document.getElementById('chatInput').blur();
    canvasEl.requestPointerLock();
  }
  function sendChatMessage(){
    const input = document.getElementById('chatInput');
    const text = input.value.trim().slice(0,140);
    if(text.length){
      addChatMessage(myName, text);
      net.send('chat', {name:myName, text});
    }
    closeChat();
  }
  net.on('chat', d => { if(d && d.text) addChatMessage(String(d.name||'Operator').slice(0,16), String(d.text).slice(0,140)); });

  /* ============================================================
     BOTS
  ============================================================ */
  const BOT_COUNT = 6;
  const botNames = ['VIPER','GHOST','RAVEN','TALON','WOLF','ECHO','FANG','CINDER'];

  function createBot(idx){
    const group = new THREE.Group();
    const {meshes, species, armInfo} = buildCreature(idx);
    meshes.forEach(m => group.add(m));
    const nameTag = makeNameSprite(botNames[idx % botNames.length] + ' // ' + species.name.split(' ')[0], '#ff8a3d');
    nameTag.position.y = 2.7;
    group.add(nameTag);
    const hpBar = new THREE.Mesh(new THREE.PlaneGeometry(1,0.12), new THREE.MeshBasicMaterial({color:0x37d67a}));
    hpBar.position.y = 2.45;
    group.add(hpBar);

    const weaponId = randomWeaponId();
    const gunMesh = gunMeshFor(weaponId, armInfo);
    group.add(gunMesh);

    const spawn = randomSpawn();
    group.position.set(spawn.x, 0, spawn.z);
    scene.add(group);

    const patrol = [];
    for(let i=0;i<3;i++){ const s = randomSpawn(); patrol.push(new THREE.Vector3(s.x,0,s.z)); }

    const bot = {
      id:'bot_'+idx, name:botNames[idx%botNames.length], group, hpBar, species, gunMesh, weaponId, armInfo,
      health:100, maxHealth:100, alive:true, floor:0,
      patrol, patrolIdx:0, state:'patrol',
      lastShot:0, fireInterval: (BOT_FIRE_INTERVAL[weaponId]||1000) + Math.random()*300,
      speed: 2.6 + Math.random()*0.8,
      respawnAt:0,
      shared:true, idx   // the roaming alien squad is shared: the host's browser runs it for everyone
    };
    meshes.forEach(m => shootables.push({mesh:m, kind:'bot', ref:bot}));
    shootables.push({mesh:gunMesh, kind:'bot', ref:bot});
    bots.push(bot);
  }
  for(let i=0;i<BOT_COUNT;i++) createBot(i);

  function respawnBotWeapon(bot, forcedWeapon){
    const idx = shootables.findIndex(s => s.mesh === bot.gunMesh);
    if(idx >= 0) shootables.splice(idx,1);
    bot.group.remove(bot.gunMesh);
    bot.weaponId = forcedWeapon || randomWeaponId();
    bot.gunMesh = gunMeshFor(bot.weaponId, bot.armInfo);
    bot.group.add(bot.gunMesh);
    shootables.push({mesh:bot.gunMesh, kind:'bot', ref:bot});
    bot.fireInterval = (BOT_FIRE_INTERVAL[bot.weaponId]||1000) + Math.random()*300;
  }

  // who can this bot see right now? (host: every player; non-shared bots: just you)
  function botCandidates(bot){
    const bf = bot.floor||0, out = [];
    const now = performance.now();
    if(deployed && localAlive && !inHell && now >= invisibleUntil && currentFloor === bf) out.push({id:null, pos:camera.position});
    if(bot.shared){
      for(const id in remotePlayers){
        const e = remotePlayers[id];
        if(!e.group.visible || e.health <= 0 || e.invisible || e.inHell || (e.floor||0) !== bf) continue;
        out.push({id, pos:new THREE.Vector3(e.group.position.x, e.group.position.y+1.7, e.group.position.z)});
      }
    }
    return out;
  }
  function pickBotTarget(bot, now){
    if(now < (bot.nextTargetCheck||0) && bot.cachedTarget !== undefined){
      // refresh the chosen target's live position between line-of-sight checks
      const t = bot.cachedTarget;
      if(!t) return null;
      if(t.id === null) return (deployed && localAlive && !inHell && now >= invisibleUntil) ? {id:null, pos:camera.position} : null;
      const e = remotePlayers[t.id];
      if(!e || !e.group.visible || e.health <= 0 || e.invisible) return null;
      return {id:t.id, pos:new THREE.Vector3(e.group.position.x, e.group.position.y+1.7, e.group.position.z)};
    }
    bot.nextTargetCheck = now + 220 + Math.random()*120;
    const bp = bot.group.position;
    const eye = new THREE.Vector3(bp.x, 1.5+(bot.floor||0)*FLOOR2_Y, bp.z);
    let best = null, bestD = 30;
    for(const c of botCandidates(bot)){
      const d = Math.hypot(c.pos.x-bp.x, c.pos.z-bp.z);
      if(d < bestD && hasLineOfSight(eye, c.pos)){ best = c; bestD = d; }
    }
    bot.cachedTarget = best ? {id:best.id} : null;
    return best;
  }
  function updatePuppetBot(bot, dt){
    // non-host view of a shared alien: glide toward the host's latest reported state
    const n = bot.netTarget;
    if(!n) return;
    bot.group.position.x += (n.x - bot.group.position.x) * Math.min(1, dt*10);
    bot.group.position.z += (n.z - bot.group.position.z) * Math.min(1, dt*10);
    bot.group.position.y = n.y;
    let dYaw = bot.netYaw - bot.group.rotation.y;
    while(dYaw > Math.PI) dYaw -= Math.PI*2;
    while(dYaw < -Math.PI) dYaw += Math.PI*2;
    bot.group.rotation.y += dYaw * Math.min(1, dt*10);
    const hpFrac = Math.max(0, bot.health/bot.maxHealth);
    bot.hpBar.scale.x = hpFrac;
    bot.hpBar.material.color.setHex(hpFrac > 0.4 ? 0x37d67a : 0xff3b3b);
  }
  function updateBot(bot, dt, now){
    if(bot.shared && net.online && !net.isHost){ updatePuppetBot(bot, dt); return; }
    if(!bot.alive){
      if(bot.noRespawn) return;
      if(now > bot.respawnAt){
        bot.alive = true;
        bot.health = bot.maxHealth;
        if(bot.techTaunt){
          bot.group.position.set(bot.homeX, (bot.floor||0)*FLOOR2_Y, bot.homeZ);
          bot.asked = false;
          bot.awaitingAnswer = false;
          bot.appeased = false;
        } else {
          const s = randomSpawn();
          bot.group.position.set(s.x, (bot.floor||0)*FLOOR2_Y, s.z);
        }
        bot.group.visible = true;
        bot.state = 'patrol';
        if(!bot.techTaunt) respawnBotWeapon(bot);
      }
      return;
    }
    const botPos3 = bot.group.position;
    const target = pickBotTarget(bot, now);
    const playerPos = target ? target.pos : camera.position;
    const distToPlayer = botPos3.distanceTo(new THREE.Vector3(playerPos.x,botPos3.y,playerPos.z));
    const canSeePlayer = !!target;

    if(canSeePlayer && (!bot.techTaunt || (bot.asked && !bot.awaitingAnswer && !bot.appeased))) bot.state = 'attack';
    else if(bot.state === 'attack') bot.state = 'patrol';

    // ambient taunting — he's loud enough to hear ranting through the store even if you can't see him yet
    if(bot.techTaunt && !bot.appeased && deployed && localAlive && currentFloor === (bot.floor||0) && camera.position.distanceTo(new THREE.Vector3(botPos3.x, camera.position.y, botPos3.z)) < 26){
      if(now - (bot.lastAmbientTauntAt||0) > 6000 + Math.random()*4000){
        bot.lastAmbientTauntAt = now;
        const idx = Math.floor(Math.random()*techTaunts.length);
        addFeed(techTaunts[idx], true);
        if(bot.speechBubble) bot.speechBubble.say(plainTechTaunts[idx], 3200);
      }
    }

    if(bot.state === 'attack'){
      const targetAngle = Math.atan2(playerPos.x-botPos3.x, playerPos.z-botPos3.z);
      bot.group.rotation.y = targetAngle;

      let shouldFireNow;
      if(bot.burstFire){
        if(now > bot.burstStateUntil){
          if(bot.burstState === 'windup'){ bot.burstState = 'firing'; bot.burstStateUntil = now+3000; }
          else if(bot.burstState === 'firing'){ bot.burstState = 'pause'; bot.burstStateUntil = now+1600; }
          else if(bot.burstState === 'pause'){
            bot.burstState = 'firing'; bot.burstStateUntil = now+3000;
            if(now - bot.lastYellAt > 4000){ playGangsterYell(); bot.lastYellAt = now; }
          }
        }
        shouldFireNow = bot.burstState === 'firing' && (now - bot.lastShot > bot.fireInterval);
      } else {
        shouldFireNow = now - bot.lastShot > bot.fireInterval;
      }

      if(shouldFireNow){
        bot.lastShot = now;
        bot.group.updateMatrixWorld(true);
        const gunWorldPos = bot.gunMesh.getWorldPosition(new THREE.Vector3());
        const aimPoint = new THREE.Vector3(playerPos.x, playerPos.y - 0.1 + (Math.random()-0.5)*0.5, playerPos.z);
        const toPlayer = aimPoint.clone().sub(gunWorldPos).normalize();
        spawnMuzzleBlast(gunWorldPos, toPlayer, WEAPONS[bot.weaponId].tracerColor);
        spawnTracer(gunWorldPos, aimPoint, WEAPONS[bot.weaponId].tracerColor);
        if(bot.shared) net.send('shot', {x:gunWorldPos.x, y:gunWorldPos.y, z:gunWorldPos.z, dx:toPlayer.x, dy:toPlayer.y, dz:toPlayer.z, ex:aimPoint.x, ey:aimPoint.y, ez:aimPoint.z, color:WEAPONS[bot.weaponId].tracerColor, w:bot.weaponId});
        if(Math.random() < 0.55){
          const amount = (BOT_DAMAGE[bot.weaponId]||12) + Math.random()*4;
          if(!target || target.id === null) damageLocalPlayer(amount, bot.name);
          else net.send('dmg', {targetId:target.id, amount, from:bot.id, fromName:bot.name}, target.id);
        }
        if(bot.techTaunt && Math.random() < 0.3 && now - (bot.lastTauntAt||0) > 4000){
          bot.lastTauntAt = now;
          const idx = Math.floor(Math.random()*techTaunts.length);
          addFeed(techTaunts[idx], true);
          if(bot.speechBubble) bot.speechBubble.say(plainTechTaunts[idx], 3200);
        }
      }

      if(bot.approach){
        if(distToPlayer > 4.5){
          const toward = new THREE.Vector3(playerPos.x - botPos3.x, 0, playerPos.z - botPos3.z).normalize();
          botPos3.x += toward.x * bot.speed*dt;
          botPos3.z += toward.z * bot.speed*dt;
        }
      } else if(distToPlayer < 9){
        const back = new THREE.Vector3(botPos3.x - playerPos.x, 0, botPos3.z - playerPos.z).normalize();
        botPos3.x += back.x * bot.speed*0.6*dt;
        botPos3.z += back.z * bot.speed*0.6*dt;
      }
    } else {
      const target = bot.patrol[bot.patrolIdx];
      const dir = new THREE.Vector3(target.x-botPos3.x, 0, target.z-botPos3.z);
      const dist = dir.length();
      if(dist < 1.2){
        bot.patrolIdx = (bot.patrolIdx+1) % bot.patrol.length;
      } else {
        dir.normalize();
        bot.group.rotation.y = Math.atan2(dir.x, dir.z);
        botPos3.x += dir.x * bot.speed * dt;
        botPos3.z += dir.z * bot.speed * dt;
      }
    }
    collideAndSlide(botPos3, 0.5, bot.floor||0);
    const hpFrac = Math.max(0, bot.health/bot.maxHealth);
    bot.hpBar.scale.x = hpFrac;
    bot.hpBar.material.color.setHex(hpFrac > 0.4 ? 0x37d67a : 0xff3b3b);
  }

  function damageBot(bot, amount, hitPoint, attacker){
    if(!bot.alive) return;
    if(hitPoint) spawnBlood(hitPoint, bot.species.blood);
    if(bot.shared && net.online && !net.isHost && !attacker){
      // someone else runs this alien: tell the host, show the hit right away
      net.send('botdmg', {i:bot.idx, a:amount}, net.hostId);
      bot.health = Math.max(1, bot.health - amount);
      if(bot.cachedTarget === null || bot.cachedTarget === undefined) bot.nextTargetCheck = 0;
      return;
    }
    bot.health -= amount;
    if(attacker && bot.shared){ bot.cachedTarget = {id:attacker.id}; bot.nextTargetCheck = performance.now() + 800; bot.state = 'attack'; }
    if(bot.health <= 0){
      bot.alive = false;
      bot.group.visible = false;
      bot.respawnAt = performance.now() + 4000;
      const takenWeapon = WEAPONS[bot.weaponId].name;
      if(attacker){
        net.send('botkill', {killerId:attacker.id, weapon:bot.weaponId, bot:bot.name}, attacker.id);
        net.send('feed', {text:(attacker.name||'Someone') + ' neutralized ' + bot.name});
        addFeed((attacker.name||'Someone') + ' neutralized ' + bot.name, false);
      } else {
        myKills++;
        updateScoreUI();
        equipWeapon(bot.weaponId);
        addFeed(myName + ' neutralized ' + bot.name + ' — took ' + takenWeapon, false);
        if(bot.shared) net.send('feed', {text: myName + ' neutralized ' + bot.name});
        playKillSound();
      }
      if(bot.shared) broadcastBots();
    }
  }
  // host -> everyone: the shared alien squad
  function broadcastBots(){
    if(!net.online || !net.isHost) return;
    const list = [];
    bots.forEach(b => {
      if(!b.shared) return;
      const p = b.group.position;
      list.push([b.idx, +p.x.toFixed(2), +p.y.toFixed(2), +p.z.toFixed(2), +b.group.rotation.y.toFixed(3), Math.round(b.health), b.alive?1:0, b.weaponId, b.floor||0]);
    });
    net.send('bots', list);
  }
  net.on('bots', list => {
    if(net.isHost || !Array.isArray(list)) return;
    list.forEach(r => {
      const bot = bots.find(b => b.shared && b.idx === r[0]);
      if(!bot) return;
      const wasAlive = bot.alive;
      bot.netTarget = bot.netTarget || new THREE.Vector3();
      bot.netTarget.set(r[1], r[2], r[3]);
      bot.netYaw = r[4];
      bot.health = r[5];
      bot.alive = !!r[6];
      bot.floor = r[8];
      if(!wasAlive && bot.alive) bot.group.position.copy(bot.netTarget); // respawn: snap
      bot.group.visible = bot.alive;
      if(r[7] && WEAPONS[r[7]] && r[7] !== bot.weaponId) respawnBotWeapon(bot, r[7]);
    });
  });
  net.on('botdmg', (d, msg) => {
    if(!net.isHost || !d) return;
    const bot = bots.find(b => b.shared && b.idx === d.i);
    const who = net.players[msg.from] || {};
    if(bot) damageBot(bot, Math.min(200, +d.a || 0), null, {id: msg.from, name: who.name || (remotePlayers[msg.from]||{}).name});
  });
  net.on('botkill', d => {
    if(!d || d.killerId !== myId) return;
    myKills++;
    updateScoreUI();
    let note = '';
    if(d.weapon && WEAPONS[d.weapon]){ equipWeapon(d.weapon); note = ' — took ' + WEAPONS[d.weapon].name; }
    addFeed(myName + ' neutralized ' + (d.bot||'an alien') + note, false);
    playKillSound();
  });

  /* ============================================================
     REMOTE PLAYERS
  ============================================================ */
  const remotePlayers = {};

  /* ============================================================
     LAN MESSAGES (net.js <-> server.py)
     pos    — each player's position/health/weapon, 20x a second
     shot   — muzzle flash + tracer for someone else's gunfire
     dmg    — damage dealt to a specific player (the victim applies it)
     kill   — the victim tells the killer they got the kill (and their gun)
     boom   — grenade / rocket explosion visuals
     bots   — the host's alien squad state; botdmg / botkill / bshot go with it
     pickups, take, granted — host-run power-ups
     feed   — kill-feed line everyone should see
  ============================================================ */
  net.on('pos', d => updateRemotePlayer(d));
  net.on('shot', d => {
    const origin = new THREE.Vector3(d.x,d.y,d.z);
    const dir = new THREE.Vector3(d.dx,d.dy,d.dz);
    spawnMuzzleBlast(origin, dir, d.color);
    spawnTracer(origin, d.ex !== undefined ? new THREE.Vector3(d.ex,d.ey,d.ez) : origin.clone().addScaledVector(dir, 30), d.color);
    playRemoteGunshot(d.w, origin);
  });
  net.on('dmg', d => {
    if(!d || d.targetId !== myId) return;
    const wasAlive = localAlive;
    damageLocalPlayer(d.amount, d.fromName);
    if(wasAlive && !localAlive && d.from && String(d.from).startsWith('p_')) reportDeathTo(d.from);
  });
  net.on('kill', d => {
    if(!d || d.killerId !== myId) return;
    myKills++;
    updateScoreUI();
    let weaponNote = '';
    if(d.weapon && WEAPONS[d.weapon]){ equipWeapon(d.weapon); weaponNote = ' — took ' + WEAPONS[d.weapon].name; }
    addFeed(myName + ' eliminated ' + (d.victim||'an operator') + weaponNote, false);
    playKillSound();
  });
  net.on('feed', d => { if(d && d.text) addFeed(String(d.text).slice(0,120), !!d.death); });
  net.on('boom', d => { if(d) explodeGrenade(new THREE.Vector3(d.x,d.y,d.z), d.f||0, true); });
  net.on('leave', d => {
    const e = d && remotePlayers[d.id];
    if(e){ e.group.visible = false; e.lastSeen = 0; addFeed((e.name||'An operator') + ' left the mall', false); }
  });
  net.on('join', d => { if(d && d.id !== myId) addFeed((d.name||'An operator') + ' joined the mall', false); });
  net.on('hostchange', d => {
    if(net.isHost){
      // we just inherited the alien squad: keep them where everyone last saw them
      bots.forEach(b => { if(b.shared && b.netTarget){ b.group.position.copy(b.netTarget); } });
      if(net.online) addFeed('You are now running the aliens for everyone', false);
    }
  });
  net.on('status', d => {
    updateNetStatusLine();
    if(d && d.online) addFeed('Linked to the LAN server' + (net.isHost ? ' — you are hosting the aliens' : ''), false);
  });

  function broadcastMyState(){
    if(!net.online) return;
    net.send('pos', {
      id:myId, name:myName, x:camera.position.x, y:camera.position.y, z:camera.position.z, yaw:yaw, pitch:pitch,
      health: localAlive ? localHealth : 0, weapon: currentWeaponId, floor: currentFloor,
      invisible: performance.now() < invisibleUntil, hell: inHell, k: myKills, dth: myDeaths
    });
  }
  // remote gunfire gets a quieter, distance-scaled version of the local gunshot
  function playRemoteGunshot(weaponId, origin){
    if(!origin) return;
    const d = origin.distanceTo(camera.position);
    if(d > 45) return;
    ensureAudio(); if(!audioCtx) return;
    const s = GUNSHOT_SPECS[weaponId] || GUNSHOT_SPECS.pistol;
    const g = Math.max(0.05, 1 - d/45) * 0.7;
    playNoiseBurst(s.dur, s.filt*0.8, s.gain*g);
  }

  function createRemotePlayer(id, data){
    const species = speciesForId(id);
    const speciesIdx = SPECIES.indexOf(species);
    const group = new THREE.Group();
    const {meshes, armInfo} = buildCreature(speciesIdx);
    meshes.forEach(m => group.add(m));
    const nameTag = makeNameSprite(data.name || 'Operator', '#3dd6ff');
    nameTag.position.y = 2.7;
    group.add(nameTag);
    const hpBar = new THREE.Mesh(new THREE.PlaneGeometry(1,0.12), new THREE.MeshBasicMaterial({color:0x37d67a}));
    hpBar.position.y = 2.45;
    group.add(hpBar);
    group.userData.isRemote = true;
    const weaponId = (data.weapon && WEAPONS[data.weapon]) ? data.weapon : 'pistol';
    const gunMesh = gunMeshFor(weaponId, armInfo);
    group.add(gunMesh);
    group.position.set(data.x||0, (data.floor ? FLOOR2_Y : 0), data.z||0);
    scene.add(group);
    const entry = {
      group, hpBar, species, gunMesh, weaponId, armInfo,
      name:data.name||'Operator', health: data.health!=null?data.health:100,
      lastSeen: performance.now(), targetPos:new THREE.Vector3(data.x||0,(data.floor ? FLOOR2_Y : 0),data.z||0), targetYaw:data.yaw||0,
      invisible:false, nameTag, floor: data.floor ? 1 : 0, kills:0
    };
    remotePlayers[id] = entry;
    meshes.forEach(m => shootables.push({mesh:m, kind:'player', ref:{id}}));
    shootables.push({mesh:gunMesh, kind:'player', ref:{id}});
    return entry;
  }

  function swapRemoteWeapon(entry, weaponId){
    const idx = shootables.findIndex(s => s.mesh === entry.gunMesh);
    if(idx >= 0) shootables.splice(idx,1);
    entry.group.remove(entry.gunMesh);
    entry.weaponId = weaponId;
    entry.gunMesh = gunMeshFor(weaponId, entry.armInfo);
    entry.group.add(entry.gunMesh);
    shootables.push({mesh:entry.gunMesh, kind:'player', ref:{id:Object.keys(remotePlayers).find(k=>remotePlayers[k]===entry)}});
  }

  function updateRemotePlayer(data){
    if(!data || data.id === myId) return;
    let entry = remotePlayers[data.id];
    if(!entry) entry = createRemotePlayer(data.id, data);
    if(entry.name !== data.name && data.name){ entry.name = data.name; refreshNameTag(entry); }
    const baseY = (data.y != null) ? Math.max(0, data.y - 1.7) : (data.floor ? FLOOR2_Y : 0);
    if(!entry.group.visible || entry.group.position.distanceTo(entry.targetPos) > 12) entry.group.position.set(data.x, baseY, data.z); // teleport on respawn
    entry.targetPos.set(data.x, baseY, data.z);
    entry.targetYaw = (data.yaw || 0) + Math.PI; // camera looks down -Z, creature models face +Z
    entry.health = data.health != null ? data.health : entry.health;
    entry.invisible = !!data.invisible;
    entry.floor = data.floor ? 1 : 0;
    entry.inHell = !!data.hell;
    entry.kills = data.k || 0;
    entry.lastSeen = performance.now();
    entry.group.visible = !entry.inHell && entry.health > 0;
    if(data.weapon && WEAPONS[data.weapon] && data.weapon !== entry.weaponId) swapRemoteWeapon(entry, data.weapon);
  }

  function pruneRemotePlayers(){
    const now = performance.now();
    for(const id in remotePlayers){
      const e = remotePlayers[id];
      if(now - e.lastSeen > 3000 || (net.online && !net.players[id])) e.group.visible = false;
    }
    document.getElementById('onlineCount').textContent = net.online ? Object.keys(net.players).length : 1;
  }
  function refreshNameTag(entry){
    if(entry.nameTag){ entry.group.remove(entry.nameTag); if(entry.nameTag.material.map) entry.nameTag.material.map.dispose(); entry.nameTag.material.dispose(); }
    entry.nameTag = makeNameSprite(entry.name || 'Operator', '#3dd6ff');
    entry.nameTag.position.y = 2.7;
    entry.group.add(entry.nameTag);
  }
  function escapeHtml(t){ return String(t).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
  function updatePlayersPanel(){
    const listEl = document.getElementById('playersPanelList');
    if(!listEl) return;
    let html = '';
    const myHealthDisplay = localAlive ? Math.round(localHealth) : 0;
    html += '<div class="playerRow' + (localAlive?'':' dead') + '"><span class="pname">' + escapeHtml(myName) + ' (you)' + (net.online && net.isHost ? '<span class="plink">HOST</span>' : '') + '</span><span class="pk">' + myKills + '</span><span class="phealth">' + myHealthDisplay + '</span></div>';
    const now = performance.now();
    const rows = [];
    for(const id in remotePlayers){
      const e = remotePlayers[id];
      if(now - e.lastSeen > 3000 || (net.online && !net.players[id])) continue;
      rows.push({name: e.name || 'Operator', health: Math.round(e.health||0), alive: (e.health||0) > 0, k:e.kills||0, host: id === net.hostId});
    }
    rows.sort((a,b) => a.name.localeCompare(b.name));
    rows.forEach(r => {
      html += '<div class="playerRow' + (r.alive?'':' dead') + '"><span class="pname">' + escapeHtml(r.name) + (r.host?'<span class="plink">HOST</span>':'') + '</span><span class="pk">' + r.k + '</span><span class="phealth">' + r.health + '</span></div>';
    });
    listEl.innerHTML = html;
  }

  /* ============================================================
     POWER-UP PICKUPS
  ============================================================ */
  const PICKUP_TYPES = {
    health:   {color:0x37d67a, label:'Med-Kit'},
    weapon:   {color:0xffb347, label:'Weapon Crate'},
    speed:    {color:0x3dd6ff, label:'Adrenaline'},
    invisible:{color:0xba7bff, label:'Cloak'},
    shield:   {color:0x4fa8ff, label:'Shield Cell'}
  };
  function weightedPickupType(){
    const r = Math.random();
    if(r < 0.30) return 'health';
    if(r < 0.55) return 'weapon';
    if(r < 0.70) return 'speed';
    if(r < 0.85) return 'invisible';
    return 'shield';
  }
  function createPickupMesh(type){
    const info = PICKUP_TYPES[type];
    const group = new THREE.Group();
    let geo;
    if(type === 'weapon') geo = new THREE.BoxGeometry(0.5,0.4,0.7);
    else if(type === 'speed') geo = new THREE.ConeGeometry(0.3,0.6,4);
    else geo = new THREE.OctahedronGeometry(0.32,0);
    const mat = new THREE.MeshStandardMaterial({color:info.color, emissive:info.color, emissiveIntensity:0.6, transparent:true, opacity: type==='invisible'?0.55:1});
    const mesh = new THREE.Mesh(geo, mat);
    group.add(mesh);
    group.userData.spinMesh = mesh;
    return group;
  }
  const pickupPoints = [
    [8,-2],[-8,3],[3,9],[-3,-9],
    [22,4],[22,-4],[-22,4],[-22,-4],
    [4,22],[-4,22],[4,-22],[-4,-22],
    [40,0],[-40,0],[0,40],[0,-40],
    [17,14],[17,-14]
  ];
  const pickups = pickupPoints.map(([x,z]) => ({x,z,type:null,group:null,active:false,respawnAt:performance.now()+Math.random()*4000}));

  // pickups are run by the host so everyone sees the same ones (and two players can't grab the same crate)
  function setPickupType(p, type){
    if(p.group){ scene.remove(p.group); p.group = null; }
    p.type = type || null;
    p.active = !!type;
    if(type){
      p.group = createPickupMesh(type);
      p.group.position.set(p.x, 1.0, p.z);
      scene.add(p.group);
    }
  }
  function trySpawnPickup(p){ setPickupType(p, weightedPickupType()); if(net.online) broadcastPickups(); }
  function collectPickup(p){
    const now = performance.now();
    if(net.online && !net.isHost){
      if(now - (p.claimAt||0) > 700){ p.claimAt = now; net.send('take', {i:pickups.indexOf(p)}, net.hostId); }
      return;
    }
    const type = p.type;
    setPickupType(p, null);
    p.respawnAt = now + 14000 + Math.random()*12000;
    applyPickupEffect(type);
    broadcastPickups();
  }
  function broadcastPickups(){
    if(!net.online || !net.isHost) return;
    net.send('pickups', pickups.map(p => p.active ? p.type : null));
  }
  net.on('pickups', list => {
    if(net.isHost || !Array.isArray(list)) return;
    list.forEach((type, i) => { const p = pickups[i]; if(p && (p.type||null) !== (type||null)) setPickupType(p, PICKUP_TYPES[type] ? type : null); });
  });
  net.on('take', (d, msg) => {
    if(!net.isHost || !d) return;
    const p = pickups[d.i];
    if(!p || !p.active) return;
    const type = p.type;
    setPickupType(p, null);
    p.respawnAt = performance.now() + 14000 + Math.random()*12000;
    net.send('granted', {i:d.i, type}, msg.from);
    broadcastPickups();
  });
  net.on('granted', d => {
    if(!d || !PICKUP_TYPES[d.type]) return;
    const p = pickups[d.i];
    if(p) setPickupType(p, null);
    applyPickupEffect(d.type);
  });
  net.on('hostchange', () => {
    if(net.isHost) pickups.forEach(p => { if(!p.active) p.respawnAt = performance.now() + 6000 + Math.random()*8000; });
  });
  function applyPickupEffect(type){
    const now = performance.now();
    playPickupSound();
    if(type === 'health'){
      localHealth = Math.min(100, localHealth+40);
      updateHealthUI();
      addFeed(myName + ' grabbed a med-kit', false);
    } else if(type === 'weapon'){
      const pick = randomWeaponId();
      equipWeapon(pick);
      addFeed(myName + ' found a ' + WEAPONS[pick].name, false);
    } else if(type === 'speed'){
      speedBoostUntil = now + 8000;
      addFeed(myName + ' grabbed adrenaline', false);
    } else if(type === 'invisible'){
      invisibleUntil = now + 8000;
      addFeed(myName + ' cloaked', false);
    } else if(type === 'shield'){
      shieldAmount = Math.min(100, shieldAmount+50);
      addFeed(myName + ' picked up a shield cell', false);
    }
    updateStatusUI();
  }
  function updatePickups(now){
    const runSpawns = !net.online || net.isHost;
    for(const p of pickups){
      if(!p.active){
        if(runSpawns && now > p.respawnAt) trySpawnPickup(p);
        continue;
      }
      p.group.rotation.y += 0.03;
      p.group.position.y = 1.0 + Math.sin(now*0.002 + p.x)*0.12;
      const dx = camera.position.x - p.x, dz = camera.position.z - p.z;
      if(deployed && localAlive && currentFloor === 0 && (dx*dx+dz*dz) < 1.6*1.6) collectPickup(p);
    }
  }

  /* ============================================================
     FIRING
  ============================================================ */
  const raycaster = new THREE.Raycaster();

  function startReload(){
    if(reloading || shellsLoaded === SHELL_CAPACITY) return;
    reloading = true;
    document.getElementById('reloadMsg').style.opacity = '1';
    playReloadSound();
    setTimeout(() => {
      shellsLoaded = SHELL_CAPACITY;
      reloading = false;
      document.getElementById('reloadMsg').style.opacity = '0';
      updateWeaponUI();
    }, 1600);
  }

  function fireCurrentWeapon(){
    const weapon = WEAPONS[currentWeaponId];
    const now = performance.now();
    if(now - lastShotTime < weapon.cooldown || !localAlive) return;
    if(weapon.kind === 'shotgun' && (reloading || shellsLoaded <= 0)) return;
    lastShotTime = now;
    if(weapon.kind === 'shotgun'){ shellsLoaded--; updateWeaponUI(); }
    playGunshotSound(currentWeaponId);

    const origin = camera.position.clone();
    const forward = camera.getWorldDirection(new THREE.Vector3());
    const muzzlePos = origin.clone().addScaledVector(forward, 0.5).add(new THREE.Vector3(0,-0.15,0));
    spawnMuzzleBlast(muzzlePos, forward, weapon.tracerColor);

    recoilPitch += weapon.recoil;
    recoilYaw += (Math.random()-0.5) * weapon.recoil * 0.4;

    if(weapon.kind === 'rocket'){
      const rMesh = new THREE.Mesh(new THREE.CylinderGeometry(0.05,0.08,0.4,8), new THREE.MeshStandardMaterial({color:0x2a2a2a, metalness:0.5, roughness:0.4}));
      rMesh.position.copy(muzzlePos);
      rMesh.quaternion.setFromUnitVectors(new THREE.Vector3(0,1,0), forward.clone().normalize());
      scene.add(rMesh);
      const vel = forward.clone().multiplyScalar(24);
      vel.y += 3.5;
      grenades.push({mesh:rMesh, vel, floor:currentFloor, exploded:false});
      broadcastShot(muzzlePos, forward, weapon.tracerColor);
      return;
    }

    const meshes = shootables.map(s=>s.mesh);
    const hitBots = new Map();
    const hitPlayers = new Map();
    const hitCreepy = new Map();

    for(let i=0;i<weapon.pellets;i++){
      const spreadX = (Math.random()-0.5)*2*weapon.spread;
      const spreadY = (Math.random()-0.5)*2*weapon.spread;
      const dir = forward.clone();
      const right = new THREE.Vector3().crossVectors(dir, new THREE.Vector3(0,1,0)).normalize();
      const up = new THREE.Vector3().crossVectors(right, dir).normalize();
      dir.addScaledVector(right, spreadX).addScaledVector(up, spreadY).normalize();

      raycaster.set(origin, dir);
      raycaster.far = weapon.range;
      const hits = raycaster.intersectObjects(meshes);
      const endPoint = hits.length ? hits[0].point : origin.clone().addScaledVector(dir, weapon.range);
      spawnTracer(muzzlePos, endPoint, weapon.tracerColor);
      if(i === 0) broadcastShot(muzzlePos, forward, weapon.tracerColor, endPoint);

      if(hits.length === 0) continue;
      const hit = hits[0];
      const entry = shootables.find(s => s.mesh === hit.object);
      if(!entry) continue;
      if(entry.kind === 'bot'){
        const rec = hitBots.get(entry.ref) || {dmg:0, point:hit.point};
        rec.dmg += weapon.damage;
        hitBots.set(entry.ref, rec);
      } else if(entry.kind === 'player'){
        const rec = hitPlayers.get(entry.ref.id) || {dmg:0, point:hit.point};
        rec.dmg += weapon.damage;
        hitPlayers.set(entry.ref.id, rec);
      } else if(entry.kind === 'creepy'){
        const rec = hitCreepy.get(entry.ref) || {dmg:0, point:hit.point};
        rec.dmg += weapon.damage;
        hitCreepy.set(entry.ref, rec);
      }
    }

    let anyHit = false;
    hitBots.forEach((rec, bot) => { damageBot(bot, rec.dmg, rec.point); anyHit = true; });
    hitPlayers.forEach((rec, id) => {
      sendDamage(id, rec.dmg);
      const rp = remotePlayers[id];
      if(rp) spawnBlood(rec.point, rp.species.blood);
      anyHit = true;
    });
    hitCreepy.forEach((rec, figure) => { damageCreepyFigure(figure, rec.dmg, rec.point); anyHit = true; });
    if(anyHit) flashHitmarker();

    if(weapon.kind === 'shotgun' && shellsLoaded <= 0) startReload();
  }

  /* ============================================================
     NETWORKING — outgoing
  ============================================================ */
  function sendDamage(targetId, amount){
    net.send('dmg', {targetId, amount, from:myId, fromName:myName}, targetId);
  }
  function reportDeathTo(killerId, killerName){
    net.send('kill', {killerId, victim:myName, weapon:currentWeaponId}, killerId);
  }
  function broadcastShot(muzzlePos, forward, color, endPoint){
    const d = {x:muzzlePos.x, y:muzzlePos.y, z:muzzlePos.z, dx:forward.x, dy:forward.y, dz:forward.z, color, w:currentWeaponId};
    if(endPoint){ d.ex = endPoint.x; d.ey = endPoint.y; d.ez = endPoint.z; }
    net.send('shot', d);
  }

  /* ============================================================
     INPUT
  ============================================================ */
  document.addEventListener('keydown', e => {
    if(chatOpen) return;
    if(e.code === 'KeyT' && document.getElementById('hud').style.display === 'block'){
      openChat();
      return;
    }
    if(e.code === 'KeyE'){ tryTradeAtStand(); tryGetFortune(); tryDrinkAtBar(); tryPlayJukebox(); tryPlayPool(); tryThrowDart(); tryUseVendingMachine(); }
    if(e.code === 'KeyY') answerTechGuy(true);
    if(e.code === 'KeyM') toggleGameMusic();
    if(e.code === 'KeyN') answerTechGuy(false);
    if(e.code === 'KeyG') throwGrenade();
    if(e.code === 'KeyR' && WEAPONS[currentWeaponId].kind === 'shotgun') startReload();
    keys[e.code] = true;
  });
  document.addEventListener('keyup', e => { if(!chatOpen) keys[e.code] = false; });

  const canvasEl = renderer.domElement;
  const chatInputEl = document.getElementById('chatInput');
  chatInputEl.addEventListener('keydown', e => {
    e.stopPropagation();
    if(e.key === 'Enter') sendChatMessage();
    else if(e.key === 'Escape') closeChat();
  });
  canvasEl.addEventListener('mousedown', (e) => {
    if(document.getElementById('startScreen').style.display !== 'none') return;
    if(chatOpen) return;
    if(e.button !== 0) return;
    if(!pointerLocked){ canvasEl.requestPointerLock(); return; }
    isMouseDown = true;
  });
  document.addEventListener('mouseup', (e) => { if(e.button===0) isMouseDown = false; });
  document.addEventListener('pointerlockchange', () => {
    pointerLocked = document.pointerLockElement === canvasEl;
    if(!pointerLocked) isMouseDown = false;
  });
  document.addEventListener('mousemove', e => {
    if(!pointerLocked) return;
    yaw -= e.movementX * 0.0022;
    pitch -= e.movementY * 0.0022;
    pitch = Math.max(-1.3, Math.min(1.3, pitch));
  });

  /* ============================================================
     START SCREEN
  ============================================================ */
  const nameInput = document.getElementById('nameInput');
  const playBtn = document.getElementById('playBtn');
  const qualitySelect = document.getElementById('qualitySelect');
  try{ const saved = localStorage.getItem('dma_name'); if(saved) nameInput.value = saved; }catch(e){}
  // graphics preset picker
  (function(){
    const auto = document.createElement('option');
    auto.value = 'auto'; auto.textContent = 'Auto-detect (' + DMA.PRESETS[DMA.Q.name].label + ')';
    qualitySelect.appendChild(auto);
    Object.keys(DMA.PRESETS).forEach(k => { const o = document.createElement('option'); o.value = k; o.textContent = DMA.PRESETS[k].label; qualitySelect.appendChild(o); });
    qualitySelect.value = (DMA.choice && DMA.PRESETS[DMA.choice]) ? DMA.choice : 'auto';
    qualitySelect.addEventListener('change', () => {
      if(qualitySelect.value === 'auto'){ try{ localStorage.removeItem('dma_quality'); }catch(e){} const u = new URL(location.href); u.searchParams.delete('q'); location.href = u.toString(); }
      else DMA.setQuality(qualitySelect.value);
    });
    const g = document.getElementById('gpuName');
    if(g) g.textContent = DMA.gpuName ? ('GPU: ' + DMA.gpuName.replace(/\s*\(.*?\)\s*/g,' ').slice(0,70)) : '';
  })();
  function updateNetStatusLine(){
    if(!net.available){
      mpStatusEl.textContent = 'Opened as a file — single-player only. Start the server (start-windows.bat / start-pi.sh) and open the address it shows to play on your LAN.';
      mpStatusEl.className = '';
    } else if(net.online){
      const n = Object.keys(net.players).length;
      mpStatusEl.textContent = 'LAN server: CONNECTED — ' + n + ' operator' + (n===1?'':'s') + ' in the mall' + (net.isHost ? ' · you host the aliens' : '');
      mpStatusEl.className = 'on';
    } else {
      mpStatusEl.textContent = 'LAN server: connecting...';
      mpStatusEl.className = '';
    }
    const info = document.getElementById('serverInfo');
    if(info && net.serverInfo && net.serverInfo.urls && net.serverInfo.urls.length){
      info.innerHTML = 'Friends on your network join at: ' + net.serverInfo.urls.map(u => '<b>' + escapeHtml(u) + '</b>').join(' or ');
    }
    document.getElementById('onlineCount').textContent = net.online ? Object.keys(net.players).length : 1;
    document.getElementById('partyLabel').textContent = net.online ? 'LAN ARENA' : (net.available ? 'RECONNECTING...' : 'SINGLE PLAYER');
  }
  net.on('join', updateNetStatusLine); net.on('leave', updateNetStatusLine); net.on('hostchange', updateNetStatusLine);
  // connect right away (as a spectator name) so the start screen can show who's already in the mall
  net.connect(myId, 'Operator' + Math.floor(Math.random()*900+100));
  updateNetStatusLine();
  setInterval(updateNetStatusLine, 3000);

  const guideToggle = document.getElementById('guideToggle');
  const guidePanel = document.getElementById('guidePanel');
  guideToggle.addEventListener('click', () => {
    const open = guidePanel.classList.toggle('open');
    guideToggle.textContent = open ? 'Power-Ups & Multiplayer Guide ▴' : 'Power-Ups & Multiplayer Guide ▾';
  });
  nameInput.addEventListener('keydown', e => { if(e.key === 'Enter') playBtn.click(); });
  playBtn.addEventListener('click', () => {
    ensureAudio();
    const v = nameInput.value.trim();
    myName = v.length ? v.slice(0,16) : ('Operator'+Math.floor(Math.random()*900+100));
    try{ localStorage.setItem('dma_name', myName); }catch(e){}
    net.rename(myName);
    document.getElementById('startScreen').style.display = 'none';
    document.getElementById('hud').style.display = 'block';
    canvasEl.requestPointerLock();
    clock.getDelta();
    deployed = true;
  });
  let deployed = false;

  /* ============================================================
     MAIN LOOP
  ============================================================ */
  const clock = new THREE.Clock();
  let netAccum = 0, statusAccum = 0, drunkDecayAccum = 0, botNetAccum = 0, pickupNetAccum = 0;
  let hurtGlow = 0;

  function animate(){
    requestAnimationFrame(animate);
    const dt = Math.min(clock.getDelta(), 0.08);
    const now = performance.now();

    recoilPitch *= Math.pow(0.001, dt);
    recoilYaw *= Math.pow(0.001, dt);
    if(recoilPitch < 0.0005) recoilPitch = 0;
    if(recoilYaw < 0.0005) recoilYaw = 0;

    if(drunkLevel > 0){
      const swayAmt = drunkLevel*0.042;
      drunkSwayYaw = Math.sin(now*0.0019)*swayAmt;
      drunkSwayPitch = Math.sin(now*0.0014+1)*swayAmt*0.7;
      drunkSwayRoll = Math.sin(now*0.0011+2)*drunkLevel*0.055;
    } else {
      drunkSwayYaw = 0; drunkSwayPitch = 0; drunkSwayRoll = 0;
    }

    if(localAlive && !inHell){
      const shakeYaw = storyShakeAmt > 0 ? (Math.random()-0.5)*storyShakeAmt : 0;
      const shakePitch = storyShakeAmt > 0 ? (Math.random()-0.5)*storyShakeAmt*0.7 : 0;
      camera.rotation.y = yaw + recoilYaw + drunkSwayYaw + shakeYaw;
      camera.rotation.x = pitch + recoilPitch + drunkSwayPitch + shakePitch;
      camera.rotation.z = drunkSwayRoll;

      const forward = new THREE.Vector3(-Math.sin(yaw), 0, -Math.cos(yaw));
      const right = new THREE.Vector3(Math.cos(yaw), 0, -Math.sin(yaw));
      const move = new THREE.Vector3();
      if(keys['KeyW']) move.add(forward);
      if(keys['KeyS']) move.sub(forward);
      if(keys['KeyD']) move.add(right);
      if(keys['KeyA']) move.sub(right);
      if(drunkLevel > 0 && move.lengthSq() > 0){
        const stumble = Math.sin(now*0.0026)*drunkLevel*0.38;
        move.add(right.clone().multiplyScalar(stumble));
      }
      if(move.lengthSq() > 0){
        const speedEff = MOVE_SPEED * (now < speedBoostUntil ? 1.6 : 1) * (drunkLevel > 0 ? Math.max(0.4, 1-drunkLevel*0.14) : 1);
        move.normalize().multiplyScalar(speedEff*dt);
        camera.position.x += move.x;
        camera.position.z += move.z;
        collideAndSlide(camera.position, 0.55, currentFloor);
      }

      // escalator: ride between floors by walking through it
      const escDX = camera.position.x - ESC_X;
      if(Math.abs(escDX) < ESC_HALF_W && camera.position.z > ESC_Z0-1 && camera.position.z < ESC_Z1+1){
        const t = Math.max(0, Math.min(1, (camera.position.z-ESC_Z0)/(ESC_Z1-ESC_Z0)));
        const desiredY = 1.7 + t*FLOOR2_Y;
        camera.position.y += (desiredY - camera.position.y) * Math.min(1, dt*6);
        currentFloor = t > 0.5 ? 1 : 0;
      } else {
        sitOffset += (sitTargetOffset - sitOffset) * Math.min(1, dt*2.5);
        camera.position.y = 1.7 + currentFloor*FLOOR2_Y + sitOffset;
      }

      // pizza cafe recharge stations (upstairs only)
      if(currentFloor === 1 && localAlive){
        const dxH = camera.position.x - PIZZA_HEAL_X, dzH = camera.position.z - PIZZA_HEAL_Z;
        if(dxH*dxH+dzH*dzH < 2.2*2.2 && now > nextPizzaHealAt && localHealth < 100){
          localHealth = Math.min(100, localHealth + 25);
          updateHealthUI();
          addFeed(myName + ' grabbed a slice — health topped up', false);
          nextPizzaHealAt = now + 6000;
        }
        const dxS = camera.position.x - POP_SPEED_X, dzS = camera.position.z - POP_SPEED_Z;
        if(dxS*dxS+dzS*dzS < 2.2*2.2 && now > nextPopSpeedAt){
          speedBoostUntil = now + 8000;
          updateStatusUI();
          addFeed(myName + ' chugged some pop — speed boost!', false);
          nextPopSpeedAt = now + 6000;
        }
      }

      if(isMouseDown) fireCurrentWeapon();
    } else if(inHell){
      camera.rotation.y = yaw + Math.sin(now*0.009)*0.03;
      camera.rotation.x = pitch + Math.sin(now*0.011)*0.02;
      camera.rotation.z = Math.sin(now*0.0075)*0.02;
    }

    hellFires.forEach((f,i) => {
      f.scale.y = 1 + Math.sin(now*0.006+i)*0.25;
      f.material.opacity = 0.7 + Math.sin(now*0.008+i*1.3)*0.15;
    });
    if(hellFireLight) hellFireLight.intensity = 2.0 + Math.sin(now*0.005)*0.6;
    if(jukeboxPlaying && jukeboxLight){
      const pulse = 0.7 + Math.abs(Math.sin(now*0.012))*1.6;
      jukeboxLight.intensity = pulse;
      if(jukeboxGlow) jukeboxGlow.material.color.setHSL((now*0.0002)%1, 0.8, 0.55);
    } else if(jukeboxLight){
      jukeboxLight.intensity = 0.7;
    }
    poolBalls.forEach(b => {
      if(b.phase === 'scatter'){
        const f = Math.max(0, Math.min(1, (now-b.phaseStart)/400));
        b.mesh.position.x = b.origX + (b.targetX-b.origX)*f;
        b.mesh.position.z = b.origZ + (b.targetZ-b.origZ)*f;
        b.mesh.rotation.y += dt*10;
        b.mesh.rotation.x += dt*7;
      } else if(b.phase === 'return'){
        const f = Math.max(0, Math.min(1, (now-b.phaseStart)/1000));
        b.mesh.position.x = b.targetX + (b.origX-b.targetX)*f;
        b.mesh.position.z = b.targetZ + (b.origZ-b.targetZ)*f;
        b.mesh.rotation.y += dt*4;
      }
    });
    if(poolCue && poolCue.userData.strikeStart){
      const sf = (now - poolCue.userData.strikeStart)/220;
      if(sf < 1){
        poolCue.position.x = poolCueOrigX - Math.sin(Math.min(1,sf)*Math.PI)*0.4;
      } else {
        poolCue.position.x = poolCueOrigX;
        poolCue.userData.strikeStart = null;
      }
    }

    for(const bot of bots) updateBot(bot, dt, now);

    for(const id in remotePlayers){
      const e = remotePlayers[id];
      e.group.position.x += (e.targetPos.x - e.group.position.x) * Math.min(1, dt*14);
      e.group.position.z += (e.targetPos.z - e.group.position.z) * Math.min(1, dt*14);
      e.group.position.y += (e.targetPos.y - e.group.position.y) * Math.min(1, dt*12);
      let dYaw = e.targetYaw - e.group.rotation.y;
      while(dYaw > Math.PI) dYaw -= Math.PI*2;
      while(dYaw < -Math.PI) dYaw += Math.PI*2;
      e.group.rotation.y += dYaw * Math.min(1, dt*14);
      const frac = Math.max(0, e.health/100);
      e.hpBar.scale.x = frac;
      e.hpBar.material.color.setHex(frac > 0.4 ? 0x37d67a : 0xff3b3b);
      const targetOpacity = e.invisible ? 0.12 : 1;
      e.group.traverse(child => {
        if(child.material && child.material.opacity !== undefined){
          child.material.opacity += (targetOpacity - child.material.opacity) * 0.12;
        }
      });
    }

    updateBloodAndTracers();
    escalatorTextures.forEach(t => { t.offset.y = (t.offset.y - dt*0.4) % 1; });
    const escSpeed = 0.09;
    escalatorSteps.forEach(s => {
      const t = (s.phase + now*0.001*escSpeed) % 1;
      positionEscalatorStep(s, t);
    });
    const armT = now*0.001;
    pizzaRobots.forEach(r => {
      r.shoulderPivot.rotation.x = -0.3 + Math.sin(armT*1.3)*0.35;
      r.elbowPivot.rotation.x = -0.4 + Math.sin(armT*1.7+1)*0.5;
      r.shoulderPivot.rotation.z = Math.sin(armT*0.7)*0.15;
      // wide swing toward the bar to sell the "placing pizza" motion, cued to a slow cycle
      const swing = Math.sin(armT*0.5);
      r.shoulderPivot.rotation.y = swing*0.7;
      if(r.heldPizza) r.heldPizza.visible = swing < 0.15;
    });
    animatronics.forEach(a => {
      const t = armT + a.phase;
      a.headPivot.rotation.y = Math.sin(t*0.6)*0.3;
      a.headPivot.rotation.x = Math.sin(t*0.9+1)*0.06;
      a.armPivotL.rotation.z = a.baseArmRotL + Math.sin(t*1.1)*0.08;
      a.armPivotR.rotation.z = a.baseArmRotR + Math.sin(t*1.4+2)*0.12;
      a.group.position.y = 0.3 + Math.sin(t*1.8)*0.015;
    });
    if(pizzaSliceMesh){
      pizzaSliceMesh.visible = now > nextPizzaHealAt;
      if(pizzaSliceMesh.visible){ pizzaSliceMesh.rotation.z += dt*1.2; pizzaSliceMesh.position.y = 1.0 + Math.sin(now*0.002)*0.08; }
    }
    // conveyor belt: fresh pizzas pop out of the oven, ride the belt loop, and heal you 5hp on contact
    if(pizzaPlaceRoomGroup && conveyorPathSegs){
      if(conveyorPizzas.length < 4 && now > nextConveyorSpawnAt){
        nextConveyorSpawnAt = now + 5000 + Math.random()*2000;
        const pGroup = new THREE.Group();
        const base = new THREE.Mesh(new THREE.CylinderGeometry(0.22,0.22,0.05,16), new THREE.MeshStandardMaterial({color:0xe8c473, roughness:0.6, emissive:0xffae3d, emissiveIntensity:0.2}));
        pGroup.add(base);
        for(let i=0;i<4;i++){
          const ang = (i/4)*Math.PI*2;
          const pep = new THREE.Mesh(new THREE.CylinderGeometry(0.04,0.04,0.02,6), new THREE.MeshStandardMaterial({color:0xa33020}));
          pep.position.set(Math.cos(ang)*0.12, 0.03, Math.sin(ang)*0.12);
          pGroup.add(pep);
        }
        pGroup.scale.set(0.01,0.01,0.01);
        pGroup.position.set(ovenWorldPos.x, 0.75, ovenWorldPos.z);
        pizzaPlaceRoomGroup.add(pGroup);
        conveyorPizzas.push({group:pGroup, state:'popping', stateStart:now, t:0});
      }
      conveyorPizzas.forEach(p => {
        if(p.state === 'popping'){
          const f = Math.min(1, (now-p.stateStart)/300);
          p.group.scale.set(f,f,f);
          if(f >= 1){ p.state = 'toBelt'; p.stateStart = now; }
        } else if(p.state === 'toBelt'){
          const f = Math.min(1, (now-p.stateStart)/600);
          const start = ovenWorldPos, end = getConveyorPoint(0);
          p.group.position.x = start.x + (end.x-start.x)*f;
          p.group.position.z = start.z + (end.z-start.z)*f;
          p.group.position.y = 0.75 + Math.sin(f*Math.PI)*0.15;
          if(f >= 1){ p.state = 'onBelt'; p.t = 0; }
        } else if(p.state === 'onBelt'){
          p.t += dt*0.02;
          if(p.t >= 1) p.t -= 1;
          const pos = getConveyorPoint(p.t);
          p.group.position.set(pos.x, 0.79, pos.z);
          p.group.rotation.y += dt*0.6;
          if(currentFloor === 1 && localAlive){
            const dx = camera.position.x - pos.x, dz = camera.position.z - pos.z;
            if(dx*dx+dz*dz < 1.3*1.3){
              localHealth = Math.min(100, localHealth + 5);
              updateHealthUI();
              addFeed(myName + ' grabbed a pizza off the belt — +5 health', false);
              p.collected = true;
            }
          }
        }
      });
      for(let i=conveyorPizzas.length-1;i>=0;i--){
        if(conveyorPizzas[i].collected){
          pizzaPlaceRoomGroup.remove(conveyorPizzas[i].group);
          conveyorPizzas.splice(i,1);
        }
      }
    }
    if(sodaCanMesh){
      sodaCanMesh.visible = now > nextPopSpeedAt;
      if(sodaCanMesh.visible){ sodaCanMesh.rotation.y += dt*1.6; sodaCanMesh.position.y = 1.0 + Math.sin(now*0.002+1)*0.08; }
    }
    updatePickups(now);
    updateMovieScreen(now);
    crystalBalls.forEach(cb => {
      cb.material.emissiveIntensity = 0.3 + Math.sin(now*0.002)*0.25;
      cb.rotation.y += dt*0.3;
    });
    if(drunkLevel !== appliedBlurLevel){
      appliedBlurLevel = drunkLevel;
      canvasEl.style.filter = drunkLevel > 0 ? `blur(${drunkLevel*0.75}px) saturate(${1+drunkLevel*0.1})` : '';
      const meterWrap = document.getElementById('drunkMeterWrap');
      const meterFill = document.getElementById('drunkMeterFill');
      if(drunkLevel > 0){ meterWrap.classList.add('show'); meterFill.style.width = (drunkLevel/5*100)+'%'; }
      else meterWrap.classList.remove('show');
    }
    drunkDecayAccum += dt;
    if(drunkDecayAccum > 14 && drunkLevel > 0 && now > drunkLockedUntil){
      drunkDecayAccum = 0;
      drunkLevel--;
    }
    if(now < shieldRegenUntil && localAlive){
      shieldAmount = 100;
    }
    tryAskTechGuy();
    if(storyTriggerPos && currentFloor === 1 && !storyPlaying){
      const dx = camera.position.x-storyTriggerPos.x, dz = camera.position.z-storyTriggerPos.z;
      if(dx*dx+dz*dz < 4*4 && now > storyPlayedAt){
        storyPlaying = true;
        storyPlayedAt = now + storyLines.length*4800 + 90000;
        addFeed('The animatronics power on with a mechanical whir...', false);
        playTradeSound();
        playStorySequence();
        sitTargetOffset = -0.7;
        const storyDuration = storyLines.length*4800+500;
        setTimeout(() => { storyPlaying = false; sitTargetOffset = 0; storyShakeAmt = 0; }, storyDuration);
        // ambient horror beats scattered through the telling: flickers, a mild tremor, and something screaming or laughing in the dark
        const effectCount = 5 + Math.floor(Math.random()*3);
        for(let i=0;i<effectCount;i++){
          const at = 2500 + Math.random()*(storyDuration-4000);
          setTimeout(() => {
            const roll = Math.random();
            if(roll < 0.4){
              flickerScreenOnce();
              setTimeout(flickerScreenOnce, 120);
            } else if(roll < 0.7){
              playScreamOrLaugh();
            } else {
              storyShakeAmt = 0.35;
              setTimeout(() => { storyShakeAmt = 0; }, 900);
            }
          }, at);
        }
      }
    }
    grenades.forEach(g => {
      g.vel.y -= 9.8*dt;
      g.mesh.position.addScaledVector(g.vel, dt);
      const floorBase = g.floor*FLOOR2_Y;
      if(g.mesh.position.y <= floorBase+0.15){
        g.mesh.position.y = floorBase+0.15;
        g.exploded = true;
      }
    });
    for(let i=grenades.length-1;i>=0;i--){
      if(grenades[i].exploded){
        explodeGrenade(grenades[i].mesh.position.clone(), grenades[i].floor);
        scene.remove(grenades[i].mesh);
        grenades.splice(i,1);
      }
    }
    speechFollowers.forEach(sf => {
      const p = sf.followFn();
      sf.bubble.mesh.position.set(p.x, p.y+sf.bubble.yOffset, p.z);
    });
    billboardPlaques.forEach(p => {
      const dx = camera.position.x - p.position.x;
      const dz = camera.position.z - p.position.z;
      p.rotation.y = Math.atan2(dx, dz);
    });
    creepyFigures.forEach(f => {
      if(!f.alive){
        if(now > f.respawnAt){
          f.alive = true;
          f.health = f.maxHealth;
          f.group.position.set(f.originalX, 0, f.originalZ);
          f.group.visible = true;
        }
        return;
      }
      const toFig = new THREE.Vector3().subVectors(f.group.position, camera.position);
      toFig.y += 3.18; // matches the figure's actual eye height
      const dist = toFig.length();
      toFig.normalize();
      const camForward = camera.getWorldDirection(new THREE.Vector3());
      const dot = camForward.dot(toFig);
      const noticed = currentFloor === 1 && dist < 24 && dot > 0.95;
      const targetIntensity = noticed ? 1.0 : 0.05;
      f.eyeL.material.emissiveIntensity += (targetIntensity - f.eyeL.material.emissiveIntensity) * 0.15;
      f.eyeR.material.emissiveIntensity += (targetIntensity - f.eyeR.material.emissiveIntensity) * 0.15;
      f.teeth.material.opacity += ((noticed?1:0) - f.teeth.material.opacity) * 0.15;
      // creeps closer while you're not looking at it; freezes the instant you spot it
      if(currentFloor === 1 && !noticed){
        const toPlayer = new THREE.Vector3(camera.position.x - f.group.position.x, 0, camera.position.z - f.group.position.z);
        const groundDist = toPlayer.length();
        if(groundDist > 2.2){
          toPlayer.normalize();
          const creepSpeed = 1.15;
          f.group.position.x += toPlayer.x * creepSpeed * dt;
          f.group.position.z += toPlayer.z * creepSpeed * dt;
          f.group.rotation.y = Math.atan2(toPlayer.x, toPlayer.z);
        }
        if(groundDist < 4 && now - (f.lastBreathAt||0) > 1900+Math.random()*900){
          f.lastBreathAt = now;
          playCreepyBreath();
        }
      }
    });

    netAccum += dt; statusAccum += dt; botNetAccum += dt; pickupNetAccum += dt;
    if(netAccum > 0.05){ netAccum = 0; if(deployed) broadcastMyState(); }
    if(net.online && net.isHost){
      if(botNetAccum > 0.08){ botNetAccum = 0; broadcastBots(); }
      if(pickupNetAccum > 2.0){ pickupNetAccum = 0; broadcastPickups(); }
    }
    if(statusAccum > 0.2){ statusAccum = 0; updateStatusUI(); updatePlayersPanel(); pruneRemotePlayers(); }

    // red-tinted vision while badly hurt (post-processing presets)
    const hurtTarget = localAlive ? Math.max(0, (30 - localHealth)/30) * 0.22 : 0.3;
    hurtGlow += (hurtTarget - hurtGlow) * Math.min(1, dt*3);
    pipeline.setHurt(hurtGlow);
    DMAGfx.frame(camera, now);
    pipeline.render();
  }
  animate();
  const loadingEl = document.getElementById('loading'); if(loadingEl) loadingEl.remove();
  // batch everything that never moves (two snapshots a few seconds apart; anything that moved or
  // is known to animate on its own or when you interact with it stays separate)
  setTimeout(() => {
    const first = DMAGfx.snapshotStatic(scene);
    setTimeout(() => {
      const keepSeparate = [];
      bots.forEach(b => keepSeparate.push(b.group));
      poolBalls.forEach(b => keepSeparate.push(b.mesh));
      escalatorSteps.forEach(st => keepSeparate.push(st.tread, st.riser, st.edge));
      pizzaRobots.forEach(r => keepSeparate.push(r.group));
      animatronics.forEach(a => keepSeparate.push(a.group));
      creepyFigures.forEach(f => keepSeparate.push(f.group));
      keepSeparate.push(poolCue, sodaCanMesh, pizzaSliceMesh, jukeboxGlow, fortuneTellerFigure, movieScreen, ...crystalBalls, ...hellFires, ...billboardPlaques);
      flickerLights.forEach(fl => keepSeparate.push(fl.fixture));
      pickups.forEach(p => keepSeparate.push(p.group));
      try{ DMAGfx.mergeStatic(scene, first, keepSeparate.filter(Boolean)); }catch(e){ console.warn('batching skipped', e); }
    }, 3000);
  }, 800);
  window.__dma = { scene, camera, renderer, pipeline, bots, remotePlayers, pickups, net, get myKills(){ return myKills; }, get localHealth(){ return localHealth; }, get deployed(){ return deployed; },
    teleport(x,z,yawV,pitchV,floor){ camera.position.set(x, 1.7+(floor||0)*FLOOR2_Y, z); currentFloor = floor||0; yaw = yawV||0; pitch = pitchV||0; },
    fire(){ fireCurrentWeapon(); }, damageLocalPlayer, equipWeapon, get weapon(){ return currentWeaponId; } };

})();
